/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'superadmin' | 'owner' | 'manager' | 'sales' | 'engineer' | 'customer';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'active' | 'disabled' | 'suspended' | 'expired' | 'pending';
  ownerId: string;
  phone?: string;
  password?: string;
  hierarchyLevel?: number; // 1 to 4 for B2B Smart Market
  custodyBalance?: number; // Caches salesman direct collections
  trustedDevices?: string[];
  maxDevices?: number;
  isLifetime?: boolean;
  subscriptionType?: 'trial' | 'paid';
  subscriptionEndDate?: string;
  printerSettings?: {
    type: 'bluetooth' | 'wifi' | 'usb' | 'system';
    paperSize: '58mm' | '80mm';
    autoPrint: boolean;
  };
}

export interface InventoryItem {
  id: string; // barcode or custom id
  ownerId: string;
  name: string;
  category: string;
  stock: number;
  minStock: number;
  price: number; // Retail price
  wholesalePrice?: number; // For wholesalers and B2B traders
  cost: number; // base cost
  lastBuyPrice?: number;
  barcode?: string;
  supplierId?: string;
  compatibilityList?: string[]; // for maintenance engineers
  warehouses?: {
    [warehouseName: string]: number; // Distribution per warehouse
  };
  units?: {
    id: string;
    name: string; // carton, dozen, pack
    factor: number; // e.g. dozen = 12
    price: number;
    cost: number;
    barcode?: string;
  }[];
}

export interface SaleItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  cost: number;
  returnedAmount?: number;
  isReturn?: boolean;
  returnReason?: string;
  returnActionType?: 'damaged' | 'replacement';
}

export interface Sale {
  id: string;
  ownerId: string;
  items: SaleItem[];
  total: number;
  profit: number;
  paymentMethod: 'cash' | 'transfer' | 'debt';
  accountId?: string; // bank account model
  customerId?: string; // VIP or merchant customer
  sellerId: string;
  sellerName: string;
  isCustodyReceived?: boolean;
  createdAt: string;
}

export interface ReturnFlow {
  id: string;
  ownerId: string;
  type: 'customer' | 'supplier';
  itemId: string;
  itemName: string;
  quantity: number;
  totalAmount: number;
  reason: string;
  inspectorId: string;
  inspectorName: string;
  managerId?: string;
  managerName?: string;
  status: 'inspection' | 'approval' | 'routing' | 'completed' | 'rejected';
  destinationWarehouse?: string;
  financialAction?: 'deduct_debt' | 'credit_balance' | 'cash_refund';
  createdAt: string;
  updatedAt: string;
}

export interface PurchaseItem {
  id: string;
  name: string;
  buyPrice: number;
  quantity: number;
  unitType: 'piece' | 'dozen' | 'carton';
  qtyInPieces: number;
}

export interface PurchaseInvoice {
  id: string;
  ownerId: string;
  buyerId: string;
  buyerName: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseItem[];
  total: number;
  paymentMethod: 'cash' | 'credit';
  createdAt: string;
}

export interface B2BOrder {
  id: string;
  fromUid: string;
  fromName: string;
  fromTier: number; // levels 1-4
  toUid: string;
  toName: string;
  toTier: number;
  items: {
    id: string;
    name: string;
    quantity: number;
    price: number;
  }[];
  total: number;
  status: 'pending' | 'ready' | 'dispatched' | 'completed' | 'rejected';
  inspectorName?: string; // dispatch pack checker
  createdAt: string;
  updatedAt: string;
}

export interface MaintenanceJob {
  id: string;
  ownerId?: string;
  customerName: string;
  customerPhone: string;
  deviceModel: string;
  problem: string;
  sparePartsUsed: {
    id: string;
    name: string;
    price: number;
    cost: number;
    quantity: number;
  }[];
  cost: number; // labor cost + parts
  status: 'pending' | 'repairing' | 'completed' | 'delivered' | 'cancelled';
  engineerId: string;
  engineerName: string;
  commission: number; // percentage or fixed
  createdAt: string;
}

export interface FinancialTransaction {
  id: string;
  ownerId: string;
  type: 'income' | 'expense' | 'transfer';
  amount: number;
  category: string;
  description: string;
  accountId?: string; // Box or bank name e.g. 'الكريمي', 'يمن كاش'
  createdAt: string;
}

export interface AccountNode {
  id: string;
  name: string;
  code: string;
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  balance: number;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  device: string;
  timestamp: string;
}

export interface DamagedItem {
  id: string;
  ownerId: string;
  itemId: string;
  itemName: string;
  quantity: number;
  cost: number;
  reason: string;
  reportedBy: string;
  reportedByName: string;
  createdAt: string;
}

export interface CallCreditRecord {
  id: string;
  date: string;
  soldAmount: number;
  programName: string; // e.g., 'الكريمي', 'يمن موبايل', 'سبأفون', 'يو'
  purchasedAmount: number;
  cashInDrawer: number;
  profit: number;
  registeredAt: string;
  engineerId: string;
  engineerName: string;
  notes?: string;
}

export interface SIMCardItem {
  id: string;
  invoiceRef: string; // الفاتورة عند شراء الشرايح
  serialNumber: string; // الرقم التسلسلي لكل شريحة
  costReplacement: number; // سعر الشراء بدل فاقد
  costNew: number; // سعر الشراء جديد
  priceNew: number; // سعر البيع جديد
  priceReplacement: number; // سعر البيع بدل فاقد
  stock: number; // الكمية
  supplierName: string; // المورد لهن
  createdAt: string;
}

