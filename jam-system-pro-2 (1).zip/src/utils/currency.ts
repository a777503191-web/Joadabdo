/**
 * Currency configuration helper for JAM SYSTEM PRO
 */

export function getCurrencySymbol(): string {
  return localStorage.getItem('shop_currency_symbol') || 'ر.ي';
}

export function getCurrencyRate(): number {
  return parseFloat(localStorage.getItem('shop_currency_rate') || '1');
}

export function roundToTwoDecimals(num: number): number {
  return Math.round((num + Number.EPSILON) * 100) / 100;
}

export function formatMoney(amount: number): string {
  const symbol = getCurrencySymbol();
  const rate = getCurrencyRate();
  const finalVal = roundToTwoDecimals(amount * rate);
  return `${finalVal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${symbol}`;
}
