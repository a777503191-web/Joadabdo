/**
 * High-quality printer utility for JAM SYSTEM PRO - Yemeni Multi-Identity Retail Suite
 */

import { formatMoney } from './currency';

export function handlePrintSection(elementId: string, title: string) {
  const contentElement = document.getElementById(elementId);
  if (!contentElement) {
    alert('❌ لم يتم العثور على العنصر المراد طباعته!');
    return;
  }

  // Clone content and remove any elements marked with class "no-print"
  const clone = contentElement.cloneNode(true) as HTMLElement;
  const noPrintElements = clone.querySelectorAll('.no-print');
  noPrintElements.forEach(el => el.remove());

  // Also adjust input/select elements to print their actual values
  const inputs = contentElement.querySelectorAll('input, select, textarea');
  const cloneInputs = clone.querySelectorAll('input, select, textarea');
  inputs.forEach((original: any, index) => {
    const clonedEl = cloneInputs[index] as HTMLElement;
    if (clonedEl) {
      const parent = clonedEl.parentElement;
      if (parent) {
        const valSpan = document.createElement('span');
        valSpan.className = 'font-bold text-black border-b border-zinc-350 px-1 py-0.5';
        valSpan.innerText = original.value || original.innerText || '';
        parent.replaceChild(valSpan, clonedEl);
      }
    }
  });

  const printWindow = window.open('', '_blank', 'width=900,height=750');
  if (!printWindow) {
    alert('⚠️ يرجى السماح بالنوافذ المنبثقة (Popups) لتتمكن من الطباعة والتصدير!');
    return;
  }

  const shopName = localStorage.getItem('default_shop_name') || 'مركز جام برو الرئيسي';
  const slogan = localStorage.getItem('default_shop_slogan') || 'لصيانة وبرمجة الهواتف الذكية';
  const phone = localStorage.getItem('default_shop_phone') || '772315106';
  const address = localStorage.getItem('default_shop_address') || 'صنعاء، اليمن';

  printWindow.document.write(`
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <title>${title} - ${shopName}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap');
          
          body {
            font-family: "Tajawal", "Cairo", sans-serif;
            background-color: #ffffff;
            color: #111111;
            margin: 0;
            padding: 24px;
            direction: rtl;
            font-size: 12px;
          }

          /* Header Styling */
          .print-header {
            border-bottom: 3px double #000000;
            padding-bottom: 12px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
          }

          .brand-box {
            text-align: right;
          }

          .brand-title {
            font-size: 18px;
            font-weight: 800;
            margin: 0 0 4px 0;
            color: #000000;
          }

          .brand-slogan {
            font-size: 11px;
            color: #444444;
            margin: 0;
          }

          .meta-box {
            text-align: left;
            font-size: 11px;
            color: #333333;
            line-height: 1.5;
          }

          .meta-box h3 {
            margin: 0 0 6px 0;
            font-size: 14px;
            font-weight: 800;
            color: #111;
          }

          /* Main Title */
          .doc-title {
            text-align: center;
            font-size: 15px;
            font-weight: 700;
            background-color: #f1f2f5;
            padding: 8px;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid #e1e2e5;
            letter-spacing: 0.5px;
          }

          /* Tables */
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          th {
            background-color: #111111 !important;
            color: #ffffff !important;
            font-weight: 700;
            text-align: right;
            padding: 8px 10px;
            border: 1px solid #111;
            font-size: 11px;
          }

          td {
            padding: 8px 10px;
            border: 1px solid #dddddd;
            font-size: 11px;
            color: #222222;
          }

          tr:nth-child(even) {
            background-color: #f8fafc;
          }

          .font-mono {
            font-family: monospace;
            font-size: 11px;
          }

          /* Utility styles */
          .text-center { text-align: center; }
          .text-left { text-align: left; }
          .text-right { text-align: right; }
          .font-bold { font-weight: bold; }
          .text-emerald-600 { color: #16a34a !important; }
          .text-red-600 { color: #dc2626 !important; }
          .text-amber-500 { color: #d97706 !important; }
          .text-sky-600 { color: #0284c7 !important; }

          .badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 9px;
            border: 1px solid #ccc;
          }

          /* Card summary panels */
          .grid-summary {
            display: grid;
            grid-template-cols: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 20px;
          }

          .summary-card {
            border: 1px solid #cccccc;
            padding: 10px;
            border-radius: 6px;
            background-color: #fafafa;
          }

          .summary-card label {
            font-size: 9px;
            color: #666;
            display: block;
            margin-bottom: 4px;
          }

          .summary-card span {
            font-size: 13px;
            font-weight: bold;
            color: #000;
          }

          /* Footer */
          .print-footer {
            margin-top: 40px;
            border-top: 1px dashed #666;
            padding-top: 10px;
            text-align: center;
            font-size: 10px;
            color: #666666;
            display: flex;
            justify-content: space-between;
          }

          @media print {
            body { padding: 0px; }
            .no-print { display: none !important; }
            button { display: none !important; }
          }
        </style>
      </head>
      <body>
        <!-- Header -->
        <div class="print-header">
          <div class="brand-box">
            <h1 class="brand-title">${shopName}</h1>
            <p class="brand-slogan">${slogan}</p>
            <p style="margin: 4px 0 0 0; font-size: 10px; color: #555;">العنوان: ${address} | تليفون: ${phone}</p>
          </div>
          <div class="meta-box">
            <h3>مستند محاسبي رسمي</h3>
            <p><strong>التاريخ:</strong> ${new Date().toLocaleString('ar-YE')}</p>
            <p><strong>نوع التقرير:</strong> ${title}</p>
          </div>
        </div>

        <!-- Document Title Banner -->
        <div class="doc-title">
          ${title}
        </div>

        <!-- Printed Content Container -->
        <div id="print-main-content">
          ${clone.innerHTML}
        </div>

        <!-- Footer signatures and note -->
        <div class="print-footer">
          <span>جهة إعداد المستند: قسم التدقيق والعمليات</span>
          <span>توقيع المالك الاستشاري: ____________________</span>
          <span>تمت الطباعة بنجاح عبر نظام الهوية اليمني الموحد 🇾🇪</span>
        </div>

        <script>
          // Automatically invoke print and then close popup window
          window.focus();
          setTimeout(function() {
            window.print();
            // Optional: window.close();
          }, 350);
        </script>
      </body>
    </html>
  `);
  printWindow.document.close();
}
