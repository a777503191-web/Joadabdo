/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  UserProfile,
  InventoryItem,
  Sale,
  ReturnFlow,
  PurchaseInvoice,
  B2BOrder,
  MaintenanceJob,
  FinancialTransaction,
  AccountNode,
  ActivityLog,
  DamagedItem
} from './types';

// Initial Users
export const initialUsers: UserProfile[] = [
  {
    uid: 'user-owner',
    name: 'أبو جود المالك',
    email: 'owner@jam.com',
    role: 'owner',
    status: 'active',
    ownerId: 'shop-jam-pro',
    phone: '+967770000001',
    hierarchyLevel: 3, // Wholesaler
    custodyBalance: 0,
    trustedDevices: ['HWID-DESKTOP-1', 'HWID-MOBILE-XA'],
    maxDevices: 3,
    isLifetime: true,
    subscriptionType: 'paid',
    subscriptionEndDate: '2030-12-31'
  },
  {
    uid: 'user-manager',
    name: 'المهندس أحمد (المدير المالي)',
    email: 'manager@jam.com',
    role: 'manager',
    status: 'active',
    ownerId: 'shop-jam-pro',
    phone: '+967770000002',
    custodyBalance: 0,
    trustedDevices: ['HWID-LAPTOP-DEV'],
    maxDevices: 1
  },
  {
    uid: 'user-sales',
    name: 'محمد الصنعاني (مبيعات)',
    email: 'sales@jam.com',
    role: 'sales',
    status: 'active',
    ownerId: 'shop-jam-pro',
    phone: '+967770000003',
    custodyBalance: 0
  },
  {
    uid: 'user-engineer',
    name: 'علي الفني (مهندس الصيانة)',
    email: 'eng@jam.com',
    role: 'engineer',
    status: 'active',
    ownerId: 'shop-jam-pro',
    phone: '+967770000004',
    custodyBalance: 0
  }
];

// Initial Inventory
export const initialInventory: InventoryItem[] = [];

// Initial Sales
export const initialSales: Sale[] = [];

// Initial Return Flow
export const initialReturns: ReturnFlow[] = [];

// Initial Purchases
export const initialPurchases: PurchaseInvoice[] = [];

// Initial B2B Orders
export const initialB2BOrders: B2BOrder[] = [];

// Initial Maintenance Jobs
export const initialMaintenance: MaintenanceJob[] = [];

// Initial Financial Transactions
export const initialFinancialTransactions: FinancialTransaction[] = [];

// Initial Chart nodes or tree accounts
export const initialAccounts: AccountNode[] = [
  { id: 'acc-1', name: 'الصندوق النقدي العام', code: '1101', type: 'asset', balance: 0 },
  { id: 'acc-2', name: 'بنك الكريمي المحمول', code: '1102', type: 'asset', balance: 0 },
  { id: 'acc-3', name: 'محفظة يمن كاش', code: '1103', type: 'asset', balance: 0 },
  { id: 'acc-4', name: 'صرافة النجم الدولي', code: '1104', type: 'asset', balance: 0 },
  { id: 'acc-5', name: 'ذمم الموردين الدائنة', code: '2101', type: 'liability', balance: 0 },
  { id: 'acc-6', name: 'ذمم العملاء المدينة', code: '1201', type: 'asset', balance: 0 }
];

// Initial Activity Logs
export const initialLogs: ActivityLog[] = [];

// Load and Save helpers using state keys in localStorage
export function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const saved = localStorage.getItem(`jam_${key}`);
    return saved ? JSON.parse(saved) : defaultValue;
  } catch (err) {
    return defaultValue;
  }
}

export function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(`jam_${key}`, JSON.stringify(value));
  } catch (err) {
    console.error('Failed to save to localStorage:', err);
  }
}
