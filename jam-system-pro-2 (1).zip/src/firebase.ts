/**
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);

// CRITICAL: The app will break without custom firestoreDatabaseId loading
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// Validate Connection to Firestore on boot as per strict skill directives
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("🚀 Firebase connected successfully to projectairy-storm-707pf!");
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("⚠️ Firebase client appears to be offline. Verify credentials inside firebase-applet-config.json");
    } else {
      console.log("ℹ️ Firebase Firestore initialized.");
    }
  }
}

testConnection();
