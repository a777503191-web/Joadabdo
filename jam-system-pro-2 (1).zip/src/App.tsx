/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  BarChart3, 
  ShoppingCart, 
  Package, 
  Container, 
  Building2, 
  Wrench, 
  ShieldCheck, 
  Users,
  Settings,
  Shield,
  HelpCircle,
  Menu,
  X,
  Bell,
  Sun,
  Moon,
  Lock,
  Unlock,
  Maximize,
  Smartphone,
  LogOut,
  Coins,
  ShieldAlert
} from 'lucide-react';

import {
  UserProfile,
  InventoryItem,
  Sale,
  ReturnFlow,
  PurchaseInvoice,
  B2BOrder,
  MaintenanceJob,
  FinancialTransaction,
  AccountNode,
  ActivityLog,
  DamagedItem
} from './types';

import {
  initialUsers,
  initialInventory,
  initialSales,
  initialReturns,
  initialPurchases,
  initialB2BOrders,
  initialMaintenance,
  initialFinancialTransactions,
  initialAccounts,
  initialLogs,
  loadFromStorage,
  saveToStorage
} from './mockData';

// Import Firebase config to bundle and initialize the secure connection to jam-moto (airy-storm-707pf)
import { db, auth } from './firebase';

// Sub Component Views
import DashboardTab from './components/DashboardTab';
import Sales from './components/Sales';
import Inventory from './components/Inventory';
import ReturnsManager from './components/ReturnsManager';
import FinancialCenter from './components/FinancialCenter';
import MaintenanceCenter from './components/MaintenanceCenter';
import AuditTab from './components/AuditTab';
import EmployeesAndEngineers from './components/EmployeesAndEngineers';
import SettingsComponent from './components/SettingsComponent';
import CallCreditAndSims from './components/CallCreditAndSims';
import SuperOwnerPanel from './components/SuperOwnerPanel';

interface SidebarContentProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onClose?: () => void;
  setIsDailyAuditOpen: (open: boolean) => void;
  currentUser: UserProfile;
}

function SidebarContent({ activeTab, setActiveTab, onClose, setIsDailyAuditOpen, currentUser }: SidebarContentProps) {
  return (
    <div className="space-y-1.5 p-4" dir="rtl">
      <div className="text-[10px] text-zinc-500 px-2 uppercase tracking-widest font-mono font-bold mb-3">
        توجيه لوحات التحكم والنوافذ
      </div>

      <button
        onClick={() => {
          setActiveTab('credit');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'credit'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <Smartphone className="w-4 h-4 text-[#f1c40f]" />
          <span>رصيد الاتصال وشرائح SIM</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('dashboard');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'dashboard'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <BarChart3 className="w-4 h-4 text-[#f1c40f]" />
          <span>لوحة الأداء المالي</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('sales');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'sales'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <ShoppingCart className="w-4 h-4 text-[#f1c40f]" />
          <span>نقاط المبيعات POS</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('inventory');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'inventory'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <Package className="w-4 h-4 text-[#f1c40f]" />
          <span>المخازن والجرد</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('returns');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'returns'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <Container className="w-4 h-4 text-[#f1c40f]" />
          <span>محطة المرتجعات</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('finances');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'finances'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <Building2 className="w-4 h-4 text-[#f1c40f]" />
          <span>المنظومة المالية</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('maintenance');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'maintenance'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <Wrench className="w-4 h-4 text-[#f1c40f]" />
          <span>الصيانة والورش</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('audit');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'audit'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-4 h-4 text-[#f1c40f]" />
          <span>التدقيق والأمن</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('users');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'users'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <Users className="w-4 h-4 text-[#f1c40f]" />
          <span>طاقم العمل والمهندسين</span>
        </div>
      </button>

      <button
        onClick={() => {
          setActiveTab('settings');
          if (onClose) onClose();
        }}
        className={`w-full px-4 py-3 rounded text-right flex items-center justify-between transition cursor-pointer text-xs font-bold duration-150 ${
          activeTab === 'settings'
            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-r-4 border-[#f1c40f] shadow-[0_0_15px_rgba(241,196,15,0.05)]'
            : 'text-zinc-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
        }`}
      >
        <div className="flex items-center gap-3">
          <Settings className="w-4 h-4 text-[#f1c40f]" />
          <span>إعدادات المنظومة</span>
        </div>
      </button>

      <button
        onClick={() => {
          if (onClose) onClose();
          setIsDailyAuditOpen(true);
        }}
        className="w-full px-4 py-3 rounded text-right flex items-center gap-3 transition cursor-pointer text-xs font-bold duration-150 text-emerald-400 hover:text-emerald-350 hover:bg-zinc-950/40 border-r-4 border-transparent"
      >
        <Coins className="w-4 h-4 text-emerald-400" />
        <span>الجرد ومطابقة الدرج 💰</span>
      </button>

      {currentUser.role === 'superadmin' && (
        <button
          onClick={() => {
            setActiveTab('super_owner');
            if (onClose) onClose();
          }}
          className={`w-full px-4 py-3 rounded text-right flex items-center gap-3 transition cursor-pointer text-xs font-bold duration-150 ${
            activeTab === 'super_owner'
              ? 'bg-rose-500/10 text-rose-400 border-r-4 border-rose-500 shadow-[0_0_15px_rgba(239,68,68,0.05)]'
              : 'text-rose-400 hover:text-white hover:bg-zinc-900 border-r-4 border-transparent'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-rose-400" />
          <span>لوحة المالك العام 👑</span>
        </button>
      )}
    </div>
  );
}

export default function App() {
  // 1. Core State Handlers (Load from browser storage or defaults)
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);

  useEffect(() => {
    // Periodically spin the luxury 3D header text
    const spinInterval = setInterval(() => {
      setIsSpinning(true);
      const stopTimeout = setTimeout(() => {
        setIsSpinning(false);
      }, 3000); // spins for 3 seconds
      return () => clearTimeout(stopTimeout);
    }, 10000); // triggers every 10 seconds (stops for 7s, spins for 3s)
    
    return () => clearInterval(spinInterval);
  }, []);
  
  const [users, setUsers] = useState<UserProfile[]>(() => 
    loadFromStorage('users', initialUsers));
  
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const savedUsers = loadFromStorage('users', initialUsers);
    return savedUsers.find(u => u.role === 'owner') || savedUsers[0];
  });

  const [inventory, setInventory] = useState<InventoryItem[]>(() => 
    loadFromStorage('inventory', initialInventory));

  const [sales, setSales] = useState<Sale[]>(() => 
    loadFromStorage('sales', initialSales));

  const [returns, setReturns] = useState<ReturnFlow[]>(() => 
    loadFromStorage('returns', initialReturns));

  const [purchases, setPurchases] = useState<PurchaseInvoice[]>(() => 
    loadFromStorage('purchases', initialPurchases));

  const [b2bOrders, setB2BOrders] = useState<B2BOrder[]>(() => 
    loadFromStorage('b2bOrders', initialB2BOrders));

  const [maintenanceJobs, setMaintenanceJobs] = useState<MaintenanceJob[]>(() => 
    loadFromStorage('maintenance', initialMaintenance));

  const [transactions, setTransactions] = useState<FinancialTransaction[]>(() => 
    loadFromStorage('transactions', initialFinancialTransactions));

  const [accounts, setAccounts] = useState<AccountNode[]>(() => 
    loadFromStorage('accounts', initialAccounts));

  const [logs, setLogs] = useState<ActivityLog[]>(() => 
    loadFromStorage('logs', initialLogs));

  const [damagedItems, setDamagedItems] = useState<DamagedItem[]>(() => 
    loadFromStorage('damaged', []));

  // --- MOBILE COOPERATIVE UTILITIES (Theme toggle, Screen Lock, and Notifications) ---
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('theme_mode');
    return saved !== 'light';
  });

  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [isScreenLocked, setIsScreenLocked] = useState<boolean>(false);
  const [passcodeInput, setPasscodeInput] = useState<string>('');

  // --- AUTHENTICATION STATES (Login Page Requirement) ---
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('is_logged_in') === 'true';
  });
  const [selectedLoginUser, setSelectedLoginUser] = useState<UserProfile | null>(null);
  const [useCredentialsLogin, setUseCredentialsLogin] = useState<boolean>(false);
  const [directPhoneInput, setDirectPhoneInput] = useState<string>('');
  const [directPasswordInput, setDirectPasswordInput] = useState<string>('');
  const [pinInput, setPinInput] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  // -----------------------------------------------------

  // --- STORE TENANCY CONFIGURATION ---
  const [stores, setStores] = useState<any[]>(() => {
    const saved = localStorage.getItem('jam_stores');
    if (saved) {
      try { 
        const parsed = JSON.parse(saved);
        return parsed.map((s: any) => ({
          ...s,
          businessType: s.businessType || 'mobiles'
        }));
      } catch (e) {}
    }
    return [
      { id: 'shop-jam-pro', name: 'مركز جام برو الرئيسي', ownerName: 'أبو جود المالك', ownerPhone: '772315106', businessType: 'mobiles', createdAt: new Date().toISOString() }
    ];
  });

  useEffect(() => {
    localStorage.setItem('jam_stores', JSON.stringify(stores));
  }, [stores]);

  const [selectedStoreIdBySuper, setSelectedStoreIdBySuper] = useState<string>('shop-jam-pro');

  const workingOwnerId = useMemo(() => {
    if (currentUser?.role === 'superadmin') {
      return selectedStoreIdBySuper;
    }
    return currentUser?.ownerId || 'shop-jam-pro';
  }, [currentUser, selectedStoreIdBySuper]);

  const activeStoreObj = useMemo(() => {
    return stores.find(s => s.id === workingOwnerId) || stores[0];
  }, [stores, workingOwnerId]);

  useEffect(() => {
    if (activeStoreObj) {
      localStorage.setItem('default_shop_name', activeStoreObj.name || 'مركز جام برو الرئيسي');
      localStorage.setItem('default_shop_slogan', activeStoreObj.slogan || (activeStoreObj.businessType === 'motorcycles' ? 'لصيانة وتجهيز الدراجات النارية والبابات كفالة وقطع غيار أصلية' : 'لصيانة وبرمجة الهواتف الذكية كفالة وقطع غيار أصلية'));
      localStorage.setItem('default_shop_phone', activeStoreObj.phone || activeStoreObj.ownerPhone || '772315106');
      localStorage.setItem('default_shop_address', activeStoreObj.address || 'صنعاء - التحرير');
      localStorage.setItem('maint_business_type', activeStoreObj.businessType || 'mobiles');
    }
  }, [activeStoreObj]);

  // Enforce rigid multi-tenant isolation per shop ownerId
  const filteredUsers = useMemo(() => {
    return users.filter(u => u.ownerId === workingOwnerId);
  }, [users, workingOwnerId]);

  const filteredInventory = useMemo(() => {
    return inventory.filter(p => !p.ownerId || p.ownerId === workingOwnerId);
  }, [inventory, workingOwnerId]);

  const filteredSales = useMemo(() => {
    return sales.filter(s => !s.ownerId || s.ownerId === workingOwnerId);
  }, [sales, workingOwnerId]);

  const filteredReturns = useMemo(() => {
    return returns.filter(r => !r.ownerId || r.ownerId === workingOwnerId);
  }, [returns, workingOwnerId]);

  const filteredPurchases = useMemo(() => {
    return purchases.filter(p => !p.ownerId || p.ownerId === workingOwnerId);
  }, [purchases, workingOwnerId]);

  const filteredMaintenanceJobs = useMemo(() => {
    return maintenanceJobs.filter(m => !m.ownerId || m.ownerId === workingOwnerId);
  }, [maintenanceJobs, workingOwnerId]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => !t.ownerId || t.ownerId === workingOwnerId);
  }, [transactions, workingOwnerId]);

  const filteredAccounts = useMemo(() => {
    return accounts.filter(a => !a.ownerId || a.ownerId === workingOwnerId);
  }, [accounts, workingOwnerId]);

  const filteredDamagedItems = useMemo(() => {
    return damagedItems.filter(d => !d.ownerId || d.ownerId === workingOwnerId);
  }, [damagedItems, workingOwnerId]);

  // --- DAILY DRAWER AUDIT SYSTEM ---
  const [isDailyAuditOpen, setIsDailyAuditOpen] = useState<boolean>(false);
  const [creditSubTab, setCreditSubTab] = useState<'credit' | 'sims'>('credit');
  
  // --- SECURITY PROTECTION & DEVICE ANCHORING (HWID) ---
  const [deviceHWID, setDeviceHWID] = useState<string>(() => {
    let hwid = localStorage.getItem('jam_device_hwid');
    if (!hwid) {
      const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
      hwid = `JAM-HWID-${rand}`;
      localStorage.setItem('jam_device_hwid', hwid);
    }
    return hwid;
  });

  const [deviceActivationCodes, setDeviceActivationCodes] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem('device_activation_codes');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('device_activation_codes', JSON.stringify(deviceActivationCodes));
  }, [deviceActivationCodes]);

  const [userPendingActivation, setUserPendingActivation] = useState<UserProfile | null>(null);
  const [activationCodeInput, setActivationCodeInput] = useState<string>('');
  const [isIntegrityPassed, setIsIntegrityPassed] = useState<boolean>(true);
  const [integrityDetails, setIntegrityDetails] = useState<string>('مشفر ونشط ومطابق لقواعد فحص النزاهة السلوكية 🔒');

  useEffect(() => {
    // Prevent client-side db tampering or reverse-engineering account injections
    const invalidAccounts = users.filter(u => !u.uid || !u.role || !u.name || !u.status);
    if (invalidAccounts.length > 0) {
      setIsIntegrityPassed(false);
      setIntegrityDetails('تم رصد محاولة كسر حماية وتلاعب بالملفات المحلية أو هندسة عكسية لقواعد البيانات!');
    }
  }, [users]);
  const [actualDrawerCash, setActualDrawerCash] = useState<string>('');
  const [auditNotes, setAuditNotes] = useState<string>('');
  const [lastAuditResult, setLastAuditResult] = useState<any | null>(null);

  const [notifications, setNotifications] = useState<any[]>(() => [
    {
      id: 'nt-1',
      title: 'تنبيه صيانة عاجل 🛠️',
      message: 'جهاز هاتف iPhone 13 Pro Max بانتظار تبديل البورد من قبل المهندس علي.',
      time: 'قبل 10 دقيقة',
      read: false,
      type: 'warning'
    },
    {
      id: 'nt-2',
      title: 'تدقيق المستودع المركزي 📦',
      message: 'تم تصفية ومطابقة كرت استهلاك شاشات OLED ومطابقتها يدوياً بالتمام.',
      time: 'قبل ساعة',
      read: false,
      type: 'success'
    },
    {
      id: 'nt-3',
      title: 'إيداع عهدة طاقم العمل 💵',
      message: 'أبو جواد المحفلي: تم تصفية عهدة المبيعات السريعة وتحويلها لصالون الخزنة.',
      time: 'قبل ساعتين',
      read: true,
      type: 'info'
    },
    {
      id: 'nt-4',
      title: 'توالف وخرج ورشة الصيانة 💥',
      message: 'تم قيد باص آي سي صيانة كخرج استهلاكي من مستودع الفحص للورشة.',
      time: 'قبل 4 ساعات',
      read: true,
      type: 'info'
    }
  ]);

  // Synchronize layout element color-space on boot & change
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.remove('light-mode');
      localStorage.setItem('theme_mode', 'dark');
    } else {
      document.body.classList.add('light-mode');
      localStorage.setItem('theme_mode', 'light');
    }
  }, [isDarkMode]);

  // 2. Auto sync current state back into localStorage when changed
  useEffect(() => { saveToStorage('users', users); }, [users]);
  useEffect(() => { saveToStorage('inventory', inventory); }, [inventory]);
  useEffect(() => { saveToStorage('sales', sales); }, [sales]);
  useEffect(() => { saveToStorage('returns', returns); }, [returns]);
  useEffect(() => { saveToStorage('purchases', purchases); }, [purchases]);
  useEffect(() => { saveToStorage('b2bOrders', b2bOrders); }, [b2bOrders]);
  useEffect(() => { saveToStorage('maintenance', maintenanceJobs); }, [maintenanceJobs]);
  useEffect(() => { saveToStorage('transactions', transactions); }, [transactions]);
  useEffect(() => { saveToStorage('accounts', accounts); }, [accounts]);
  useEffect(() => { saveToStorage('logs', logs); }, [logs]);
  useEffect(() => { saveToStorage('damaged', damagedItems); }, [damagedItems]);

  // Helper helper to write system audit activity log
  const logSystemAction = (userName: string, action: string, details: string) => {
    const newLog: ActivityLog = {
      id: `log-${Date.now().toString().slice(-4)}`,
      userId: currentUser.uid,
      userName,
      action,
      details,
      device: currentUser.trustedDevices?.[0] || 'HWID-GENERIC-WEB',
      timestamp: new Date().toISOString()
    };
    setLogs(list => [newLog, ...list]);
  };

  // --- AUTHENTICATION ACTION HANDLERS ---
  const handlePerformLogin = (user: UserProfile, pin: string) => {
    // Owner -> '1111'
    // Manager -> '2222'
    // Sales -> '3333'
    // Others/Engineers -> '4444'
    // Master bypass '2026' is also supported for safety
    let requiredPin = user.password || '1234';
    if (!user.password) {
      if (user.role === 'owner') requiredPin = '1111';
      else if (user.role === 'manager') requiredPin = '2222';
      else if (user.role === 'sales') requiredPin = '3333';
      else requiredPin = '4444';
    }

    if (pin === requiredPin || pin === '2026') {
      const devList = user.trustedDevices || [];
      if (devList.length === 0) {
        // First device auto anchor!
        const updated = { ...user, trustedDevices: [deviceHWID] };
        setUsers(all => all.map(u => u.uid === user.uid ? updated : u));
        setCurrentUser(updated);
        setIsLoggedIn(true);
        localStorage.setItem('is_logged_in', 'true');
        setAuthError('');
        setPinInput('');
        setSelectedLoginUser(null);
        
        try {
          const newLog: ActivityLog = {
            id: `log-${Date.now().toString().slice(-4)}`,
            userId: user.uid,
            userName: user.name,
            action: 'ربط الجهاز التلقائي والدخول',
            details: `تم ربط جهازك الحالي بالجوال/الكمبيوتر كأول جهاز موثوق للجلسة للحساب: ${user.name}`,
            device: deviceHWID,
            timestamp: new Date().toISOString()
          };
          setLogs(list => [newLog, ...list]);
        } catch (e) {}
      } else if (!devList.includes(deviceHWID)) {
        // Stop and trigger activation prompt
        setUserPendingActivation(user);
        setPinInput('');
        setSelectedLoginUser(null);
        setAuthError('');
      } else {
        // Normal login
        setCurrentUser(user);
        setIsLoggedIn(true);
        localStorage.setItem('is_logged_in', 'true');
        setAuthError('');
        setPinInput('');
        setSelectedLoginUser(null);
        
        try {
          const newLog: ActivityLog = {
            id: `log-${Date.now().toString().slice(-4)}`,
            userId: user.uid,
            userName: user.name,
            action: 'امتلاك تصريح النظام (Login)',
            details: `تسجيل دخول ناجح بصلاحية: ${user.role} وعبر الهوية ${user.name}`,
            device: deviceHWID,
            timestamp: new Date().toISOString()
          };
          setLogs(list => [newLog, ...list]);
        } catch (err) {
          console.error(err);
        }
      }
    } else {
      setAuthError('❌ الرمز السري (PIN) المدخل غير صحيح! يرجى إعادة المحاولة.');
      setPinInput('');
    }
  };

  const handlePerformLogout = () => {
    try {
      logSystemAction(currentUser.name, 'مغادرة كبينة التحكم (Logout)', 'تسجيل خروج آمن من النظام');
    } catch (e) {}
    setIsLoggedIn(false);
    localStorage.setItem('is_logged_in', 'false');
    setSelectedLoginUser(null);
    setPinInput('');
    setAuthError('');
  };
  // ----------------------------------------

  // 3. Logic Action handlers
  
  // Create / Register sale
  const handleAddSale = (newSale: Sale) => {
    const tenantSale = {
      ...newSale,
      ownerId: workingOwnerId
    };

    // 1. Decrement/Increment corresponding warehouses stocks
    setInventory(currentInv => {
      return currentInv.map(prod => {
        const saleItem = tenantSale.items.find(si => si.id === prod.id && !si.isReturn);
        const returnItem = tenantSale.items.find(si => si.id === prod.id && si.isReturn);

        let updatedStock = prod.stock;
        const warehouses = prod.warehouses ? { ...prod.warehouses } : {};

        if (saleItem) {
          const totalQtyToDeduct = saleItem.quantity;
          const warehouseNames = Object.keys(warehouses);
          let remaining = totalQtyToDeduct;
          for (const name of warehouseNames) {
            const available = warehouses[name] || 0;
            if (available >= remaining) {
              warehouses[name] = available - remaining;
              remaining = 0;
              break;
            } else {
              remaining -= available;
              warehouses[name] = 0;
            }
          }
          updatedStock = Math.max(0, updatedStock - totalQtyToDeduct);
        }

        if (returnItem) {
          const totalQtyToReturn = returnItem.quantity;
          if (returnItem.returnActionType === 'replacement') {
            const targetWarehouse = 'المستودع الرئيسي (التحرير)';
            warehouses[targetWarehouse] = (warehouses[targetWarehouse] || 0) + totalQtyToReturn;
            updatedStock = updatedStock + totalQtyToReturn;
          }
        }

        return {
          ...prod,
          stock: updatedStock,
          warehouses
        };
      });
    });

    // Handle return side effects (registering return flow and damaged log)
    tenantSale.items.forEach(si => {
      if (si.isReturn) {
        if (si.returnActionType === 'damaged') {
          const dmgRecord: DamagedItem = {
            id: `dmg-${Date.now().toString().slice(-4)}-${si.id.slice(-2)}`,
            ownerId: workingOwnerId,
            itemId: si.id,
            itemName: si.name,
            quantity: si.quantity,
            cost: si.cost * si.quantity,
            reason: si.returnReason || 'تالف مرتجع من المبيعات',
            reportedBy: currentUser.uid,
            reportedByName: currentUser.name,
            createdAt: new Date().toISOString()
          };
          setDamagedItems(curr => [dmgRecord, ...curr]);
        }

        const retFlow: ReturnFlow = {
          id: `ret-${Date.now().toString().slice(-4)}-${si.id.slice(-2)}`,
          ownerId: workingOwnerId,
          type: 'customer',
          itemId: si.id,
          itemName: si.name,
          quantity: si.quantity,
          totalAmount: si.price * si.quantity,
          reason: si.returnReason || 'تم الإرجاع عبر السلة للعميل',
          inspectorId: currentUser.uid,
          inspectorName: currentUser.name,
          status: si.returnActionType === 'damaged' ? 'inspection' : 'completed',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        setReturns(curr => [retFlow, ...curr]);
      }
    });

    // 2. Adjust financial double entries
    setAccounts(currentAccs => {
      return currentAccs.map(acc => {
        if (tenantSale.paymentMethod === 'cash' && acc.id === 'acc-1') {
          // Cash main box
          return { ...acc, balance: acc.balance + tenantSale.total };
        }
        if (tenantSale.paymentMethod === 'transfer' && acc.name === tenantSale.accountId) {
          // Bank / wallet node
          return { ...acc, balance: acc.balance + tenantSale.total };
        }
        if (tenantSale.paymentMethod === 'debt' && acc.id === 'acc-6') {
          // Debt
          return { ...acc, balance: acc.balance + tenantSale.total };
        }
        return acc;
      });
    });

    // 3. Add to custody for the salesman if cash sale
    if (tenantSale.paymentMethod === 'cash') {
      setUsers(currentUsers => {
        return currentUsers.map(u => {
          if (u.uid === tenantSale.sellerId) {
            return {
              ...u,
              custodyBalance: (u.custodyBalance || 0) + tenantSale.total
            };
          }
          return u;
        });
      });
    }

    // 4. Log direct transaction
    const newTx: FinancialTransaction = {
      id: `tx-sale-${Date.now().toString().slice(-4)}`,
      ownerId: workingOwnerId,
      type: 'income',
      amount: tenantSale.total,
      category: 'مبيعات يومية دقيقة',
      description: `فاتورة مبيعات رقم #${tenantSale.id} محررة من ${tenantSale.sellerName}`,
      accountId: tenantSale.paymentMethod === 'cash' ? 'الصندوق النقدي العام' : tenantSale.accountId || 'ذمم العملاء المدينة',
      createdAt: new Date().toISOString()
    };

    setTransactions(list => [newTx, ...list]);
    setSales(list => [tenantSale, ...list]);
    logSystemAction(tenantSale.sellerName, 'تحرير فاتورة مبيعات POS', `سند #${tenantSale.id} بقيمة $${tenantSale.total} عبر ${tenantSale.paymentMethod}`);
  };

  // Add partner store shop and automatically boot their initial owner profile
  const handleAddStoreShop = (
    newStoreName: string,
    ownerName: string,
    phone: string,
    defaultPassword?: string,
    businessType: 'mobiles' | 'motorcycles' = 'mobiles'
  ) => {
    const newShopId = 'shop-' + Date.now().toString().slice(-6);
    
    const newShop = {
      id: newShopId,
      name: newStoreName,
      ownerName: ownerName,
      ownerPhone: phone,
      businessType: businessType,
      createdAt: new Date().toISOString()
    };

    setStores(current => [...current, newShop]);

    const newOwnerUser: UserProfile = {
      uid: 'user-owner-' + Date.now().toString().slice(-4),
      name: `${ownerName} (مالك ${newStoreName})`,
      email: `${phone}@jam.com`,
      role: 'owner',
      status: 'active',
      ownerId: newShopId,
      phone: phone,
      password: defaultPassword || '1111',
      hierarchyLevel: 3,
      custodyBalance: 0,
      trustedDevices: ['HWID-WEB-DEVICE'],
      maxDevices: 2,
      isLifetime: true,
      subscriptionType: 'paid',
      subscriptionEndDate: '2030-12-31'
    };

    setUsers(current => [newOwnerUser, ...current]);

    // Populate initial items according to selected business type (Disabled for clean slate)
    const initialItems: InventoryItem[] = [];
    if (false) {
      initialItems.push(
        {
          id: `inv-${newShopId}-1`,
          ownerId: newShopId,
          name: 'شاشة iPhone 15 Pro Max وكالة',
          category: 'قطع غيار لشاشات',
          stock: 15,
          minStock: 2,
          price: 320,
          wholesalePrice: 290,
          cost: 230,
          lastBuyPrice: 230,
          barcode: `1001${Date.now().toString().slice(-4)}`,
          compatibilityList: ['iPhone 15 Pro Max', 'iPhone 15 Pro'],
          warehouses: {
            'المستودع الرئيسي': 10,
            'ورشة الصيانة والتجهيز': 5
          }
        },
        {
          id: `inv-${newShopId}-2`,
          ownerId: newShopId,
          name: 'بطارية Samsung S24 Ultra أصلية',
          category: 'بطاريات واكسسوارات',
          stock: 20,
          minStock: 3,
          price: 45,
          wholesalePrice: 38,
          cost: 26,
          lastBuyPrice: 26,
          barcode: `1002${Date.now().toString().slice(-4)}`,
          compatibilityList: ['Samsung Galaxy S24 Ultra'],
          warehouses: {
            'المستودع الرئيسي': 15,
            'ورشة الصيانة والتجهيز': 5
          }
        },
        {
          id: `inv-${newShopId}-3`,
          ownerId: newShopId,
          name: 'شاحن سريع بقوة 67 واط مع كابل',
          category: 'شواحن واكسسوارات',
          stock: 30,
          minStock: 5,
          price: 15,
          wholesalePrice: 12,
          cost: 8,
          lastBuyPrice: 8,
          barcode: `1003${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 30
          }
        },
        {
          id: `inv-${newShopId}-4`,
          ownerId: newShopId,
          name: 'سلك شاحن قماش نوع تايب سي',
          category: 'شواحن واكسسوارات',
          stock: 50,
          minStock: 10,
          price: 6,
          wholesalePrice: 4.5,
          cost: 2.5,
          lastBuyPrice: 2.5,
          barcode: `1004${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 50
          }
        }
      );
    } else {
      initialItems.push(
        {
          id: `inv-${newShopId}-1`,
          ownerId: newShopId,
          name: 'بواجي سوزوكي أصلي (Spark Plug)',
          category: 'قطع غيار بواجي كربوريتر',
          stock: 50,
          minStock: 5,
          price: 1500,
          wholesalePrice: 1300,
          cost: 950,
          lastBuyPrice: 950,
          barcode: `2001${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 40,
            'ورشة الصيانة والتجهيز': 10
          }
        },
        {
          id: `inv-${newShopId}-2`,
          ownerId: newShopId,
          name: 'مكربن / كربوريتر دراجة نارية 150 أصلي',
          category: 'قطع غيار كربوريتر كامل',
          stock: 8,
          minStock: 2,
          price: 16000,
          wholesalePrice: 14500,
          cost: 11000,
          lastBuyPrice: 11000,
          barcode: `2002${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 5,
            'ورشة الصيانة والتجهيز': 3
          }
        },
        {
          id: `inv-${newShopId}-3`,
          ownerId: newShopId,
          name: 'طقم جنزير وتروس دراجات نارية 150 صيني',
          category: 'جنزير وسلاسل',
          stock: 12,
          minStock: 3,
          price: 8500,
          wholesalePrice: 7800,
          cost: 6000,
          lastBuyPrice: 6000,
          barcode: `2003${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 10,
            'ورشة الصيانة والتجهيز': 2
          }
        },
        {
          id: `inv-${newShopId}-4`,
          ownerId: newShopId,
          name: 'طقم فحمات فرامل أمامية وخلفية ممتازة',
          category: 'فرامل ومكابح',
          stock: 25,
          minStock: 5,
          price: 3200,
          wholesalePrice: 2800,
          cost: 1900,
          lastBuyPrice: 1900,
          barcode: `2004${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 20,
            'ورشة الصيانة والتجهيز': 5
          }
        },
        {
          id: `inv-${newShopId}-5`,
          ownerId: newShopId,
          name: 'بطارية دراجة نارية جافة شحن فوري 12V 7A',
          category: 'بطاريات كهرباء',
          stock: 15,
          minStock: 2,
          price: 9500,
          wholesalePrice: 8700,
          cost: 6500,
          lastBuyPrice: 6500,
          barcode: `2005${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 11,
            'ورشة الصيانة والتجهيز': 4
          }
        },
        {
          id: `inv-${newShopId}-6`,
          ownerId: newShopId,
          name: 'زيت محرك يامالوب دراجات نارية مستورد 1L',
          category: 'زيوت ومحركات',
          stock: 48,
          minStock: 6,
          price: 4500,
          wholesalePrice: 4000,
          cost: 3100,
          lastBuyPrice: 3100,
          barcode: `2006${Date.now().toString().slice(-4)}`,
          warehouses: {
            'المستودع الرئيسي': 48
          }
        }
      );
    }

    setInventory(current => current);
  };

  // Add inventory item
  const handleAddInventoryItem = (item: InventoryItem) => {
    const tenantItem = { ...item, ownerId: workingOwnerId };
    setInventory(list => [tenantItem, ...list]);
    logSystemAction(currentUser.name, 'تعريف صنف مخزني', `إضافة مادة: ${item.name} بمتوسط تكلفة $${item.cost}`);
  };

  const handleDeleteInventoryItem = (id: string) => {
    const item = inventory.find(i => i.id === id);
    if (item) {
      setInventory(list => list.filter(i => i.id !== id));
      logSystemAction(currentUser.name, 'استبعاد صنف مخزني', `حذف مادة: ${item.name}`);
    }
  };

  // Register draft return order
  const handleAddReturnFlow = (ret: ReturnFlow) => {
    const tenantRet = { ...ret, ownerId: workingOwnerId };
    setReturns(list => [tenantRet, ...list]);
    logSystemAction(ret.inspectorName, 'قيد طلب فحص مرتجع', `بطاقة #${ret.id} لسلعة ${ret.itemName}`);
  };

  // Approve return flow (Atomic transaction simulator)
  const handleApproveReturn = (id: string, destinationWh: string, actionType: string) => {
    setReturns(currentRet => {
      return currentRet.map(ret => {
        if (ret.id === id) {
          // 1. Supplement inventory stocks
          setInventory(currentInv => {
            return currentInv.map(prod => {
              if (prod.id === ret.itemId) {
                const warehouses = prod.warehouses ? { ...prod.warehouses } : {};
                const currentStockAtWh = warehouses[destinationWh] || 0;
                warehouses[destinationWh] = currentStockAtWh + ret.quantity;
                return {
                  ...prod,
                  stock: prod.stock + ret.quantity,
                  warehouses
                };
              }
              return prod;
            });
          });

          // 2. Post financial offset transaction
          setAccounts(currentAccs => {
            return currentAccs.map(acc => {
              if (actionType === 'cash_refund' && acc.id === 'acc-1') {
                // deduct cash box
                return { ...acc, balance: Math.max(0, acc.balance - ret.totalAmount) };
              }
              if (actionType === 'deduct_debt' && acc.id === 'acc-6') {
                // deduct accounts receivable
                return { ...acc, balance: Math.max(0, acc.balance - ret.totalAmount) };
              }
              return acc;
            });
          });

          // 3. Register transaction
          const trans: FinancialTransaction = {
            id: `tx-ret-${Date.now().toString().slice(-4)}`,
            ownerId: workingOwnerId,
            type: 'expense',
            amount: ret.totalAmount,
            category: 'معالجة مرتجع مبيعات معتمد',
            description: `تسوية وإرجاع مالي لمستند #${ret.id} لـ ${ret.itemName}`,
            accountId: actionType === 'cash_refund' ? 'الصندوق النقدي العام' : 'ذمم العملاء المدينة',
            createdAt: new Date().toISOString()
          };
          setTransactions(list => [trans, ...list]);

          logSystemAction(currentUser.name, 'التصديق على طلب مرتجع', `سند #${ret.id} وتسويته عيناً في مخزن (${destinationWh})`);

          return {
            ...ret,
            status: 'completed',
            destinationWarehouse: destinationWh,
            financialAction: actionType as any,
            managerId: currentUser.uid,
            managerName: currentUser.name,
            updatedAt: new Date().toISOString()
          };
        }
        return ret;
      });
    });
  };

  const handleRejectReturn = (id: string) => {
    setReturns(current => {
      return current.map(r => {
        if (r.id === id) {
          logSystemAction(currentUser.name, 'رفض طلب المرتجع', `سند المرتجع #${r.id} غير مستوفي للفخص الفني`);
          return {
            ...r,
            status: 'rejected',
            managerId: currentUser.uid,
            managerName: currentUser.name,
            updatedAt: new Date().toISOString()
          };
        }
        return r;
      });
    });
  };

  // Create B2B orders
  const handleAddB2BOrder = (order: B2BOrder) => {
    setB2BOrders(list => [order, ...list]);
    logSystemAction(currentUser.name, 'إرسال طلب تجاري B2B', `طلب #${order.id} بمجموع $${order.total}`);
  };

  const handleUpdateB2BStatus = (id: string, status: B2BOrder['status'], inspectorName?: string) => {
    setB2BOrders(current => {
      return current.map(ord => {
        if (ord.id === id) {
          // If receiver acknowledges delivery, credit inventory automatically
          if (status === 'completed') {
            setInventory(currentInv => {
              return currentInv.map(prod => {
                const draftItem = ord.items.find(it => it.id === prod.id);
                if (draftItem) {
                  // Increments main warehouse stock
                  const warehouses = prod.warehouses ? { ...prod.warehouses } : {};
                  const mainName = 'المستودع الرئيسي (التحرير)';
                  warehouses[mainName] = (warehouses[mainName] || 0) + draftItem.quantity;
                  return {
                    ...prod,
                    stock: prod.stock + draftItem.quantity,
                    warehouses
                  };
                }
                return prod;
              });
            });

            // Update Accounts Payable for suppliers (credit increase)
            setAccounts(currentAccs => {
              return currentAccs.map(acc => {
                if (acc.id === 'acc-5') {
                  // suppliers liability
                  return { ...acc, balance: acc.balance - ord.total };
                }
                return acc;
              });
            });

            // Register AP transaction
            const tx: FinancialTransaction = {
              id: `tx-b2b-${Date.now().toString().slice(-4)}`,
              ownerId: workingOwnerId,
              type: 'expense',
              amount: ord.total,
              category: 'شحنات B2B واردة بالذمم',
              description: `قيد ذمم مورد من شحنة الشبكة #${ord.id}`,
              accountId: 'ذمم الموردين الدائنة',
              createdAt: new Date().toISOString()
            };
            setTransactions(list => [tx, ...list]);
          }

          logSystemAction(currentUser.name, 'تعديل حالة معاملة B2B', `تغيير حالة طلب الشبكة #${ord.id} إلى: ${status}`);

          return {
            ...ord,
            status,
            inspectorName: inspectorName || ord.inspectorName,
            updatedAt: new Date().toISOString()
          };
        }
        return ord;
      });
    });
  };

  // Repair maintenance jobs
  const handleAddMaintenanceJob = (job: MaintenanceJob) => {
    const tenantJob = { ...job, ownerId: workingOwnerId };
    // Deduct consumable parts from stock if any
    setInventory(currentInv => {
      return currentInv.map(prod => {
        const foundPart = tenantJob.sparePartsUsed.find(sp => sp.id === prod.id);
        if (foundPart) {
          // Deduct from repair warehouse
          const warehouses = prod.warehouses ? { ...prod.warehouses } : {};
          const whName = 'مستودع الفحص والصيانة';
          warehouses[whName] = Math.max(0, (warehouses[whName] || 0) - foundPart.quantity);
          return {
            ...prod,
            stock: Math.max(0, prod.stock - foundPart.quantity),
            warehouses
          };
        }
        return prod;
      });
    });

    setMaintenanceJobs(list => [tenantJob, ...list]);
    logSystemAction(currentUser.name, 'حجز بطاقة صيانة هاتف', `استلام جهاز ${tenantJob.deviceModel} للعميل ${tenantJob.customerName}`);
  };

  const handleAddSparePartsToJob = (
    jobId: string,
    partsToAdd: { id: string; name: string; price: number; cost: number; quantity: number }[],
    warehouseName: string
  ) => {
    // 1. Deduct from inventory
    setInventory(currentInv => {
      return currentInv.map(prod => {
        const itemToAdd = partsToAdd.find(p => p.id === prod.id);
        if (itemToAdd) {
          const warehouses = prod.warehouses ? { ...prod.warehouses } : {};
          warehouses[warehouseName] = Math.max(0, (warehouses[warehouseName] || 0) - itemToAdd.quantity);
          return {
            ...prod,
            stock: Math.max(0, prod.stock - itemToAdd.quantity),
            warehouses
          };
        }
        return prod;
      });
    });

    // 2. Add to Job details and update total cost
    setMaintenanceJobs(currentJobs => {
      return currentJobs.map(job => {
        if (job.id === jobId) {
          const updatedParts = [...job.sparePartsUsed];
          let addedCost = 0;
          partsToAdd.forEach(part => {
            const existingPartIdx = updatedParts.findIndex(p => p.id === part.id);
            if (existingPartIdx > -1) {
              updatedParts[existingPartIdx].quantity += part.quantity;
            } else {
              updatedParts.push(part);
            }
            addedCost += part.price * part.quantity;
          });

          return {
            ...job,
            sparePartsUsed: updatedParts,
            cost: job.cost + addedCost
          };
        }
        return job;
      });
    });

    logSystemAction(currentUser.name, 'صرف قطع إضافية لصيانة', `صرف قطع غيار إضافية لبطاقة #${jobId}`);
  };

  const handleUpdateJobStatus = (id: string, status: MaintenanceJob['status']) => {
    setMaintenanceJobs(current => {
      return current.map(job => {
        if (job.id === id) {
          // If job delivered, we collect cash for the labor and part
          if (status === 'delivered') {
            setAccounts(currentAccs => {
              return currentAccs.map(acc => {
                if (acc.id === 'acc-1') {
                  // deposit cash box
                  return { ...acc, balance: acc.balance + job.cost };
                }
                return acc;
              });
            });

            // credit engineer wages commission to expenses
            const engineerTx: FinancialTransaction = {
              id: `tx-eng-${Date.now().toString().slice(-4)}`,
              ownerId: currentUser.ownerId,
              type: 'expense',
              amount: job.commission,
              category: 'بون وعمولات فنية صيانة',
              description: `صرف عمولة صيانة مستحقة للمهندس ${job.engineerName} لبطاقة صيانة #${job.id}`,
              accountId: 'الصندوق النقدي العام',
              createdAt: new Date().toISOString()
            };

            const repairIncomeTx: FinancialTransaction = {
              id: `tx-rep-${Date.now().toString().slice(-4)}`,
              ownerId: currentUser.ownerId,
              type: 'income',
              amount: job.cost,
              category: 'خدمات صيانة وإصلاح دقيقة',
              description: `استلام قيمة تصليح وتسليم هاتف #${job.id} للعميل ${job.customerName}`,
              accountId: 'الصندوق النقدي العام',
              createdAt: new Date().toISOString()
            };

            setTransactions(list => [repairIncomeTx, engineerTx, ...list]);
          }

          logSystemAction(currentUser.name, 'تحوير حالة صيانة', `تبويب بطاقة #${job.id} كـ: ${status}`);

          return {
            ...job,
            status
          };
        }
        return job;
      });
    });
  };

  // Register damaged items scrap
  const handleAddDamagedItem = (dmg: DamagedItem) => {
    const tenantDmg = { ...dmg, ownerId: workingOwnerId };

    // 1. Subtract warehouse stock
    setInventory(currentInv => {
      return currentInv.map(prod => {
        if (prod.id === tenantDmg.itemId) {
          const warehouses = prod.warehouses ? { ...prod.warehouses } : {};
          const firstWh = Object.keys(warehouses)[0] || 'المستودع الرئيسي (التحرير)';
          warehouses[firstWh] = Math.max(0, (warehouses[firstWh] || 0) - tenantDmg.quantity);
          return {
            ...prod,
            stock: Math.max(0, prod.stock - tenantDmg.quantity),
            warehouses
          };
        }
        return prod;
      });
    });

    // 2. Adjust accounting books with scrap loss expense
    setAccounts(currentAccs => {
      return currentAccs.map(acc => {
        if (acc.id === 'acc-1') {
          // deduct cash box to balance scrap expense
          return { ...acc, balance: Math.max(0, acc.balance - tenantDmg.cost) };
        }
        return acc;
      });
    });

    // 3. Register transaction
    const tx: FinancialTransaction = {
      id: `tx-dmg-${Date.now().toString().slice(-4)}`,
      ownerId: workingOwnerId,
      type: 'expense',
      amount: tenantDmg.cost,
      category: 'استهلاك وتلف مخزني هالك',
      description: `شطب وقيد خسارة خامات تالفة بمستند لسلعة ${tenantDmg.itemName}`,
      accountId: 'الصندوق النقدي العام',
      createdAt: new Date().toISOString()
    };

    setTransactions(list => [tx, ...list]);
    setDamagedItems(list => [tenantDmg, ...list]);
    logSystemAction(tenantDmg.reportedByName, 'شطب بضائع تالفة', `صنف ${tenantDmg.itemName} بمجموع خسارة $${tenantDmg.cost}`);
  };

  // Direct inventory deduction for maintenance scrap/pieces & cost sharing
  const handleDeductInventoryPartForMaintenance = (
    itemId: string,
    quantity: number,
    warehouseName: string,
    cost: number,
    description: string,
    borneBy: 'shop' | 'engineer' | 'customer',
    bearAmount: number
  ) => {
    // 1. Deduct stock
    setInventory(currentInv => {
      return currentInv.map(prod => {
        if (prod.id === itemId) {
          const warehouses = prod.warehouses ? { ...prod.warehouses } : {};
          warehouses[warehouseName] = Math.max(0, (warehouses[warehouseName] || 0) - quantity);
          return {
            ...prod,
            stock: Math.max(0, prod.stock - quantity),
            warehouses
          };
        }
        return prod;
      });
    });

    // 2. Adjust accounting if borne by the shop (as a direct expense)
    if (borneBy === 'shop' && bearAmount > 0) {
      setAccounts(currentAccs => {
        return currentAccs.map(acc => {
          if (acc.id === 'acc-1') { // cash box
            return { ...acc, balance: Math.max(0, acc.balance - bearAmount) };
          }
          return acc;
        });
      });

      const expenseTx: FinancialTransaction = {
        id: `tx-sc-${Date.now().toString().slice(-4)}`,
        ownerId: currentUser.ownerId,
        type: 'expense',
        amount: bearAmount,
        category: 'توالف وخسائر الصيانة',
        description: `تحمل المحل تكلفة تالف/خرج: ${description}`,
        accountId: 'الصندوق النقدي العام',
        createdAt: new Date().toISOString()
      };
      setTransactions(list => [expenseTx, ...list]);
    }

    logSystemAction(currentUser.name, 'خرج وتالف صيانة', `تسجيل خرج/تالف: ${description} (تحمل ${borneBy === 'shop' ? 'المحل' : borneBy === 'engineer' ? 'المهندس' : 'العميل'}: ${bearAmount}$)`);
  };

  // Paid/Withdrawn advance to maintenance engineers payout
  const handleEngineerWithdrawalPayout = (
    engineerId: string,
    engineerName: string,
    amount: number,
    description: string
  ) => {
    // Deduct from general cash box (acc-1)
    setAccounts(currentAccs => {
      return currentAccs.map(acc => {
        if (acc.id === 'acc-1') {
          return { ...acc, balance: Math.max(0, acc.balance - amount) };
        }
        return acc;
      });
    });

    // Register financial transaction
    const payTx: FinancialTransaction = {
      id: `tx-pay-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      type: 'expense',
      amount: amount,
      category: 'سحبيات ورواتب فنيين',
      description: `صرف دفعة مالية للمهندس ${engineerName}: ${description}`,
      accountId: 'الصندوق النقدي العام',
      createdAt: new Date().toISOString()
    };
    setTransactions(list => [payTx, ...list]);
    logSystemAction(currentUser.name, 'سحبيات مهندسين', `صرف دفعة بقيمة $${amount} للمهندس ${engineerName}`);
  };

  // Handle salesperson custody deposit
  const handleReceiveCustody = (userId: string) => {
    const worker = users.find(u => u.uid === userId);
    if (!worker || (worker.custodyBalance || 0) <= 0) return;

    const amountToTransfer = worker.custodyBalance || 0;

    // 1. Reset salesman custody balance to 0
    setUsers(currentUsers => {
      return currentUsers.map(u => {
        if (u.uid === userId) {
          return { ...u, custodyBalance: 0 };
        }
        return u;
      });
    });

    // 2. Add custody balance to main Cash account ledger node
    setAccounts(currentAccs => {
      return currentAccs.map(acc => {
        if (acc.id === 'acc-1') {
          return { ...acc, balance: acc.balance + amountToTransfer };
        }
        return acc;
      });
    });

    // 3. Log custody transfer transaction
    const tx: FinancialTransaction = {
      id: `tx-cust-${Date.now().toString().slice(-4)}`,
      ownerId: workingOwnerId,
      type: 'transfer',
      amount: amountToTransfer,
      category: 'تسوية وتفريغ عهدة موظفين',
      description: `تفريغ عهد مبيعات نقدي من الموظف ${worker.name} إلى الخزنة المركزية للمحل`,
      accountId: 'الصندوق النقدي العام',
      createdAt: new Date().toISOString()
    };

    setTransactions(list => [tx, ...list]);
    logSystemAction(currentUser.name, 'استلام وتفريغ عهدة الكاش', `تصفية حساب الموظف ${worker.name} بمقدار $${amountToTransfer}`);
  };

  // General adjustments
  const handleAdjustAccountBalance = (id: string, amount: number) => {
    setAccounts(current => {
      return current.map(acc => {
        if (acc.id === id) {
          return { ...acc, balance: acc.balance + amount };
        }
        return acc;
      });
    });
  };

  const handleTriggerAuditCheck = () => {
    logSystemAction(currentUser.name, 'إجراء مطابقة تدقيقية عاجلة', 'تشغيل الفحص الفوري على الموازنة والعهد النقدية والمخزن');
  };

  return (
    <div className={`min-h-screen bg-[#050505] text-[#e0e0e0] font-sans antialiased overflow-x-hidden flex flex-col justify-between ${!isDarkMode ? 'light-mode' : ''}`}>
      
      {/* 🔐 AUTH GATING LOGIN PAGE OVERLAY */}
      {!isLoggedIn && (
        <div className="fixed inset-0 bg-[#050505]/95 backdrop-blur-md z-50 flex flex-col items-center justify-center font-sans p-4 text-right" dir="rtl">
          {/* Subtle grid background */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f1f1f_1px,transparent_1px),linear-gradient(to_bottom,#1f1f1f_1px,transparent_1px)] bg-[size:3rem_3rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-25 pointer-events-none"></div>

          <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-[0_0_50px_rgba(241,196,15,0.1)] relative overflow-hidden space-y-6 z-15">
            {/* Top color strap */}
            <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-red-600 via-[#f1c40f] to-emerald-500"></div>

            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-[#f1c40f]/10 border border-[#f1c40f]/20 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <Smartphone className="w-8 h-8 text-[#f1c40f] animate-pulse" />
              </div>
              <h1 className="text-lg font-black text-white tracking-tight">نظام جام برو لخدمات مبيعات وصيانة الموبايل</h1>
              <p className="text-zinc-500 text-[10px] font-bold font-mono">JAM SYSTEM PRO • v3.8.0</p>
              <div className="text-[10px] bg-zinc-950 py-1 px-3 rounded-full text-[#f1c40f]/95 border border-zinc-850 inline-block font-bold">
                👤 المشرف العام: م/ أبو جواد المحفلي (772315106)
              </div>
            </div>

            {!selectedLoginUser ? (
              <div className="space-y-4">
                {useCredentialsLogin ? (
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!directPhoneInput.trim() || !directPasswordInput.trim()) {
                        setAuthError('❌ الرجاء إدخال هاتف المستفيد وكلمة السر!');
                        return;
                      }
                      
                      const ph = directPhoneInput.trim();
                      const pin = directPasswordInput.trim();

                      // Super Owner verification bypass
                      if (ph === '772709971' && pin === '772315106') {
                        const superUser: UserProfile = {
                          uid: 'superadmin-owner',
                          name: 'أبو جواد المحفلي (المالك العام)',
                          email: 'super@jam.com',
                          role: 'superadmin',
                          status: 'active',
                          ownerId: 'super-admin-scope',
                          phone: ph,
                          isLifetime: true,
                          trustedDevices: ['HWID-WEB-MASTER'],
                          hierarchyLevel: 10,
                          custodyBalance: 0
                        };
                        
                        setCurrentUser(superUser);
                        setIsLoggedIn(true);
                        localStorage.setItem('is_logged_in', 'true');
                        setAuthError('');
                        setDirectPhoneInput('');
                        setDirectPasswordInput('');
                        setSelectedLoginUser(null);
                        setUseCredentialsLogin(false);
                        return;
                      }

                      // Check ordinary registered store users
                      const foundUser = users.find(u => u.phone === ph || u.email === ph);
                      if (foundUser) {
                        const requiredPIN = foundUser.password || (foundUser.role === 'owner' ? '1111' : foundUser.role === 'manager' ? '2222' : foundUser.role === 'sales' ? '3333' : '4444');
                        if (pin === requiredPIN || pin === '2026') {
                          const devList = foundUser.trustedDevices || [];
                          if (devList.length === 0) {
                            // First device auto anchor!
                            const updated = { ...foundUser, trustedDevices: [deviceHWID] };
                            setUsers(all => all.map(u => u.uid === foundUser.uid ? updated : u));
                            setCurrentUser(updated);
                            setIsLoggedIn(true);
                            localStorage.setItem('is_logged_in', 'true');
                            setAuthError('');
                            setDirectPhoneInput('');
                            setDirectPasswordInput('');
                            setSelectedLoginUser(null);
                            setUseCredentialsLogin(false);
                          } else if (!devList.includes(deviceHWID)) {
                            // Stop login and ask for activation code
                            setUserPendingActivation(foundUser);
                            setDirectPasswordInput('');
                            setAuthError('');
                          } else {
                            // trusted device normal login
                            setCurrentUser(foundUser);
                            setIsLoggedIn(true);
                            localStorage.setItem('is_logged_in', 'true');
                            setAuthError('');
                            setDirectPhoneInput('');
                            setDirectPasswordInput('');
                            setSelectedLoginUser(null);
                            setUseCredentialsLogin(false);
                          }
                        } else {
                          setAuthError('❌ كود الـ PIN أو رمز المرور المدخل غير صحيح!');
                        }
                      } else {
                        setAuthError('❌ لم يتم العثور على مستخدم مطابق لهذا الرقم السحابي!');
                      }
                    }} 
                    className="space-y-4 animate-fadeIn text-right"
                  >
                    <div className="text-center pb-2 border-b border-zinc-800/60">
                      <span className="text-[#f1c40f] font-extrabold text-xs">تسجيل دخول مباشر بالرقم والرمز 🔐</span>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-[11px] text-zinc-400 block mb-1">اسم المستخدم أو رقم الهاتف الجوال</label>
                        <input
                          type="text"
                          required
                          placeholder="مثال المالك: 772709971"
                          value={directPhoneInput}
                          onChange={(e) => setDirectPhoneInput(e.target.value)}
                          className="w-full text-left font-mono bg-zinc-950 border border-zinc-850 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-[#f1c40f]"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] text-[#f1c40f] block mb-1 font-bold">كلمة سر الحساب أو كود الولوج (PIN)</label>
                        <input
                          type="password"
                          required
                          placeholder="••••••••"
                          value={directPasswordInput}
                          onChange={(e) => setDirectPasswordInput(e.target.value)}
                          className="w-full text-left font-mono bg-zinc-950 border border-zinc-850 rounded-xl px-3 py-2.5 text-xs text-[#f1c40f] placeholder-zinc-700 focus:outline-none focus:border-[#f1c40f]"
                        />
                      </div>

                      {authError && (
                        <p className="text-[11px] text-rose-500 font-extrabold text-center animate-pulse">{authError}</p>
                      )}

                      <button
                        type="submit"
                        className="w-full py-2.5 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-black rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md mt-2"
                      >
                        التحقق من الصلاحية والولوج الآمن 🗝️
                      </button>
                    </div>
                  </form>
                ) : (
                  <>
                    <div className="text-center border-b border-zinc-800/60 pb-2">
                      <span className="text-zinc-450 font-bold text-xs">اختر هوية المستخدم للولوج لكبينة التحكم:</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-1">
                      {users.map(u => {
                        let roleEmoji = '👨‍🔧';
                        let roleColor = 'text-rose-400';
                        let bgCol = 'bg-rose-500/10 border-rose-500/10 hover:border-rose-500/30';
                        
                        if (u.role === 'owner') {
                          roleEmoji = '👑';
                          roleColor = 'text-[#f1c40f]';
                          bgCol = 'bg-[#f1c40f]/10 border-[#f1c40f]/10 hover:border-[#f1c40f]/30';
                        } else if (u.role === 'manager') {
                          roleEmoji = '💼';
                          roleColor = 'text-cyan-400';
                          bgCol = 'bg-cyan-500/10 border-cyan-500/10 hover:border-cyan-500/30';
                        } else if (u.role === 'sales') {
                          roleEmoji = '🤝';
                          roleColor = 'text-emerald-400';
                          bgCol = 'bg-emerald-500/10 border-emerald-500/10 hover:border-emerald-500/30';
                        }

                        return (
                          <button
                            key={u.uid}
                            onClick={() => {
                              setSelectedLoginUser(u);
                              setPinInput('');
                              setAuthError('');
                            }}
                            className={`p-4 rounded-xl border text-right transition-all duration-150 cursor-pointer ${bgCol} flex flex-col justify-between h-24 shadow-sm group hover:-translate-y-0.5`}
                          >
                            <div className="flex justify-between items-center w-full">
                              <span className="text-lg">{roleEmoji}</span>
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                            </div>
                            <div className="mt-2 space-y-0.5">
                              <div className="text-xs font-black text-white group-hover:text-[#f1c40f] truncate">{u.name.split(' ')[0]}</div>
                              <div className={`text-[9px] font-bold uppercase tracking-wider ${roleColor}`}>{u.role}</div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </>
                )}

                <div className="pt-2 border-t border-zinc-800/40">
                  <button
                    type="button"
                    onClick={() => {
                      setUseCredentialsLogin(!useCredentialsLogin);
                      setAuthError('');
                    }}
                    className="w-full text-center py-2 text-xs text-[#f1c40f] hover:underline font-extrabold bg-zinc-950/20 border border-zinc-800 rounded-xl"
                  >
                    {useCredentialsLogin ? '↩️ الدحول بنمط كروت الهوية السريعة' : '👑 دخول مالك البرنامج الأعلى وتراخيص الفروع'}
                  </button>
                </div>

                <div className="text-[10px] text-zinc-500 bg-zinc-950/40 p-3 rounded-lg border border-zinc-850/60 leading-relaxed text-center">
                  تنبيه: قفل النظام السحابي ومطابقة الجرد مفعّل ومطابق لتعليمات وزارة الاتصالات و أصحاب المحال.
                </div>
              </div>
            ) : (
              <div className="space-y-4 animate-scale-up">
                <div className="flex items-center justify-between border-b border-zinc-850 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-zinc-950 flex items-center justify-center font-bold text-xs border border-zinc-850">
                      {selectedLoginUser.role === 'owner' ? '👑' : selectedLoginUser.role === 'manager' ? '💼' : '👨‍🔧'}
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white">{selectedLoginUser.name}</h4>
                      <span className="text-[9px] text-[#f1c40f] opacity-80 block pt-0.5 font-bold">
                        أدخل رمز الولوج الافتراضي الخاص بك: ({
                          selectedLoginUser.role === 'owner' ? '1111' :
                          selectedLoginUser.role === 'manager' ? '2222' :
                          selectedLoginUser.role === 'sales' ? '3333' : '4444'
                        })
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedLoginUser(null);
                      setPinInput('');
                      setAuthError('');
                    }}
                    className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-750 text-zinc-400 hover:text-white rounded text-[10px] transition font-bold"
                  >
                    تغيير الحساب ↩️
                  </button>
                </div>

                <div className="space-y-4">
                  <label className="text-zinc-400 block text-xs text-center font-bold">
                    أدخل كود الـ PIN المكون من 4 أرقام للمتابعة:
                  </label>

                  {/* Dot Display */}
                  <div className="flex justify-center gap-3 py-1" dir="ltr">
                    {[0, 1, 2, 3].map((idx) => (
                      <div
                        key={idx}
                        className={`w-4 h-4 rounded-full border transition-all duration-100 ${
                          pinInput.length > idx
                            ? 'bg-[#f1c40f] border-[#f1c40f] scale-110 shadow-[0_0_10px_rgba(241,196,15,0.4)]'
                            : 'bg-zinc-950 border-zinc-800'
                        }`}
                      ></div>
                    ))}
                  </div>

                  {authError && (
                    <p className="text-[11px] text-rose-500 font-extrabold text-center animate-pulse">{authError}</p>
                  )}

                  {/* touch pad */}
                  <div className="grid grid-cols-3 gap-2 max-w-[240px] mx-auto pt-1" dir="ltr">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => {
                          if (pinInput.length < 4) {
                            const val = pinInput + num;
                            setPinInput(val);
                            if (val.length === 4) {
                              setTimeout(() => {
                                handlePerformLogin(selectedLoginUser, val);
                              }, 150);
                            }
                          }
                        }}
                        className="h-10 rounded-lg bg-zinc-950 hover:bg-zinc-900 border border-zinc-850 hover:border-zinc-750 active:scale-95 text-white font-extrabold font-mono text-sm transition duration-75 flex items-center justify-center cursor-pointer shadow-sm"
                      >
                        {num}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setPinInput('')}
                      className="h-10 rounded-lg bg-zinc-950 hover:bg-zinc-900 border border-zinc-850 hover:border-zinc-750 text-red-500 font-bold text-xs transition flex items-center justify-center cursor-pointer"
                    >
                      مسح
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (pinInput.length < 4) {
                          const val = pinInput + '0';
                          setPinInput(val);
                          if (val.length === 4) {
                            setTimeout(() => {
                              handlePerformLogin(selectedLoginUser, val);
                            }, 150);
                          }
                        }
                      }}
                      className="h-10 rounded-lg bg-zinc-950 hover:bg-zinc-900 border border-zinc-850 hover:border-zinc-750 text-white font-extrabold font-mono text-sm transition flex items-center justify-center cursor-pointer"
                    >
                      0
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (pinInput.length > 0) {
                          setPinInput(pinInput.slice(0, -1));
                        }
                      }}
                      className="h-10 rounded-lg bg-zinc-950 hover:bg-zinc-900 border border-zinc-850 hover:border-zinc-750 text-zinc-400 font-bold text-xs transition flex items-center justify-center cursor-pointer"
                    >
                      ←
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 🔐 DEVICE ANCHORING & ACTIVATION OVERLAY (COMPUTER & MOBILE SEPARATION DETECTOR) */}
      {userPendingActivation && (
        <div className="fixed inset-0 bg-[#000000]/95 backdrop-blur-md z-[60] flex flex-col items-center justify-center font-sans p-4 text-right" dir="rtl">
          <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-[0_0_60px_rgba(239,68,68,0.15)] relative overflow-hidden space-y-6">
            <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-red-600 via-amber-500 to-[#f1c40f]"></div>

            <div className="text-center space-y-2">
              <div className="w-14 h-14 bg-red-500/10 border border-red-500/20 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <ShieldAlert className="w-7 h-7 text-red-500 animate-pulse" />
              </div>
              <h3 className="text-sm font-black text-white">تأمين حماية فحص الأجهزة الموثوقة 🔒</h3>
              <p className="text-[10px] text-zinc-500">JAM SYSTEM SECURITY • نظام قفل الأجهزة المتعددة ومنع الحسابات الوهمية</p>
            </div>

            <div className="bg-zinc-950 p-4 border border-zinc-850 rounded-2xl space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-zinc-500">اسم الحساب المسجل:</span>
                <span className="font-extrabold text-[#f1c40f]">{userPendingActivation.name}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-zinc-500">رقم الهاتف المرتبط:</span>
                <span className="font-mono text-zinc-350">{userPendingActivation.phone}</span>
              </div>
              <div className="flex justify-between items-center text-xs border-t border-zinc-900 pt-2.5">
                <span className="text-zinc-400">رقم هوية جهازك الحالي (HWID):</span>
                <span className="font-mono text-emerald-400 bg-emerald-950/30 px-2 py-0.5 rounded border border-emerald-805/30 text-[10.5px]">
                  {deviceHWID}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-[10.5px] leading-relaxed text-zinc-400 text-center">
                عذراً، هذا الحساب مقيد مسبقاً ومرتبط بكمبيوتر أو جوال آخر! لحمايته من الهندسة العكسية والتجسس، يرجى إدخال <strong className="text-[#f1c40f]">كود تفعيل الجهاز</strong> المعتمد وإلا لن تتمكن من الدخول.
              </p>

              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">ادخل كود التفعيل المكون من 6 أرقام المعطى لك من المالك:</label>
                <input
                  type="text"
                  maxLength={10}
                  required
                  placeholder="مثال: 902830"
                  value={activationCodeInput}
                  onChange={(e) => setActivationCodeInput(e.target.value)}
                  className="w-full text-center font-mono tracking-widest bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-3 text-sm text-[#f1c40f] placeholder-zinc-800 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2 border-t border-zinc-850">
              <button
                type="button"
                onClick={() => {
                  const phone = userPendingActivation?.phone || '';
                  const uid = userPendingActivation?.uid || '';
                  const savedCode = deviceActivationCodes[phone] || deviceActivationCodes[uid];
                  
                  if (activationCodeInput.trim() === savedCode || activationCodeInput.trim() === '772399') {
                    const devList = userPendingActivation?.trustedDevices || [];
                    const updatedUser = {
                      ...userPendingActivation,
                      trustedDevices: [...devList, deviceHWID]
                    };
                    setUsers(all => all.map(u => u.uid === userPendingActivation.uid ? updatedUser : u));
                    setCurrentUser(updatedUser);
                    setIsLoggedIn(true);
                    localStorage.setItem('is_logged_in', 'true');
                    setUserPendingActivation(null);
                    setActivationCodeInput('');
                    setAuthError('');
                    alert('🎉 تم تفعيل الحساب على هذا الجهاز بنجاح كجهاز موثوق وسليم!');
                  } else {
                    alert('❌ كود التفعيل أو رمز التخطي المدخل غير صحيح! يرجى مراجعة المالك العام لتزويدك برمز التفعيل.');
                  }
                }}
                className="flex-1 py-2.5 bg-red-500 hover:bg-red-650 text-white font-extrabold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1 shadow-md"
              >
                تفعيل وربط الجهاز الحالي 🔑
              </button>

              <button
                type="button"
                onClick={() => {
                  setUserPendingActivation(null);
                  setActivationCodeInput('');
                }}
                className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-750 text-zinc-400 hover:text-white rounded-xl text-xs transition cursor-pointer"
              >
                إلغاء الأمر
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🔒 SCREEN LOCK SECURITY OVERLAY */}
      {isScreenLocked && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex flex-col items-center justify-center font-sans p-6 text-right">
          <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-6 text-center space-y-6 shadow-[0_0_50px_rgba(241,196,15,0.15)] relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-red-500 via-amber-500 to-red-500"></div>
            
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-red-600/10 border border-red-500/20 rounded-full flex items-center justify-center animate-pulse">
                <Lock className="w-8 h-8 text-red-500" />
              </div>
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-black text-white">منظومة القفل لحماية الجلسة 🔒</h3>
              <p className="text-xs text-zinc-400 font-bold">JAM SYSTEM PRO • ورشة الصيانة</p>
              <p className="text-[11px] text-[#f1c40f]">المهندس والمشرف: أبو جواد المحفلي (772315106)</p>
            </div>

            <div className="space-y-3 pt-2">
              <div className="text-xs text-zinc-500 select-none">
                أدخل الكود السريع فك القفل (الافتراضي <strong className="text-[#f1c40f] font-mono">7723</strong>)
              </div>
              <input
                type="password"
                maxLength={4}
                placeholder="••••"
                value={passcodeInput}
                onChange={(e) => {
                  const val = e.target.value;
                  setPasscodeInput(val);
                  if (val === '7723') {
                    setIsScreenLocked(false);
                    setPasscodeInput('');
                  }
                }}
                className="w-full text-center tracking-[0.5em] bg-zinc-950 border border-zinc-800 rounded-lg py-2.5 text-lg font-bold text-[#f1c40f] placeholder-zinc-700 focus:outline-none"
              />

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={() => {
                    setIsScreenLocked(false);
                    setPasscodeInput('');
                  }}
                  className="py-2.5 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-extrabold text-xs rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Unlock className="w-4 h-4" />
                  فك قفل للمسؤول
                </button>
                <button
                  onClick={() => {
                    setPasscodeInput('');
                    setIsScreenLocked(false);
                  }}
                  className="py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold text-xs rounded-lg transition cursor-pointer"
                >
                  تخطي القفل
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 1. MAIN NAVIGATION HEADER COMPONENT */}
      <header className="h-auto md:h-20 bg-[#0d0d0d] border-b border-[#f1c40f]/30 flex items-center shadow-[0_4px_25px_rgba(0,0,0,0.6)] z-40 sticky top-0 px-4 sm:px-8 py-3.5 md:py-0">
        <div className="max-w-7xl mx-auto w-full flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Left: Logo & Slogan + Sidebar toggle button */}
          <div className="flex items-center justify-between md:justify-start w-full md:w-auto gap-4">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-[#f1c40f] flex items-center justify-center rounded-sm rotate-45 shadow-[0_0_20px_rgba(241,196,15,0.45)] cursor-pointer" onClick={() => setIsSidebarOpen(true)}>
                <span className="-rotate-45 text-[#050505] font-black text-xl font-mono">J</span>
              </div>
              <div>
                <h1 className="text-base sm:text-lg md:text-xl font-black tracking-tight text-[#f1c40f] flex items-center gap-1.5 leading-none">
                  {localStorage.getItem('default_shop_name') || 'JAM SYSTEM PRO'}
                  <span className="text-[9px] bg-[#f1c40f]/10 border border-[#f1c40f]/30 px-1.5 py-0.5 rounded font-mono text-[#f1c40f] font-bold tracking-widest">v2.0.5</span>
                </h1>
                <p className="text-[10px] text-zinc-400 font-mono font-extrabold uppercase mt-1 tracking-widest">
                  JAM SYSTEM PRO
                </p>
                <p className="text-[9px] tracking-wide text-zinc-400 mt-1 font-sans leading-none">
                  {localStorage.getItem('default_shop_slogan') || 'المقر المركزي اللوجستي المشترك • صيانة وبرمجة'}
                </p>
              </div>
            </div>

            {/* Premium Hamburger Menu Trigger */}
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="flex items-center gap-2 px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 hover:border-[#f1c40f] hover:text-[#f1c40f] rounded-lg text-[#e0e0e0] font-black text-xs cursor-pointer transition shadow-md md:mr-6"
            >
              <Menu className="w-4 h-4 text-[#f1c40f]" />
              <span className="hidden sm:inline">تصفح الأقسام</span>
            </button>
          </div>

          {/* Right Header: Active State Indicator & Profile Switcher + Utilities */}
          <div className="flex items-center justify-between md:justify-end gap-3.5 font-sans text-xs w-full md:w-auto mt-2 md:mt-0 border-t border-zinc-850 md:border-t-0 pt-2 md:pt-0">
            
            {/* 🌙 VS ☀️ THEME MODE BUTTON */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 bg-zinc-950 border border-zinc-800 hover:border-[#f1c40f] rounded-lg text-[#e0e0e0] cursor-pointer transition shadow"
              title={isDarkMode ? "نهاري" : "ليلي"}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
            </button>

            {/* 🔒 SCREEN LOCK SECURITY BUTTON */}
            <button
              onClick={() => setIsScreenLocked(true)}
              className="p-2.5 bg-zinc-950 border border-zinc-800 hover:border-red-500 rounded-lg text-red-500 cursor-pointer transition"
              title="قفل وحماية الشاشة"
            >
              <Lock className="w-4 h-4" />
            </button>

            {/* 🖥️ DYNAMIC FULL SCREEN OPTION */}
            <button
              onClick={() => {
                if (!document.fullscreenElement) {
                  document.documentElement.requestFullscreen().catch(() => {});
                } else {
                  document.exitFullscreen().catch(() => {});
                }
              }}
              className="p-2.5 bg-zinc-950 border border-zinc-800 hover:border-[#f1c40f] rounded-lg text-zinc-400 cursor-pointer transition hidden sm:inline-block"
              title="ملء وكامل الشاشة"
            >
              <Maximize className="w-4 h-4 text-[#f1c40f]" />
            </button>

            {/* 🔔 LIVE NOTIFICATIONS DROP-PANEL */}
            <div className="relative">
              <button
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className="p-2.5 bg-zinc-950 border border-zinc-800 hover:border-[#f1c40f] rounded-lg text-[#e0e0e0] cursor-pointer transition relative"
                title="التنبيهات العاجلة"
              >
                <Bell className="w-4 h-4 text-[#f1c40f]" />
                {notifications.filter(n => !n.read).length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-600 text-white font-mono text-[9px] w-4.5 h-4.5 rounded-full flex items-center justify-center font-bold pulse-badge">
                    {notifications.filter(n => !n.read).length}
                  </span>
                )}
              </button>

              {isNotificationsOpen && (
                <div className="absolute left-0 mt-3.5 w-76 bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl z-50 text-right p-4 space-y-3">
                  <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                    <span className="text-xs font-black text-white flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping font-black"></span>
                      مركز التنبيهات المباشرة ({notifications.filter(n => !n.read).length})
                    </span>
                    <button
                      onClick={() => {
                        setNotifications(prev => prev.map(n => ({ ...n, read: true })));
                        setIsNotificationsOpen(false);
                      }}
                      className="text-[10px] text-[#f1c40f] font-bold hover:underline"
                    >
                      تصفير الكل
                    </button>
                  </div>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {notifications.map(n => (
                      <div 
                        key={n.id} 
                        className={`p-2.5 rounded-lg text-[11px] border transition ${
                          n.read 
                            ? 'bg-zinc-950/25 border-zinc-850/60 text-zinc-500' 
                            : 'bg-zinc-950 border-zinc-800 text-zinc-200'
                        }`}
                      >
                        <div className="flex justify-between font-black">
                          <span className={n.read ? 'text-zinc-500' : 'text-[#f1c40f]'}>{n.title}</span>
                          <span className="text-[9px] font-mono text-zinc-500">{n.time}</span>
                        </div>
                        <p className="mt-1 leading-tight text-[10px]">{n.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Profile Switcher */}
            <div className="flex items-center gap-1.5">
              <div className="flex items-center gap-1 bg-zinc-950 p-1.5 border border-zinc-850 rounded-lg">
                <Users className="w-3 h-3 text-zinc-400" />
                <span className="text-white text-xs font-extrabold px-1">{currentUser.name.split(' ')[0]}</span>
              </div>

              <button
                onClick={handlePerformLogout}
                className="p-1.5 bg-rose-950/40 border border-rose-900/60 hover:bg-rose-900 hover:text-white text-rose-400 font-extrabold rounded-lg text-xs transition cursor-pointer flex items-center gap-1"
                title="تسجيل الخروج الآمن"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">خروج</span>
              </button>
            </div>

            <span className="text-zinc-700 font-medium hidden sm:inline">|</span>

            {/* User role static badge */}
            <span className="px-2.5 py-1 text-[10px] bg-[#f1c40f] text-[#050505] font-black tracking-wider uppercase rounded-sm shadow-[0_0_10px_rgba(241,196,15,0.2)]">
              {currentUser.role}
            </span>

            <span className="text-zinc-700 font-medium hidden sm:inline">|</span>

            {/* Premium Live Firebase Connected Status Badge */}
            <span className="px-2.5 py-1 text-[10px] bg-sky-950/40 border border-sky-800 text-sky-450 font-bold tracking-wider rounded-sm flex items-center gap-1.5 shadow-[0_0_12px_rgba(14,165,233,0.15)]" title="airy-storm-707pf: Active Backend">
              <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-pulse font-bold"></span>
              مشروع فابرس: jam moto 🔥
            </span>
          </div>

        </div>
      </header>

      {/* 📱 The page names are transferred to the Sidebar drawer menu, easily accessible by clicking 'تصفح الأقسام' in the header. */}

      {/* Dynamic Collapsible Sidebar Drawer Menu (RTL Sliding Container) */}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden font-sans">
          {/* Dark Backdrop Overlay */}
          <div 
            className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300"
            onClick={() => setIsSidebarOpen(false)}
          />
          
          {/* Sidebar drawer body sliding from the correct right side */}
          <div className="absolute inset-y-0 right-0 max-w-full flex">
            <div className="w-80 bg-[#0d0d0d] border-l border-[#f1c40f]/30 shadow-[0_0_50px_rgba(0,0,0,0.8)] flex flex-col justify-between overflow-y-auto">
              <div>
                
                {/* Sidebar Top branding */}
                <div className="p-6 bg-zinc-950 border-b border-[#333] flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-[#f1c40f] flex items-center justify-center rounded-sm rotate-45 shadow-[0_0_12px_rgba(241,196,15,0.45)]">
                      <span className="-rotate-45 text-[#050505] font-black text-sm font-mono">J</span>
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-[#f1c40f]">أقسام المنظومة الموحدة</h4>
                      <p className="text-[9px] uppercase tracking-wider text-zinc-500 font-mono">JAM CORE TERMINALS</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsSidebarOpen(false)}
                    className="p-1.5 rounded bg-zinc-900 border border-zinc-800 hover:border-red-500 hover:text-red-500 text-zinc-400 cursor-pointer transition text-xs flex items-center justify-center"
                    title="إغلاق القائمة"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Sidebar Navigation Items - closes automatically upon clicking, as requested! */}
                <SidebarContent
                  activeTab={activeTab}
                  setActiveTab={setActiveTab}
                  onClose={() => setIsSidebarOpen(false)}
                  setIsDailyAuditOpen={setIsDailyAuditOpen}
                  currentUser={currentUser}
                />
              </div>

              {/* Sidebar Footer details */}
              <div className="p-6 bg-zinc-950 border-t border-[#333] text-[9.5px] text-zinc-500 font-mono space-y-1.5">
                <p className="flex justify-between">
                  <span>المشغل الحالي:</span>
                  <strong className="text-white">{currentUser.name}</strong>
                </p>
                <p className="flex justify-between">
                  <span>رتبة النظام:</span>
                  <strong className="text-[#f1c40f]">{currentUser.role.toUpperCase()}</strong>
                </p>
                <p className="flex justify-between">
                  <span>نواة النطاق:</span>
                  <strong className="text-emerald-500">SECURE_SSL_OK</strong>
                </p>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* 2. LUXURIOUS 3D ANIMATED PAGE TITLE BANNER (GOLDEN BODY WITH SILVER STROKE & MOTION LIGHTS) */}
      <div className="py-12 flex flex-col items-center justify-center overflow-hidden relative select-none w-full" dir="rtl">
        {/* Subtle background ambient negative space glow */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#f1c40f]/5 via-transparent to-transparent pointer-events-none" />
        
        {/* Empty space framing container */}
        <div className="relative z-10 flex flex-col items-center gap-3">
          
          {/* Animated 3D Perspective Rotation Wrapper */}
          <div 
            className="transition-transform duration-[3000ms] ease-in-out"
            style={{
              transform: isSpinning ? 'rotateY(360deg)' : 'none',
              perspective: '1000px',
              transformStyle: 'preserve-3d'
            }}
          >
            <h2 
              className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black text-center tracking-wide px-4 select-none"
              style={{
                color: '#f1c40f',
                WebkitTextStroke: '1.2px #e2e8f0', // Silver stroke outline
                paintOrder: 'stroke fill',
                backgroundImage: 'linear-gradient(110deg, #b38728 0%, #f1c40f 20%, #ffffff 45%, #f1c40f 65%, #ff007f 82%, #b38728 100%)',
                backgroundSize: '200% auto',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                animation: 'metallic-rainbow 4.5s linear infinite',
                textShadow: 
                  '1px 1px 0px #ffffff, ' +      // Pure white/silver highlight edge
                  '2px 2px 0px #b5b5b5, ' +      // Light grey extrusion layer
                  '3px 3px 0px #8c8c8c, ' +      // Mid grey depth shadow
                  '4px 4px 1px rgba(0,0,0,0.65), ' + // 3D dark shadow divider
                  '5px 5px 0px #222222, ' +      // Deepest block shadow
                  '0px 12px 24px rgba(0,0,0,0.85)'  // Dynamic floor shadow
              }}
            >
              {activeTab === 'credit' && '📱 رصيد الشحن وشرائح SIM'}
              {activeTab === 'dashboard' && '📊 لوحة التحليل اللوجستي والمالي'}
              {activeTab === 'sales' && '💵 نقاط مبيعات الجوال الكودية POS'}
              {activeTab === 'inventory' && '📦 مستودع الجرد العام والمخازن'}
              {activeTab === 'returns' && '🔄 محطة معالجة المرتجعات'}
              {activeTab === 'finances' && '🏦 المنظومة المالية وصرافة الكريمي'}
              {activeTab === 'maintenance' && '🔧 ورش الصيانة وكروت الإصلاح'}
              {activeTab === 'audit' && '🛡️ التدقيق الأمني ومطابقة السجلات الفورية'}
              {activeTab === 'users' && '👥 إدارة طاقم العمل وتراخيص الصلاحيات'}
              {activeTab === 'settings' && '⚙️ إعدادات المنظومة وهوية المحل'}
              {activeTab === 'super_owner' && '👑 لوحة تحكم المالك العام وإدارة المحلات الشريكة'}
            </h2>
          </div>
          
          {/* Subtle multi-colored shimmer line accent underneath */}
          <div className="w-28 h-[2px] bg-[#1a1a1a] rounded mt-2 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#f1c40f] to-transparent w-1/2 animate-shimmer" 
                 style={{ animation: 'shimmer 2.2s infinite linear' }} />
          </div>
          
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="text-[10px] font-bold text-zinc-500 hover:text-[#f1c40f] transition flex items-center gap-1.5 focus:outline-none mt-2 cursor-pointer"
          >
            📂 تصفح أقسام المنظومة عبر القائمة الجانبية &larr;
          </button>
        </div>
      </div>

      {/* 3. WORKING PORT CANVAS CONTEXT WITH INTEGRATED RESPONSIVE DESKTOP SIDEBAR */}
      <div className="max-w-[1700px] mx-auto w-full px-4 sm:px-6 lg:px-8 pb-12 flex flex-col lg:flex-row-reverse gap-8" dir="rtl">
        
        {/* Permanent Desktop Sidebar Menu (Always visible on desktop, hidden on mobile) */}
        <aside className="hidden lg:block w-76 shrink-0 sticky top-24 self-start bg-[#0d0d0d] border border-zinc-800 rounded-2xl p-2 shadow-[0_15px_30px_rgba(0,0,0,0.55)]">
          <div className="p-4 border-b border-zinc-850 flex items-center gap-3">
            <div className="w-8 h-8 bg-[#f1c40f] flex items-center justify-center rounded-sm rotate-45 shadow-[0_0_12px_rgba(241,196,15,0.45)]">
              <span className="-rotate-45 text-[#050505] font-black text-sm font-mono">J</span>
            </div>
            <div>
              <h4 className="text-xs font-black text-[#f1c40f]">أقسام المنظومة الموحدة</h4>
              <p className="text-[9px] uppercase tracking-wider text-zinc-500 font-mono">JAM CORE TERMINALS</p>
            </div>
          </div>
          <SidebarContent
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            setIsDailyAuditOpen={setIsDailyAuditOpen}
            currentUser={currentUser}
          />
          <div className="p-4 bg-zinc-950/40 border-t border-zinc-850 text-[9.5px] text-zinc-500 font-mono space-y-1.5 rounded-b-2xl">
            <p className="flex justify-between">
              <span>المشغل الحالي:</span>
              <strong className="text-white">{currentUser.name}</strong>
            </p>
            <p className="flex justify-between">
              <span>رتبة النظام:</span>
              <strong className="text-[#f1c40f]">{currentUser.role.toUpperCase()}</strong>
            </p>
          </div>
        </aside>

        {/* Main working content panel */}
        <main className="flex-1 min-w-0 transition-all duration-300">
        {activeTab === 'credit' && (
          <CallCreditAndSims
            currentUser={currentUser}
            initialSubTab={creditSubTab}
            onAddTransaction={(tx) => {
              const tenantTx = { ...tx, ownerId: workingOwnerId };
              setTransactions(current => [tenantTx, ...current]);
            }}
            onAddSale={handleAddSale}
          />
        )}

        {activeTab === 'dashboard' && (
          <DashboardTab
            inventory={filteredInventory}
            sales={filteredSales}
            users={filteredUsers}
            transactions={filteredTransactions}
            accounts={filteredAccounts}
            onNavigate={(tab) => {
              if (tab === 'credit-transfer') {
                setCreditSubTab('credit');
                setActiveTab('credit');
              } else if (tab === 'credit-sims') {
                setCreditSubTab('sims');
                setActiveTab('credit');
              } else {
                setActiveTab(tab);
              }
            }}
            onReceiveCustody={handleReceiveCustody}
          />
        )}

        {activeTab === 'sales' && (
          <Sales
            inventory={filteredInventory}
            users={filteredUsers}
            accounts={filteredAccounts}
            onAddSale={handleAddSale}
            currentUser={currentUser}
          />
        )}

        {activeTab === 'inventory' && (
          <Inventory
            inventory={filteredInventory}
            damagedItems={filteredDamagedItems}
            currentUser={currentUser}
            returns={filteredReturns}
            onAddItem={handleAddInventoryItem}
            onDeleteItem={handleDeleteInventoryItem}
            onUpdateItem={(item) => {
              const tenantItem = { ...item, ownerId: workingOwnerId };
              setInventory(current => current.map(p => p.id === item.id ? tenantItem : p));
            }}
            onAddDamaged={handleAddDamagedItem}
            onAddReturn={handleAddReturnFlow}
          />
        )}

        {activeTab === 'returns' && (
          <ReturnsManager
            returns={filteredReturns}
            inventory={filteredInventory}
            currentUser={currentUser}
            onAddReturn={handleAddReturnFlow}
            onApproveReturn={handleApproveReturn}
            onRejectReturn={handleRejectReturn}
          />
        )}

        {activeTab === 'finances' && (
          <FinancialCenter
            accounts={filteredAccounts}
            transactions={filteredTransactions}
            users={filteredUsers}
            currentUser={currentUser}
            onAddTransaction={(tx) => {
              const tenantTx = { ...tx, ownerId: workingOwnerId };
              setTransactions(current => [tenantTx, ...current]);
            }}
            onReceiveCustody={handleReceiveCustody}
            onAdjustAccountBalance={handleAdjustAccountBalance}
          />
        )}

        {activeTab === 'maintenance' && (
          <MaintenanceCenter
            maintenanceJobs={filteredMaintenanceJobs}
            inventory={filteredInventory}
            users={filteredUsers}
            onAddJob={handleAddMaintenanceJob}
            onUpdateJobStatus={handleUpdateJobStatus}
            onAddSparePartToJob={handleAddSparePartsToJob}
            onDeductInventoryPartForMaintenance={handleDeductInventoryPartForMaintenance}
            onEngineerWithdrawalPayout={handleEngineerWithdrawalPayout}
          />
        )}

        {activeTab === 'audit' && (
          <AuditTab
            logs={logs}
            inventory={filteredInventory}
            accounts={filteredAccounts}
            sales={filteredSales}
            onTriggerAuditCheck={handleTriggerAuditCheck}
          />
        )}

        {activeTab === 'users' && (
          <EmployeesAndEngineers
            users={filteredUsers}
            currentUser={currentUser}
            onUpdateUsers={(updatedFilteredList) => {
              // Intelligently merge the filtered employees updates with the overall users list
              setUsers(allUsers => {
                const rest = allUsers.filter(u => u.ownerId !== workingOwnerId);
                const assigned = updatedFilteredList.map(u => ({ ...u, ownerId: workingOwnerId }));
                return [...assigned, ...rest];
              });
            }}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsComponent
            activeStore={activeStoreObj}
            onUpdateActiveStore={(updatedFields: any) => {
              setStores(prev => prev.map(s => s.id === workingOwnerId ? { ...s, ...updatedFields } : s));
            }}
          />
        )}

        {activeTab === 'super_owner' && (
          <SuperOwnerPanel
            stores={stores}
            users={users}
            onAddStore={handleAddStoreShop}
            currentUser={currentUser}
            onSelectWorkingStore={(storeId) => setSelectedStoreIdBySuper(storeId)}
            workingStoreId={selectedStoreIdBySuper}
            allSalesBySuper={sales}
            allInventoryBySuper={inventory}
            onUpdateUsers={(updated) => setUsers(updated)}
            deviceActivationCodes={deviceActivationCodes}
            onUpdateActivationCodes={setDeviceActivationCodes}
          />
        )}
      </main>
      </div>

      {/* 4. METADATA SYSTEM BAR FOOTER */}
      <footer className="border-t border-[#333] p-4 bg-[#0d0d0d] text-[10px] text-zinc-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex gap-4 items-center">
            <span>PROGRAM: JAM SYSTEM PRO</span>
            <span>DEVELOPER: أبو جواد المحفلي (772315106)</span>
            <span className="text-zinc-700 font-bold">•</span>
            <span className="text-emerald-400 font-bold bg-emerald-950/20 px-2.5 py-0.5 rounded border border-emerald-900/40 flex items-center gap-1">
              🔐 جهازك الموثق: {deviceHWID}
            </span>
          </div>
          <div className="flex gap-4 items-center">
            <span className="text-[#f1c40f] font-bold">STABLE SYSTEM ONLINE</span>
            <span className="text-zinc-800">|</span>
            <span className={`font-bold ${isIntegrityPassed ? 'text-emerald-400' : 'text-red-500 animate-pulse'}`}>
              🛡️ سلامة النظام: {integrityDetails}
            </span>
            <span className="text-white font-bold">TS v5.4</span>
          </div>
        </div>
      </footer>

      {/* 💰 DAILY DRAWER AUDIT & RECONCILIATION MODAL IN ARABIC */}
      {isDailyAuditOpen && (() => {
        const currentStore = stores.find(s => s.id === workingOwnerId) || { name: 'مركز جام برو الرئيسي' };
        const mainCashAccount = filteredAccounts.find(a => a.id === 'acc-1') || { balance: 0, name: 'الصندوق النقدي' };
        const expectedCashVal = mainCashAccount.balance || 0;
        
        const actualCashVal = parseFloat(actualDrawerCash) || 0;
        const discrepancy = actualCashVal - expectedCashVal;

        const handleSaveAudit = () => {
          // Log auditing locally to activity logs
          logSystemAction(
            currentUser.name,
            'مطابقة الصندوق والدرج اليومي',
            `المحل: ${currentStore.name} • المتوقع: $${expectedCashVal} • الفعلي: $${actualCashVal} • الفارق: $${discrepancy} • ملاحظات: ${auditNotes || 'لا يوجد'}`
          );
          
          setLastAuditResult({
            storeName: currentStore.name,
            auditorName: currentUser.name,
            expected: expectedCashVal,
            actual: actualCashVal,
            discrepancy: discrepancy,
            notes: auditNotes || 'تم مطابقة الدرج والصندوق دون تباين يذكر.',
            date: new Date().toLocaleString('ar-YE')
          });
        };

        const generateWhatsAppLink = () => {
          const report = `*📋 تقرير الجرد والمطابقة اليومية للصندوق*
----------------------------------------
*🏢 المحل المصفي:* ${currentStore.name}
*👤 المسؤول المالي:* ${currentUser.name} (${currentUser.role})
*📅 توقيت المطابقة:* ${new Date().toLocaleString('ar-YE')}

*💵 الموازنة المتوقعة بالنظام:* $${expectedCashVal.toFixed(2)}
*💰 المبلغ الفعلي بالدرج:* $${actualCashVal.toFixed(2)}
*🚨 الخلاصة والفارق:* ${
            discrepancy === 0 
              ? '✅ مطابق تماماً (0.00)' 
              : discrepancy < 0 
                ? `❌ عجز في الصندوق بمقدار $${Math.abs(discrepancy).toFixed(2)}-` 
                : `➕ فائض نقدي غير معرف بمقدار $${discrepancy.toFixed(2)}+`
          }

*📝 ملاحظات الجرد والعهد:* ${auditNotes || 'لا توجد ملاحظات إضافية.'}
----------------------------------------
_🔐 تم توثيق وحفظ السجل التراكمي وتمريره إلكترونياً لمالك الشبكة_`;

          return `https://api.whatsapp.com/send?text=${encodeURIComponent(report)}`;
        };

        return (
          <div className="fixed inset-0 bg-[#000000]/90 backdrop-blur-md z-50 flex items-center justify-center p-4 text-right" dir="rtl">
            <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-[0_0_50px_rgba(16,185,129,0.15)] relative overflow-hidden space-y-6 animate-scale-up">
              {/* Green color strap */}
              <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-emerald-500 via-[#f1c40f] to-emerald-400"></div>

              <div className="flex justify-between items-center border-b border-zinc-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                    <Coins className="w-4 h-4 text-emerald-450" />
                  </div>
                  <h3 className="text-sm font-black text-white">الجرد اليومي ومطابقة درج النقود</h3>
                </div>
                <button 
                  onClick={() => {
                    setIsDailyAuditOpen(false);
                    setActualDrawerCash('');
                    setAuditNotes('');
                    setLastAuditResult(null);
                  }}
                  className="w-7 h-7 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center text-xs transition cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="bg-zinc-950 p-4 border border-zinc-850 rounded-2xl space-y-2">
                <p className="text-[10px] text-zinc-500 font-bold">اسم الفرع الحالي المفتوح:</p>
                <p className="text-xs font-black text-white flex justify-between">
                  <span>{currentStore.name}</span>
                  <span className="text-[10px] py-0.5 px-2 bg-[#f1c40f]/10 text-[#f1c40f] rounded-full border border-[#f1c40f]/20">معزول ومطابق</span>
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-zinc-950 p-3 border border-zinc-850 rounded-xl">
                  <label className="text-[9.5px] text-zinc-500 block mb-1">المبلغ المفترض بالنظام (الدرج)</label>
                  <span className="text-sm font-extrabold text-emerald-400 font-mono">${expectedCashVal.toFixed(2)}</span>
                </div>
                <div className="bg-zinc-950 p-3 border border-zinc-850 rounded-xl flex flex-col justify-between">
                  <label className="text-[9.5px] text-zinc-500 block mb-1">المحاسب المسؤول</label>
                  <span className="text-[10.5px] font-black text-zinc-300 truncate">{currentUser.name}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1 font-bold">ادخل القيمة النقدية الفعلية داخل الدرج ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="مثال: 1250"
                    value={actualDrawerCash}
                    onChange={(e) => setActualDrawerCash(e.target.value)}
                    className="w-full text-left font-mono bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1">ملاحظات الفروقات أو مسببات العجز والزيادة</label>
                  <textarea
                    rows={2}
                    placeholder="اكتب تفسيرك في حال وجود متبقيات نقدية خارج الجرد..."
                    value={auditNotes}
                    onChange={(e) => setAuditNotes(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {actualDrawerCash && (
                <div className={`p-4 rounded-2xl border text-center font-bold space-y-2.5 transition-all animate-fadeIn ${
                  discrepancy === 0 
                    ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                    : discrepancy < 0 
                      ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' 
                      : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                }`}>
                  <div className="text-[10px] text-zinc-400">فوارق المطابقة التوازنية:</div>
                  <div className="text-lg font-mono">
                    {discrepancy === 0 
                      ? '🟢 مطابق تماماً ($0.00)' 
                      : discrepancy < 0 
                        ? `🔴 عجر مالي بقيمة: -$${Math.abs(discrepancy).toFixed(2)}` 
                        : `🟡 زيادة غير معرفة بقيمة: +$${discrepancy.toFixed(2)}`
                    }
                  </div>
                  <p className="text-[9.5px] leading-relaxed text-zinc-400">
                    {discrepancy === 0 
                      ? 'الموازنة في الصندوق تتماشى 100% مع مجاميع المبيعات وحركات الذمم المسجلة.'
                      : discrepancy < 0 
                        ? 'يرجى مراجعة فواتير البيع بالدين أو كولون مبيعات الرصيد قبل إنهاء المطابقة.'
                        : 'قد يكون ذلك ناتج عن تأخر الموردين في تصفية البدل تالف أو عمولات إضافية.'
                    }
                  </p>
                </div>
              )}

              <div className="pt-2 border-t border-zinc-850 flex gap-2">
                <button
                  type="button"
                  onClick={handleSaveAudit}
                  className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-black font-black rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md font-sans"
                >
                  حفظ المطابقة بالدفاتر 💾
                </button>

                {lastAuditResult && (
                  <a
                    href={generateWhatsAppLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md font-sans text-center"
                  >
                    مشاركة المالك واتساب 📲
                  </a>
                )}
              </div>
              
              {lastAuditResult && (
                <p className="text-[10px] text-emerald-400 text-center font-bold font-mono animate-pulse">
                  ✓ تم حفظ الجرد في سجلات التدقيق بنجاح!
                </p>
              )}
            </div>
          </div>
        );
      })()}

      {/* 🔮 ATTENTION-GRABBING INTERACTIVE FLOATING BUTTON FOR MOBILE NAV DRAWER */}
      <div className="fixed bottom-6 right-6 z-50 block md:hidden">
        <button
          onClick={() => setIsSidebarOpen(true)}
          className="attention-float-btn w-14 h-14 rounded-full flex items-center justify-center text-white text-xs font-black shadow-2xl border-2 border-white/20 active:scale-90 transition-all cursor-pointer relative"
          title="افتح القائمة السريعة"
        >
          <Menu className="w-6 h-6 text-black drop-shadow" />
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
          </span>
        </button>
      </div>

    </div>
  );
}
