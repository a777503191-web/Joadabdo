/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Layers, 
  AlertTriangle, 
  Users, 
  Activity, 
  ArrowUpLeft, 
  Inbox,
  ShieldCheck,
  Zap,
  ShoppingCart,
  RotateCcw,
  Wrench,
  Coins,
  CreditCard,
  Printer
} from 'lucide-react';
import { handlePrintSection } from '../utils/print';
import { 
  InventoryItem, 
  Sale, 
  UserProfile, 
  FinancialTransaction,
  AccountNode
} from '../types';
import { formatMoney, roundToTwoDecimals } from '../utils/currency';

interface DashboardTabProps {
  inventory: InventoryItem[];
  sales: Sale[];
  users: UserProfile[];
  transactions: FinancialTransaction[];
  accounts: AccountNode[];
  onNavigate: (tab: string) => void;
  onReceiveCustody: (userId: string) => void;
}

export default function DashboardTab({
  inventory,
  sales,
  users,
  transactions,
  accounts,
  onNavigate,
  onReceiveCustody
}: DashboardTabProps) {
  
  const isMotorcycles = localStorage.getItem('maint_business_type') === 'motorcycles';

  // 1. Calculations
  const metrics = useMemo(() => {
    const totalSalesSum = roundToTwoDecimals(sales.reduce((sum, item) => sum + item.total, 0));
    const totalProfitSum = roundToTwoDecimals(sales.reduce((sum, item) => sum + item.profit, 0));
    
    // Unpaid debts are marked on accounts with code 2101 or 1201 (or look directly at sales with paymentMethod === 'debt')
    const totalDebt = roundToTwoDecimals(sales
      .filter(s => s.paymentMethod === 'debt')
      .reduce((sum, s) => sum + s.total, 0));
      
    // Cash in all wallets
    const totalCashInWallets = roundToTwoDecimals(accounts
      .filter(acc => acc.type === 'asset')
      .reduce((sum, acc) => sum + acc.balance, 0));

    return {
      sales: totalSalesSum,
      profit: totalProfitSum,
      debt: totalDebt,
      walletCash: totalCashInWallets
    };
  }, [sales, accounts]);

  // 2. Low stock warning items
  const lowStockItems = useMemo(() => {
    return inventory.filter(item => item.stock <= item.minStock);
  }, [inventory]);

  // 3. User performance (Sales count & custody balance)
  const staffPerformance = useMemo(() => {
    return users.map(user => {
      const userSales = sales.filter(s => s.sellerId === user.uid);
      const totalSum = userSales.reduce((sum, s) => sum + s.total, 0);
      return {
        ...user,
        salesCount: userSales.length,
        salesVolume: totalSum
      };
    });
  }, [users, sales]);

  // 4. Sales by category for rendering custom bars
  const categoryStats = useMemo(() => {
    const stats: { [cat: string]: number } = {};
    sales.forEach(sale => {
      sale.items.forEach(item => {
        const invItem = inventory.find(i => i.id === item.id);
        const category = invItem?.category || 'عام';
        stats[category] = (stats[category] || 0) + (item.quantity * item.price);
      });
    });
    return Object.entries(stats).map(([name, value]) => ({ name, value }));
  }, [sales, inventory]);

  return (
    <div className="space-y-6" id="dashboard-tab-print-content">
      {/* Header System Details */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-zinc-800 pb-5 gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span className="w-2.5 h-6 bg-[#f1c40f] rounded-sm block"></span>
            نشرة الأداء والتحكم المالي العام
          </h2>
          <p className="text-zinc-400 text-sm mt-1">
            مؤشرات فورية متزامنة مع القيود الدفترية وحركات الخزائن.
          </p>
        </div>
        
        {/* State Indicators & Printing action */}
        <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
          <button
            onClick={() => handlePrintSection('dashboard-tab-print-content', 'تقرير وتحليل الأداء والتحكم المالي العام')}
            className="no-print px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-black hover:opacity-90 rounded border border-amber-500 transition flex items-center gap-2 cursor-pointer shadow-md"
          >
            <Printer className="w-4 h-4" />
            طباعة تقرير الأداء اليومي 🖨️
          </button>

          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-[#f1c40f]/10 text-[#f1c40f] border border-[#f1c40f]/20">
            <span className="w-2 h-2 rounded-full bg-[#f1c40f] animate-pulse"></span>
            الوضع متصل
          </div>
          <div className="px-2.5 py-1.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
            UTC 2026
          </div>
        </div>
      </div>

      {/* 🚀 QUICK ACTIONS FOR IMMEDIATE INVOICING / OPERATIONS */}
      <div className="bg-zinc-950/60 border border-[#f1c40f]/20 rounded-2xl p-4 md:p-5 shadow-[0_0_30px_rgba(241,196,15,0.03)] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-zinc-900 pb-3" dir="rtl">
          <div>
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <span className="w-1.5 h-4 bg-[#f1c40f] rounded-full animate-pulse"></span>
              أزرار العمل السريع والوصول المباشر ⚡
            </h3>
            <p className="text-[10px] text-zinc-400 mt-1">اضغط على أي زر لبدء عملية معالجة فواتير حركة الصندوق والعميل.</p>
          </div>
        </div>

        <div className={`grid grid-cols-2 ${isMotorcycles ? 'md:grid-cols-3' : 'md:grid-cols-5'} gap-3`} dir="rtl">
          {/* Action 1: POS Sale */}
          <button
            onClick={() => onNavigate('sales')}
            className="flex items-center justify-between p-3.5 bg-gradient-to-br from-emerald-500/10 to-teal-500/5 hover:to-teal-500/10 border border-emerald-500/10 hover:border-emerald-500/40 rounded-xl transition-all duration-200 group hover:-translate-y-0.5 shadow-sm text-right cursor-pointer"
          >
            <div className="space-y-1 min-w-0">
              <span className="text-xs font-black text-white group-hover:text-emerald-400 transition-colors block">بيع مباشر</span>
              <span className="text-[9px] text-zinc-400 block truncate">فاتورة بيع POS</span>
            </div>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500/20 group-hover:scale-105 transition-all flex-shrink-0">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </button>

          {/* Action 2: Return */}
          <button
            onClick={() => onNavigate('returns')}
            className="flex items-center justify-between p-3.5 bg-gradient-to-br from-amber-500/10 to-orange-500/5 hover:to-orange-500/10 border border-amber-500/10 hover:border-amber-500/40 rounded-xl transition-all duration-200 group hover:-translate-y-0.5 shadow-sm text-right cursor-pointer"
          >
            <div className="space-y-1 min-w-0">
              <span className="text-xs font-black text-white group-hover:text-amber-400 transition-colors block">مرتجع سلع</span>
              <span className="text-[9px] text-zinc-400 block truncate">فحص ومرتجع فوري</span>
            </div>
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20 group-hover:scale-105 transition-all flex-shrink-0">
              <RotateCcw className="w-4 h-4" />
            </div>
          </button>

          {/* Action 3: Maintenance */}
          <button
            onClick={() => onNavigate('maintenance')}
            className="flex items-center justify-between p-3.5 bg-gradient-to-br from-cyan-500/10 to-blue-500/5 hover:to-blue-500/10 border border-cyan-500/10 hover:border-cyan-500/40 rounded-xl transition-all duration-200 group hover:-translate-y-0.5 shadow-sm text-right cursor-pointer"
          >
            <div className="space-y-1 min-w-0">
              <span className="text-xs font-black text-white group-hover:text-cyan-400 transition-colors block">صيانة</span>
              <span className="text-[9px] text-zinc-400 block truncate">كرت صيانة وورشة</span>
            </div>
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 group-hover:bg-cyan-500/20 group-hover:scale-105 transition-all flex-shrink-0">
              <Wrench className="w-4 h-4" />
            </div>
          </button>

          {!isMotorcycles && (
            <>
              {/* Action 4: Credit / Transfer */}
              <button
                onClick={() => onNavigate('credit-transfer')}
                className="flex items-center justify-between p-3.5 bg-gradient-to-br from-[#f1c40f]/10 to-yellow-600/5 hover:to-yellow-600/10 border border-[#f1c40f]/10 hover:border-[#f1c40f]/40 rounded-xl transition-all duration-200 group hover:-translate-y-0.5 shadow-sm text-right cursor-pointer"
              >
                <div className="space-y-1 min-w-0">
                  <span className="text-xs font-black text-white group-hover:text-[#f1c40f] transition-colors block">تحويل رصيد</span>
                  <span className="text-[9px] text-zinc-400 block truncate">تسجيل مبيعات رصيد</span>
                </div>
                <div className="p-2 rounded-lg bg-[#f1c40f]/10 text-[#f1c40f] group-hover:bg-[#f1c40f]/20 group-hover:scale-105 transition-all flex-shrink-0">
                  <Coins className="w-4 h-4" />
                </div>
              </button>

              {/* Action 5: SIM Card Sale */}
              <button
                onClick={() => onNavigate('credit-sims')}
                className="flex items-center justify-between p-3.5 bg-gradient-to-br from-rose-500/10 to-red-500/5 hover:to-red-500/10 border border-rose-500/10 hover:border-rose-500/40 rounded-xl transition-all duration-200 group hover:-translate-y-0.5 shadow-sm col-span-2 md:col-span-1 text-right cursor-pointer"
              >
                <div className="space-y-1 min-w-0">
                  <span className="text-xs font-black text-white group-hover:text-rose-400 transition-colors block">بيع شرايح</span>
                  <span className="text-[9px] text-zinc-400 block truncate">إصدار خطوط وشرايح</span>
                </div>
                <div className="p-2 rounded-lg bg-rose-500/10 text-rose-400 group-hover:bg-rose-500/20 group-hover:scale-105 transition-all flex-shrink-0">
                  <CreditCard className="w-4 h-4" />
                </div>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Sales */}
        <div className="bg-[#0d0d0d] border-l-4 border-[#f1c40f] border border-zinc-800/40 rounded p-5 hover:border-zinc-700 transition relative overflow-hidden group shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-sm font-medium">إجمالي المبيعات النشطة</span>
            <div className="p-2 rounded bg-zinc-800 text-[#f1c40f] group-hover:bg-[#f1c40f]/10 transition">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">{formatMoney(metrics.sales)}</span>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-1 font-mono">
              <ArrowUpLeft className="w-3.5 h-3.5" />
              <span>+18.4% نمو اليوم</span>
            </div>
          </div>
          {/* Subtle bottom indicator */}
          <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#f1c40f]/40 to-transparent"></div>
        </div>

        {/* KPI 2: Net profit */}
        <div className="bg-[#0d0d0d] border-l-4 border-[#f1c40f] border border-zinc-800/40 rounded p-5 hover:border-zinc-700 transition relative overflow-hidden group shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-sm font-medium">صافي الربح المحقق</span>
            <div className="p-2 rounded bg-zinc-800 text-amber-400 group-hover:bg-amber-500/10 transition">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-bold font-mono tracking-tight text-[#f1c40f]">{formatMoney(metrics.profit)}</span>
            <div className="flex items-center gap-1.5 text-xs text-zinc-400 mt-1">
              <span>هامش ربح توازني مجدول</span>
            </div>
          </div>
        </div>

        {/* KPI 3: Outstandings */}
        <div className="bg-[#0d0d0d] border-l-4 border-[#f1c40f] border border-zinc-800/40 rounded p-5 hover:border-zinc-700 transition relative overflow-hidden group shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-sm font-medium">الديون والذمم الآجلة</span>
            <div className="p-2 rounded bg-zinc-800 text-[#f1c40f] group-hover:bg-[#f1c40f]/10 transition">
              <Layers className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">{formatMoney(metrics.debt)}</span>
            <div className="flex items-center gap-1.5 text-xs text-amber-400 mt-1">
              <span>ذمم تجارية ومقاصات شبكية</span>
            </div>
          </div>
        </div>

        {/* KPI 4: Distributed cash flow */}
        <div className="bg-[#0d0d0d] border-l-4 border-green-500 border border-zinc-800/40 rounded p-5 hover:border-zinc-700 transition relative overflow-hidden group shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-sm font-medium">إجمالي السيولة النقدية</span>
            <div className="p-2 rounded bg-zinc-800 text-green-400 group-hover:bg-green-550/10 transition">
              <Zap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-bold font-mono tracking-tight text-green-400">{formatMoney(metrics.walletCash)}</span>
            <div className="flex items-center gap-1.5 text-xs text-green-500 mt-1">
              <span>صناديق وبنوك الكريمي محتسب</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Analytical & Actionable items */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Section left (2 columns wide) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Custom SVG Performance Graph */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold text-white">تحليل توزيع المبيعات حسب السلع والخدمات</h3>
                <p className="text-xs text-zinc-400 mt-0.5">مقارنة الحصص الإجمالية المدخلة بالدولار المرجعي</p>
              </div>
              <Activity className="w-5 h-5 text-zinc-500" />
            </div>
            
            {categoryStats.length === 0 ? (
              <div className="h-44 flex flex-col items-center justify-center border border-zinc-800 border-dashed rounded text-zinc-500 text-sm">
                <p>لا توجد مبيعات مفهرسة لتصنيف الفئات حالياً</p>
              </div>
            ) : (
              <div className="space-y-4">
                {categoryStats.map((stat, i) => {
                  const maxAmt = Math.max(...categoryStats.map(c => c.value)) || 1;
                  const ratio = (stat.value / maxAmt) * 100;
                  return (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-zinc-300 font-medium">{stat.name}</span>
                        <span className="text-white font-semibold">${stat.value.toLocaleString()}</span>
                      </div>
                      <div className="w-full bg-zinc-800 rounded-full h-2.5 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-amber-600 to-[#f1c40f] rounded-full transition-all duration-500"
                          style={{ width: `${ratio}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            
            <div className="mt-5 border-t border-zinc-800/60 pt-4 flex items-center justify-between text-xs text-zinc-400">
              <span>* يتم التحديث تلقائياً فور تعديل فواتير المستودعات ونقطة بيع POS.</span>
              <button 
                onClick={() => onNavigate('sales')}
                className="text-[#f1c40f] hover:underline flex items-center gap-1 font-mono"
              >
                افتح نقطة البيع مبيعات &larr;
              </button>
            </div>
          </div>

          {/* Employee Custody Control Room */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-white">إمارة العهد والمطابقة اليومية للموظفين</h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  حركات درج الكاش غير المسواة مع الخزنة المركزية.
                </p>
              </div>
              <Users className="w-5 h-5 text-zinc-500" />
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-right text-sm">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-400 text-xs">
                    <th className="py-2.5">الموظف</th>
                    <th className="py-2.5">الدور التشغيلي</th>
                    <th className="py-2.5">الفواتير المحررة</th>
                    <th className="py-2.5">العهدة الحالية</th>
                    <th className="py-2.5 text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/40">
                  {staffPerformance.map((user, i) => (
                    <tr key={i} className="hover:bg-zinc-800/20 text-zinc-300">
                      <td className="py-3 font-medium text-white">{user.name}</td>
                      <td className="py-3">
                        <span className="px-2 py-0.5 rounded text-xs bg-zinc-800 text-zinc-400">
                          {user.role}
                        </span>
                      </td>
                      <td className="py-3 font-mono">{user.salesCount} فاتورة</td>
                      <td className="py-3 font-mono text-[#f1c40f]">
                        ${(user.custodyBalance || 0).toLocaleString()}
                      </td>
                      <td className="py-3 text-center">
                        <button
                          disabled={(user.custodyBalance || 0) <= 0}
                          onClick={() => onReceiveCustody(user.uid)}
                          className={`px-3 py-1 rounded text-xs transition font-semibold font-mono ${
                            (user.custodyBalance || 0) > 0
                              ? 'bg-[#f1c40f] text-black hover:bg-[#d2ac0a] cursor-pointer'
                              : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
                          }`}
                        >
                          تفريغ واستلام العهدة
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Section right (1 column wide) */}
        <div className="space-y-6">
          
          {/* Low Stock Watcher Card */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500 animate-pulse" />
                <h3 className="font-semibold text-white">تحذير نفاد المخزون الكلي</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-amber-400 font-mono">
                {lowStockItems.length} سلع مكشوفة
              </span>
            </div>
            
            {lowStockItems.length === 0 ? (
              <div className="py-8 flex flex-col items-center justify-center text-zinc-500 text-xs">
                <ShieldCheck className="w-8 h-8 text-emerald-500 mb-2" />
                <p>جميع مستويات المخزون مستقرة ومفعمة</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                {lowStockItems.map((item, idx) => (
                  <div key={idx} className="p-3 rounded bg-zinc-950 border border-zinc-800 flex items-center justify-between text-xs">
                    <div>
                      <h4 className="font-medium text-zinc-200">{item.name}</h4>
                      <div className="flex items-center gap-2 text-[10px] text-zinc-500 mt-1">
                        <span>الحد الأدنى: <strong className="font-mono">{item.minStock}</strong></span>
                        <span>&bull;</span>
                        <span>الفئة: <strong>{item.category}</strong></span>
                      </div>
                    </div>
                    <div className="text-left font-mono">
                      <span className="px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20 font-bold block">
                        المتبقي: {item.stock} حبة
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="mt-4 pt-4 border-t border-zinc-800/60">
              <button 
                onClick={() => onNavigate('inventory')}
                className="w-full py-2 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold font-mono text-center block"
              >
                تحديث وجرد مخزن المواد &larr;
              </button>
            </div>
          </div>

          {[/* System state / quick specs box */].map(() => null)}
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
            <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#f1c40f]" /> 
              دليل الربط الحسابي المتكامل
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              وفقاً لدليل النظام الفني لـ <strong>JAM System Pro</strong> وبراءته المالية:
            </p>
            <ul className="text-xs text-zinc-300 mt-3 space-y-2.5 list-disc list-inside">
              <li>
                <strong className="text-white">الذريّة الكلية:</strong> ترحيل مرتجع المبيعات يتم مع زيادة حيازة مستودع الصنيع مباشرة بـ <code>runTransaction</code>.
              </li>
              <li>
                <strong className="text-white">العهد المالية:</strong> المبيعات النقدية للمحلات ترحّل لصندوق البائع المنفرد ولا تفرّغ آلياً إلا بإذن غلق الدرج.
              </li>
              <li>
                <strong className="text-white">الصيانة:</strong> قيد قطع الغيار يسحب حصرياً من الصنف البنيوي للمستودع لربط التلفيات برمتها.
              </li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}
