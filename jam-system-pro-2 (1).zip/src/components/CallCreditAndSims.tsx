/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Plus, 
  Trash2, 
  TrendingUp, 
  Wallet, 
  Calendar, 
  Hash, 
  User, 
  FileText, 
  ShoppingBag, 
  Search, 
  CheckCircle,
  Percent,
  RefreshCw,
  Sliders,
  DollarSign
} from 'lucide-react';
import { CallCreditRecord, SIMCardItem, UserProfile } from '../types';

interface CallCreditAndSimsProps {
  currentUser: UserProfile;
  onAddTransaction?: (tx: any) => void;
  onAddSale?: (sale: any) => void;
  initialSubTab?: 'credit' | 'sims';
}

export default function CallCreditAndSims({ 
  currentUser,
  onAddTransaction,
  onAddSale,
  initialSubTab = 'credit'
}: CallCreditAndSimsProps) {
  
  // --- STATE PERSISTENCE ---
  const [activeSubTab, setActiveSubTab] = useState<'credit' | 'sims'>(initialSubTab);

  useEffect(() => {
    setActiveSubTab(initialSubTab);
  }, [initialSubTab]);
  
  const [creditRecords, setCreditRecords] = useState<CallCreditRecord[]>(() => {
    const saved = localStorage.getItem('call_credit_records');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'cr-1',
        date: '2026-06-11',
        programName: 'الكريمي جوال',
        soldAmount: 25000,
        purchasedAmount: 22000,
        cashInDrawer: 26000,
        profit: 3000,
        registeredAt: '2026-06-11T21:45:00.000Z',
        engineerId: 'eng-1',
        engineerName: 'المهندس علي المحفلي',
        notes: 'تصفية الفترة المسائية بنجاح'
      },
      {
        id: 'cr-2',
        date: '2026-06-11',
        programName: 'يمن موبايل فوري',
        soldAmount: 64000,
        purchasedAmount: 58000,
        cashInDrawer: 64500,
        profit: 6000,
        registeredAt: '2026-06-11T21:50:00.000Z',
        engineerId: 'admin',
        engineerName: 'أبو جواد المحفلي',
        notes: 'مبيعات الشحن الفوري للشبكة'
      },
      {
        id: 'cr-3',
        date: '2026-06-10',
        programName: 'العمقي للصرافة',
        soldAmount: 43000,
        purchasedAmount: 39500,
        cashInDrawer: 43200,
        profit: 3500,
        registeredAt: '2026-06-10T22:00:00.000Z',
        engineerId: 'eng-2',
        engineerName: 'المهندس صالح المرادي',
        notes: 'مطابقة ممتازة مع الجرد الإجمالي'
      }
    ];
  });

  const [simCards, setSimCards] = useState<SIMCardItem[]>(() => {
    const saved = localStorage.getItem('sim_cards_inventory');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'sim-1',
        invoiceRef: 'INV-7723',
        serialNumber: '8996701122334455001',
        costNew: 1500,
        costReplacement: 1000,
        priceNew: 3000,
        priceReplacement: 2000,
        stock: 25,
        supplierName: 'يمن موبايل - الموزع المركزي',
        createdAt: '2026-06-12T07:15:00.000Z'
      },
      {
        id: 'sim-2',
        invoiceRef: 'INV-4099',
        serialNumber: '8996702200998877660',
        costNew: 2000,
        costReplacement: 1200,
        priceNew: 3500,
        priceReplacement: 2500,
        stock: 12,
        supplierName: 'مؤسسة صبأفون للإتصالات',
        createdAt: '2026-06-12T07:16:00.000Z'
      },
      {
        id: 'sim-3',
        invoiceRef: 'INV-5500',
        serialNumber: '8996703355443322112',
        costNew: 2500,
        costReplacement: 1500,
        priceNew: 4000,
        priceReplacement: 3000,
        stock: 8,
        supplierName: 'شركة يو للاتصالات السلكية',
        createdAt: '2026-06-12T07:17:00.000Z'
      }
    ];
  });

  // Save changes to local storage automatically
  useEffect(() => {
    localStorage.setItem('call_credit_records', JSON.stringify(creditRecords));
  }, [creditRecords]);

  useEffect(() => {
    localStorage.setItem('sim_cards_inventory', JSON.stringify(simCards));
  }, [simCards]);

  // --- 1. CALL CREDIT REGISTRY STATE & LOGIC ---
  const [soldAmount, setSoldAmount] = useState<string>('');
  const [purchasedAmount, setPurchasedAmount] = useState<string>('');
  const [cashInDrawer, setCashInDrawer] = useState<string>('');
  const [customProfit, setCustomProfit] = useState<string>('');
  const [programName, setProgramName] = useState<string>('الكريمي جوال');
  const [creditNotes, setCreditNotes] = useState<string>('');
  const [creditDate, setCreditDate] = useState<string>(() => {
    return new Date().toISOString().substring(0, 10);
  });
  
  // Custom suggestion for program/app
  const mobilePrograms = [
    'الكريمي جوال',
    'الكريمي مميز',
    'يمن موبايل فوري',
    'العمقي صرافة',
    'النجم للصرافة',
    'شركة سبأفون',
    'تطبيق يو شحن',
    'النظام المشترك الموحد'
  ];

  // Auto calculate profit recommendation
  const calculatedProfit = Math.max(0, (Number(soldAmount) || 0) - (Number(purchasedAmount) || 0));

  const handleAddCreditRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!soldAmount || !purchasedAmount || !cashInDrawer) {
      alert('الرجاء تعبئة كمية المبيعات والمشتريات والنقدية المتوفرة بالدرج لتأكيد الإغلاق اليومي للرصيد!');
      return;
    }

    const recProfit = customProfit !== '' ? Number(customProfit) : calculatedProfit;

    const newRecord: CallCreditRecord = {
      id: 'cr-' + Date.now(),
      date: creditDate,
      programName,
      soldAmount: Number(soldAmount),
      purchasedAmount: Number(purchasedAmount),
      cashInDrawer: Number(cashInDrawer),
      profit: recProfit,
      registeredAt: new Date().toISOString(),
      engineerId: currentUser.uid,
      engineerName: currentUser.name,
      notes: creditNotes || 'تسجيل الميزان اليومي للرصيد'
    };

    setCreditRecords([newRecord, ...creditRecords]);
    
    // Auto register a financial transaction in the parent systems if passed
    if (onAddTransaction) {
      onAddTransaction({
        id: 'tx-credit-' + Date.now(),
        ownerId: 'owner-1',
        type: 'income',
        amount: Number(soldAmount),
        category: 'مبيعات رصيد وشحن',
        description: `تسجيل مبيعات رصيد (${programName}) - صافي الفايدة المقيدة: ${recProfit} ريال`,
        accountId: programName,
        createdAt: new Date().toISOString()
      });
    }

    // Reset Form
    setSoldAmount('');
    setPurchasedAmount('');
    setCashInDrawer('');
    setCustomProfit('');
    setCreditNotes('');
  };

  const handleDeleteCreditRecord = (id: string) => {
    if (window.confirm('هل أنت متأكد من رغبتك في حذف هذا البيان المالي المسجل؟')) {
      setCreditRecords(current => current.filter(r => r.id !== id));
    }
  };

  // --- 2. SIM CARDS MANAGMENT STATE & LOGIC ---
  const [simInvoiceRef, setSimInvoiceRef] = useState<string>('');
  const [simSerialNumber, setSimSerialNumber] = useState<string>('');
  const [simCostNew, setSimCostNew] = useState<string>('');
  const [simCostReplacement, setSimCostReplacement] = useState<string>('');
  const [simPriceNew, setSimPriceNew] = useState<string>('');
  const [simPriceReplacement, setSimPriceReplacement] = useState<string>('');
  const [simStock, setSimStock] = useState<string>('10');
  const [simSupplier, setSimSupplier] = useState<string>('');
  const [simSearchQuery, setSimSearchQuery] = useState<string>('');

  const handleAddSIMBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!simSerialNumber || !simPriceNew || !simStock) {
      alert('الرجاء ملء الرقم التسلسلي وسعر البيع الأولي والكمية لتقييد الشريحة!');
      return;
    }

    const newSIM: SIMCardItem = {
      id: 'sim-' + Date.now(),
      invoiceRef: simInvoiceRef || 'فاتورة شراء شفهية',
      serialNumber: simSerialNumber,
      costNew: Number(simCostNew) || 0,
      costReplacement: Number(simCostReplacement) || 0,
      priceNew: Number(simPriceNew) || 0,
      priceReplacement: Number(simPriceReplacement) || 0,
      stock: Number(simStock) || 1,
      supplierName: simSupplier || 'مورد عام للاتصالات',
      createdAt: new Date().toISOString()
    };

    setSimCards([newSIM, ...simCards]);

    // Reset Form
    setSimInvoiceRef('');
    setSimSerialNumber('');
    setSimCostNew('');
    setSimCostReplacement('');
    setSimPriceNew('');
    setSimPriceReplacement('');
    setSimStock('10');
    setSimSupplier('');
  };

  const handleSellSIMItem = (simId: string, sellType: 'new' | 'replacement') => {
    const sim = simCards.find(s => s.id === simId);
    if (!sim) return;

    if (sim.stock <= 0) {
      alert('المعذرة! نفذت الكمية من هذه الشريحة بالفروع!');
      return;
    }

    const isConfirmed = window.confirm(`تأكيد بيع الشريحة ذي الرقم المتسلسل (${sim.serialNumber}) كـ ${sellType === 'new' ? 'جديد' : 'بدل فاقد'} بمبلغ ${sellType === 'new' ? sim.priceNew : sim.priceReplacement} ريال؟`);
    if (!isConfirmed) return;

    // Deduct Stock
    setSimCards(current => current.map(item => {
      if (item.id === simId) {
        return {
          ...item,
          stock: Math.max(0, item.stock - 1)
        };
      }
      return item;
    }));

    const sellPrice = sellType === 'new' ? sim.priceNew : sim.priceReplacement;
    const buyCost = sellType === 'new' ? sim.costNew : sim.costReplacement;
    const profitEarned = Math.max(0, sellPrice - buyCost);

    // Register inside the parent POS sales system if function is loaded
    if (onAddSale) {
      onAddSale({
        id: 'sale-sim-' + Date.now(),
        ownerId: 'owner-1',
        items: [
          {
            id: sim.id,
            name: `شريحة SIM: ${sim.serialNumber.substring(0, 8)}... (${sellType === 'new' ? 'جديد' : 'بدل فاقد'})`,
            quantity: 1,
            price: sellPrice,
            cost: buyCost
          }
        ],
        total: sellPrice,
        profit: profitEarned,
        paymentMethod: 'cash',
        sellerId: currentUser.uid,
        sellerName: currentUser.name,
        createdAt: new Date().toISOString()
      });
    }

    alert(`تم تسجيل عملية البيع بنجاح! السعر: ${sellPrice} ريال. تم خصم 1 من الكمية المتوفرة بالسيريال.`);
  };

  const handleDeleteSIMBatch = (id: string) => {
    if (window.confirm('هل تود حقاً شطب هذا الصنف من مخزن الشرائح نهائياً؟')) {
      setSimCards(current => current.filter(s => r => r.id !== id));
      setSimCards(current => current.filter(s => s.id !== id));
    }
  };

  // --- STATS COMPONENT CALCULATIONS ---
  const totalCreditSold = creditRecords.reduce((sum, r) => sum + r.soldAmount, 0);
  const totalCreditPurchased = creditRecords.reduce((sum, r) => sum + r.purchasedAmount, 0);
  const totalCreditProfit = creditRecords.reduce((sum, r) => sum + r.profit, 0);
  const totalCreditCash = creditRecords.reduce((sum, r) => sum + r.cashInDrawer, 0);

  const totalSIMStock = simCards.reduce((sum, s) => sum + s.stock, 0);

  // Filter SIM Cards query
  const filteredSims = simCards.filter(s => {
    const q = simSearchQuery.toLowerCase();
    return s.serialNumber.includes(q) || s.supplierName.toLowerCase().includes(q) || s.invoiceRef.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6 text-right font-sans" dir="rtl">
      
      {/* HEADER SECTION WITH HERO CARD */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-950 to-zinc-900 border border-[#f1c40f]/20 rounded-2xl p-6 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#f1c40f]/5 rounded-full blur-2xl"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-emerald-500/5 rounded-full blur-3xl"></div>
        
        <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <span className="px-3 py-1 bg-[#f1c40f]/10 text-[#f1c40f] text-xs font-black rounded-lg border border-[#f1c40f]/20">
              خدمات الإتصالات والشبكات والمبيعات اليومية
            </span>
            <h2 className="text-2xl font-black text-white mt-2 flex items-center gap-2">
              <Smartphone className="w-6 h-6 text-[#f1c40f]" />
              صناديق رصيد الشحن وشرائح SIM 📱
            </h2>
            <p className="text-xs text-zinc-400 mt-1 max-w-xl">
              منظومة متكاملة لتقييد مبيعات الرصيد نهاية اليوم لمختلف البرامج والتطبيقات (الكريمي، يمن موبايل، العمقي)، بالإضافة لخدمات إدارة وجرد شرائح الإتصال SIM الفورية مع تعيين أسعار البدل والمبيعات المباشرة.
            </p>
          </div>

          {/* Tab buttons switcher */}
          <div className="flex bg-zinc-950/80 p-1 border border-zinc-800 rounded-xl w-full md:w-auto">
            <button
              onClick={() => setActiveSubTab('credit')}
              className={`flex-1 md:flex-none px-4 py-2.5 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeSubTab === 'credit'
                  ? 'bg-[#f1c40f] text-black shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Wallet className="w-4 h-4" />
              رصيد البرامج والشحن اليومي
            </button>
            <button
              onClick={() => setActiveSubTab('sims')}
              className={`flex-1 md:flex-none px-4 py-2.5 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
                activeSubTab === 'sims'
                  ? 'bg-[#f1c40f] text-black shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Hash className="w-4 h-4" />
              مستودع شرائح SIM السريعة
            </button>
          </div>
        </div>
      </div>

      {/* ======================= SUB TAB 1: CALL CREDIT REGISTER ======================= */}
      {activeSubTab === 'credit' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Column Local stats */}
          <div className="lg:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-4">
            
            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] text-zinc-500 font-bold block mb-1">إجمالي مبيعات الرصيد</span>
                <span className="text-lg font-black text-emerald-500">{totalCreditSold.toLocaleString()} <span className="text-xs">ريال</span></span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-emerald-500" />
              </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] text-zinc-500 font-bold block mb-1">إجمالي تكلفة المشتريات</span>
                <span className="text-lg font-black text-amber-500">{totalCreditPurchased.toLocaleString()} <span className="text-xs">ريال</span></span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-amber-500" />
              </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] text-zinc-500 font-bold block mb-1">صافي أرباح الرصيد 💵</span>
                <span className="text-lg font-black text-[#f1c40f]">{totalCreditProfit.toLocaleString()} <span className="text-xs">ريال</span></span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                <Percent className="w-5 h-5 text-[#f1c40f]" />
              </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] text-zinc-500 font-bold block mb-1">النقدية الفعلية المسوّاة بالدرج</span>
                <span className="text-lg font-black text-blue-400">{totalCreditCash.toLocaleString()} <span className="text-xs">ريال</span></span>
              </div>
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Wallet className="w-5 h-5 text-blue-400" />
              </div>
            </div>

          </div>

          {/* Form to Close Day Credit */}
          <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl md:col-span-1 space-y-4">
            <div className="border-b border-zinc-800 pb-2">
              <span className="text-[10px] text-zinc-500 block">إغلاق الميزان اليومي للمبيعات</span>
              <h3 className="text-sm font-black text-[#f1c40f]">تقييد جرد نهاية اليوم 📝</h3>
            </div>

            <form onSubmit={handleAddCreditRecord} className="space-y-4 text-right">
              
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-zinc-400 block">برنامج / محمل الشحن بالجوال</label>
                <select
                  value={programName}
                  onChange={(e) => setProgramName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-white"
                >
                  {mobilePrograms.map(prog => (
                    <option key={prog} value={prog}>{prog}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-400 block">كم بعت؟ (مجموع المبيعات)</label>
                  <input
                    type="number"
                    value={soldAmount}
                    onChange={(e) => setSoldAmount(e.target.value)}
                    placeholder="مثال: 50000"
                    required
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white text-center font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-400 block">كم اشتريت؟ (المشتريات/الرصيد)</label>
                  <input
                    type="number"
                    value={purchasedAmount}
                    onChange={(e) => setPurchasedAmount(e.target.value)}
                    placeholder="مثال: 47000"
                    required
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white text-center font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-400 block">كم في الدرج كاش؟</label>
                  <input
                    type="number"
                    value={cashInDrawer}
                    onChange={(e) => setCashInDrawer(e.target.value)}
                    placeholder="مطابقة الكاش بالدرج"
                    required
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white text-center font-bold text-blue-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-400 block">الفايدة / الفائدة اليدوية</label>
                  <input
                    type="number"
                    value={customProfit}
                    onChange={(e) => setCustomProfit(e.target.value)}
                    placeholder={`تلقائي: ${calculatedProfit}`}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-[#f1c40f] text-center font-bold"
                  />
                  <span className="text-[9px] text-zinc-500 block text-center">(اتركه فارغاً للحساب التلقائي)</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-zinc-400 block">تاريخ هذه الدورية/التسجيل</label>
                <input
                  type="date"
                  value={creditDate}
                  onChange={(e) => setCreditDate(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white text-center font-bold"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-zinc-400 block flex justify-between">
                  <span>ملاحظات إضافية</span>
                  <span className="text-[9px] text-zinc-500">اختياري</span>
                </label>
                <textarea
                  value={creditNotes}
                  onChange={(e) => setCreditNotes(e.target.value)}
                  placeholder="ملاحظات العجز/الزيادة أو تفاصيل العميل والمسؤول..."
                  rows={2}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white text-right"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <CheckCircle className="w-4 h-4" />
                تقييد وتسجيل إقفال اليوم للرصيد ✓
              </button>
            </form>
          </div>

          {/* Grid/Table of Previous Records */}
          <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl lg:col-span-2 space-y-4">
            <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
              <div>
                <span className="text-[10px] text-zinc-500 block font-mono">HISTORY LOGS</span>
                <h3 className="text-sm font-black text-white">السجلات التاريخية لإقفال الشحن اليومي 📜</h3>
              </div>
              <span className="text-xs bg-zinc-950 px-3 py-1 border border-zinc-800 rounded-lg font-bold text-zinc-400">
                إجمالي التقييدات: {creditRecords.length}
              </span>
            </div>

            {creditRecords.length === 0 ? (
              <div className="text-center py-10 text-zinc-500 space-y-2">
                <div className="text-4xl">📭</div>
                <p className="text-xs font-bold">لا توجد أي تقارير إغلاق رصيد وشحن فوري مسجلة حالياً.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                {creditRecords.map(rec => {
                  const checkDiff = rec.cashInDrawer - rec.soldAmount;
                  return (
                    <div 
                      key={rec.id} 
                      className="p-4 bg-zinc-950/75 border border-zinc-850 hover:border-zinc-800 rounded-xl space-y-3 transition relative"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-[#f1c40f] animate-pulse"></span>
                          <span className="font-black text-xs text-white">{rec.programName}</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-zinc-900 rounded border border-zinc-800 text-zinc-400 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {rec.date}
                          </span>
                        </div>
                        
                        <button
                          onClick={() => handleDeleteCreditRecord(rec.id)}
                          className="p-1 text-zinc-600 hover:text-red-500 transition rounded"
                          title="حذف القيد المالي"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-1 border-t border-zinc-900/80">
                        <div>
                          <span className="text-[9px] text-zinc-500 block">المبيعات الإجمالية</span>
                          <span className="text-xs font-black text-emerald-400 font-mono">{rec.soldAmount.toLocaleString()} ريال</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-zinc-500 block">المشتريات والرصيد</span>
                          <span className="text-xs font-black text-zinc-300 font-mono">{rec.purchasedAmount.toLocaleString()} ريال</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-zinc-500 block">الكاش في الدرج</span>
                          <span className="text-xs font-black text-blue-400 font-mono">{rec.cashInDrawer.toLocaleString()} ريال</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-zinc-500 block">صافي الفائدة المقيدة</span>
                          <span className="text-xs font-black text-[#f1c40f] font-mono">+{rec.profit.toLocaleString()} ريال</span>
                        </div>
                      </div>

                      {/* Footer Info line */}
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center text-[10px] text-zinc-500 gap-1.5 pt-2 border-t border-zinc-900/60 font-mono">
                        <div className="flex items-center gap-1">
                          <User className="w-3.5 h-3.5 text-zinc-500" />
                          <span>المسؤول: <strong>{rec.engineerName}</strong></span>
                        </div>
                        {rec.notes && (
                          <div className="text-zinc-400 italic font-sans max-w-sm truncate text-left">
                            📄 {rec.notes}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================= SUB TAB 2: SIM CARDS GERD MANAGER ======================= */}
      {activeSubTab === 'sims' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* SIM Cards input Batch Form */}
          <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl md:col-span-1 space-y-4">
            <div className="border-b border-zinc-800 pb-2">
              <span className="text-[10px] text-zinc-500 block">تغذية المخازن بدفعة جديدة</span>
              <h3 className="text-sm font-black text-[#f1c40f]">إضافة/تقييد دفعة شرائح SIM 📦</h3>
            </div>

            <form onSubmit={handleAddSIMBatch} className="space-y-4 text-right">
              
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-zinc-400 block">رقم الفاتورة عند شراء الشرائح</label>
                <input
                  type="text"
                  value={simInvoiceRef}
                  onChange={(e) => setSimInvoiceRef(e.target.value)}
                  placeholder="مثال: فاتورة مبيعات #4092"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-[#f1c40f] block">الرقم التسلسلي الأولي للشريحة (أو البادئة)</label>
                <input
                  type="text"
                  value={simSerialNumber}
                  onChange={(e) => setSimSerialNumber(e.target.value)}
                  placeholder="مثال: 899670112233..."
                  required
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono text-left tracking-wider"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-zinc-400 block">سعر الشراء (شريحة جديدة)</label>
                  <input
                    type="number"
                    value={simCostNew}
                    onChange={(e) => setSimCostNew(e.target.value)}
                    placeholder="شراء جديد"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-center font-bold text-red-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-zinc-400 block">سعر الشراء (بدل فاقد)</label>
                  <input
                    type="number"
                    value={simCostReplacement}
                    onChange={(e) => setSimCostReplacement(e.target.value)}
                    placeholder="شراء فاقد"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-center font-bold text-red-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-emerald-400 block">سعر البيع الافتراضي (جديد)</label>
                  <input
                    type="number"
                    value={simPriceNew}
                    onChange={(e) => setSimPriceNew(e.target.value)}
                    placeholder="سعر بيع جديد"
                    required
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-center font-bold text-emerald-400"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-emerald-400 block">سعر البيع (بدل فاقد)</label>
                  <input
                    type="number"
                    value={simPriceReplacement}
                    onChange={(e) => setSimPriceReplacement(e.target.value)}
                    placeholder="بيع بدل فاقد"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-center font-bold text-emerald-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-400 block">الكمية المسلمة للمحل</label>
                  <input
                    type="number"
                    value={simStock}
                    onChange={(e) => setSimStock(e.target.value)}
                    placeholder="مثال: 50"
                    required
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-center font-bold text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-zinc-400 block">المورد الرئيسي لهن</label>
                  <input
                    type="text"
                    value={simSupplier}
                    onChange={(e) => setSimSupplier(e.target.value)}
                    placeholder="مثال: شركة يمن موبايل"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#f1c40f] hover:bg-[#e0b70d] text-black text-xs font-black rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                تقييد دفعة الشرائح بالمستودع 💾
              </button>
            </form>
          </div>

          {/* SIM Cards List and Touch selling board */}
          <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl lg:col-span-2 space-y-4">
            
            {/* Quick Live Search Bar */}
            <div className="flex flex-col md:flex-row justify-between items-stretch md:items-center gap-3 border-b border-zinc-800 pb-4">
              <div>
                <span className="text-[10px] text-zinc-500 block font-mono">STOCK MANAGER</span>
                <h3 className="text-sm font-black text-white">إجمالي الشرائح المتوفرة بالرف ({totalSIMStock} شريحة) 🔋</h3>
              </div>

              <div className="relative">
                <input
                  type="text"
                  value={simSearchQuery}
                  onChange={(e) => setSimSearchQuery(e.target.value)}
                  placeholder="ابحث بالسيريال أو بالمورد..."
                  className="w-full md:w-64 bg-zinc-950 border border-zinc-800 rounded-lg py-1.5 pr-8 pl-3 text-xs text-white text-right placeholder-zinc-600 focus:outline-none"
                />
                <Search className="w-4 h-4 text-zinc-600 absolute right-2.5 top-2" />
              </div>
            </div>

            {filteredSims.length === 0 ? (
              <div className="text-center py-12 text-zinc-500">
                <div className="text-4xl text-zinc-700">🔎</div>
                <p className="text-xs font-bold mt-2">لا توجد أي شرائح مطابقة لبحثك أو الرقم التسلسلي المدخل.</p>
              </div>
            ) : (
              <div className="space-y-3.5 max-h-[480px] overflow-y-auto pr-1">
                {filteredSims.map(sim => (
                  <div 
                    key={sim.id}
                    className="p-4 bg-zinc-950/80 border border-zinc-850 hover:border-zinc-800 hover:bg-zinc-950 rounded-xl space-y-3 transition"
                  >
                    <div className="flex flex-wrap justify-between items-center gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`w-3 h-3 rounded-full ${sim.stock > 5 ? 'bg-emerald-500' : 'bg-red-500'} animate-pulse`}></span>
                          <span className="font-mono text-xs font-black text-[#f1c40f] tracking-widest">{sim.serialNumber}</span>
                        </div>
                        <div className="flex flex-wrap items-center gap-3 text-[10px] text-zinc-500 font-bold">
                          <span>🧾 الفاتورة: <strong className="text-zinc-400">{sim.invoiceRef}</strong></span>
                          <span>🏢 المورد الرئيسي: <strong className="text-zinc-400">{sim.supplierName}</strong></span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 bg-zinc-900 border border-zinc-800 text-[10px] rounded text-zinc-400 font-bold">
                          المتبقي: <strong className="text-white font-mono">{sim.stock}</strong> قطع
                        </span>
                        <button
                          onClick={() => handleDeleteSIMBatch(sim.id)}
                          className="p-1 cursor-pointer text-zinc-700 hover:text-red-500 transition"
                          title="شطب"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Touch action sales triggers */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-zinc-900/50 p-2.5 rounded-lg border border-zinc-850/60">
                      
                      {/* Sell as New Option */}
                      <div className="flex justify-between items-center gap-2 text-right">
                        <div>
                          <span className="text-[9px] text-zinc-500 block">البيع كـ شريحة جديدة</span>
                          <span className="text-xs font-black text-emerald-400 font-mono">{sim.priceNew.toLocaleString()} <span className="text-[10px]">ريال</span></span>
                          <span className="text-[9px] text-zinc-600 block leading-none mt-0.5">تكلفة المشتريات: {sim.costNew}</span>
                        </div>
                        <button
                          onClick={() => handleSellSIMItem(sim.id, 'new')}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[10px] rounded-lg shadow cursor-pointer transition-all active:scale-95"
                        >
                          🏃 بيع جديد
                        </button>
                      </div>

                      {/* Sell as Replacement Option */}
                      <div className="flex justify-between items-center gap-2 text-right border-t md:border-t-0 md:border-r border-zinc-800 pt-2.5 md:pt-0 md:pr-4">
                        <div>
                          <span className="text-[9px] text-zinc-500 block">البيع كـ بدل فاقد 🔄</span>
                          <span className="text-xs font-black text-amber-500 font-mono">{sim.priceReplacement.toLocaleString()} <span className="text-[10px]">ريال</span></span>
                          <span className="text-[9px] text-zinc-600 block leading-none mt-0.5">تكلفة المشتريات: {sim.costReplacement}</span>
                        </div>
                        <button
                          onClick={() => handleSellSIMItem(sim.id, 'replacement')}
                          className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-black text-[10px] rounded-lg shadow cursor-pointer transition-all active:scale-95"
                        >
                          🔄 بيع بدل فاقد
                        </button>
                      </div>

                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
