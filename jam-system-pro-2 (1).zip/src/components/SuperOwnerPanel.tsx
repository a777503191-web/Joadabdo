import React, { useState, useMemo } from 'react';
import { 
  Store, 
  Users, 
  Plus, 
  Phone, 
  User, 
  ShieldAlert, 
  Clock, 
  Eye, 
  Coins, 
  Building, 
  Activity,
  UserCheck,
  CheckCircle,
  TrendingUp,
  Inbox,
  RotateCcw,
  Key,
  QrCode
} from 'lucide-react';
import { UserProfile, InventoryItem, Sale } from '../types';

interface ProgramStore {
  id: string;
  name: string;
  ownerName: string;
  ownerPhone: string;
  businessType?: 'mobiles' | 'motorcycles';
  createdAt: string;
}

interface SuperOwnerPanelProps {
  stores: ProgramStore[];
  users: UserProfile[];
  onAddStore: (storeName: string, ownerName: string, phone: string, defaultPassword?: string, businessType?: 'mobiles' | 'motorcycles') => void;
  currentUser: UserProfile;
  onSelectWorkingStore: (storeId: string) => void;
  workingStoreId: string;
  allSalesBySuper: Sale[];
  allInventoryBySuper: InventoryItem[];
  onUpdateUsers?: (updated: UserProfile[]) => void;
  deviceActivationCodes?: Record<string, string>;
  onUpdateActivationCodes?: React.Dispatch<React.SetStateAction<Record<string, string>>>;
}

export default function SuperOwnerPanel({
  stores,
  users,
  onAddStore,
  currentUser,
  onSelectWorkingStore,
  workingStoreId,
  allSalesBySuper,
  allInventoryBySuper,
  onUpdateUsers,
  deviceActivationCodes = {},
  onUpdateActivationCodes
}: SuperOwnerPanelProps) {
  const [isAddStoreOpen, setIsAddStoreOpen] = useState(false);
  const [lastGenerated, setLastGenerated] = useState<{ name: string; phone: string; code: string } | null>(null);

  // Form states
  const [storeName, setStoreName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [ownerPIN, setOwnerPIN] = useState('');
  const [businessType, setBusinessType] = useState<'mobiles' | 'motorcycles'>('mobiles');

  // Submit adding new store shop
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName.trim() || !ownerName.trim() || !ownerPhone.trim()) {
      alert('⚠️ الرجاء تعبئة حقول اسم المحل، اسم المالك، ورقم الهاتف للمتابعة.');
      return;
    }

    // Call callback to add store and set up default owner account
    onAddStore(
      storeName.trim(),
      ownerName.trim(),
      ownerPhone.trim(),
      ownerPIN.trim() || '1111',
      businessType
    );

    // Reset Form
    setStoreName('');
    setOwnerName('');
    setOwnerPhone('');
    setOwnerPIN('');
    setBusinessType('mobiles');
    setIsAddStoreOpen(false);

    alert(`🎉 تم نجاح قيد وتفعيل المتجر الجديد (${storeName}) وتأسيس حساب مالك فرعي معزول بنجاح!`);
  };

  // Compile calculations per store for management oversight
  const storesOverviewData = useMemo(() => {
    return stores.map(store => {
      // Find employees for this store
      const storeEmployees = users.filter(u => u.ownerId === store.id);
      // Find inventory items for this store
      const storeInv = allInventoryBySuper.filter(item => item.ownerId === store.id);
      // Find sales for this store
      const storeSales = allSalesBySuper.filter(s => s.ownerId === store.id);
      const totalSalesVolume = storeSales.reduce((acc, s) => acc + s.total, 0);

      return {
        ...store,
        employeeCount: storeEmployees.length,
        itemsCount: storeInv.length,
        salesCount: storeSales.length,
        salesTotal: totalSalesVolume
      };
    });
  }, [stores, users, allSalesBySuper, allInventoryBySuper]);

  // Find current store details
  const selectedStore = useMemo(() => {
    return stores.find(s => s.id === workingStoreId);
  }, [stores, workingStoreId]);

  // Find owner/main accounts for this store
  const storeOwnerUser = useMemo(() => {
    return users.find(u => u.ownerId === workingStoreId && u.role === 'owner') ||
           users.find(u => u.ownerId === workingStoreId);
  }, [users, workingStoreId]);

  // Aggregate super totals
  const totalStores = stores.length;
  const totalStaff = users.length;
  const totalInventoryAcrossSystem = allInventoryBySuper.length;
  const totalFinancialVolumeAcrossSystem = allSalesBySuper.reduce((acc, s) => acc + s.total, 0);

  return (
    <div className="space-y-6 font-sans text-right" dir="rtl">
      {/* 👑 Top Super Header banner */}
      <div className="p-6 bg-gradient-to-l from-zinc-950 via-zinc-900 to-zinc-950 border border-[#f1c40f]/30 rounded-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#f1c40f]/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2 py-0.5 bg-[#f1c40f]/20 border border-[#f1c40f]/40 text-[#f1c40f] rounded text-[10px] uppercase tracking-wider font-extrabold">SUPER ADMIN</span>
              <h2 className="text-lg font-black text-white flex items-center gap-1">
                لوحة تحكم مالك البرنامج الأعلى وتراخيص الفروع 👑
              </h2>
            </div>
            <p className="text-zinc-400 text-xs mt-0.5 leading-relaxed">
              مرحبًا بك م/ أبو جواد المحفلي. هنا يمكنك قيد المحلات التجارية والعملاء أصحاب المحلات، منح تراخيص الاستخدام، ومتابعة النشاط الكلي مع عزل تام ومحكم لقواعد البيانات لكل متجر.
            </p>
          </div>

          <button
            onClick={() => setIsAddStoreOpen(true)}
            className="px-5 py-2.5 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-extrabold text-xs rounded-xl shadow-[0_0_20px_rgba(241,196,15,0.2)] transition duration-150 flex items-center gap-2 cursor-pointer self-stretch md:self-auto justify-center"
            id="btn-add-partner-store"
          >
            <Plus className="w-4 h-4 text-black" />
            إضافة متجر (عميل) جديد للبرنامج
          </button>
        </div>
      </div>

      {/* 📊 Aggregations Dashboard Cards for System Master */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center gap-4">
          <div className="w-12 h-12 bg-purple-500/10 rounded-lg flex items-center justify-center border border-purple-500/20">
            <Building className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 block font-bold">المحلات والعملاء النشطين</span>
            <strong className="text-lg font-mono text-white block mt-0.5">{totalStores} محال</strong>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center gap-4">
          <div className="w-12 h-12 bg-[#f1c40f]/10 rounded-lg flex items-center justify-center border border-[#f1c40f]/20">
            <Users className="w-6 h-6 text-[#f1c40f]" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 block font-bold">إجمالي الموظفين والعمال بالنظام</span>
            <strong className="text-lg font-mono text-white block mt-0.5">{totalStaff} مستخدم</strong>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-500/10 rounded-lg flex items-center justify-center border border-emerald-500/20">
            <Inbox className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 block font-bold">المواد والقطع المعرّفة كلياً</span>
            <strong className="text-lg font-mono text-white block mt-0.5">{totalInventoryAcrossSystem} صنف</strong>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex items-center gap-4">
          <div className="w-12 h-12 bg-sky-500/10 rounded-lg flex items-center justify-center border border-sky-500/20">
            <TrendingUp className="w-6 h-6 text-sky-400" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 block font-bold">حجم المبيعات الكلية عبر النظام</span>
            <strong className="text-lg font-mono text-white block mt-0.5">${totalFinancialVolumeAcrossSystem.toFixed(2)}</strong>
          </div>
        </div>
      </div>

      <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#f1c40f] animate-pulse" />
          <div>
            <h3 className="text-xs font-bold text-white">منظومة العزل وتفقد الفروع المعزولة:</h3>
            <p className="text-[10px] text-zinc-500 mt-0.5">يمكنك تشغيل ومعاينة لوحة أي متجر في كبينة التحكم وكأنك المالك الفعلي له بالضغط على زر "تفقد وإدارة هذا المحل".</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-zinc-900 px-3 py-2 rounded-lg border border-zinc-850">
          <span className="text-[10px] text-zinc-400 font-bold">المحل النشط للمعاينة حالياً:</span>
          <span className="text-xs bg-[#f1c40f] text-black font-extrabold px-2 py-0.5 rounded font-mono">
            {stores.find(st => st.id === workingStoreId)?.name || 'غير محدد'}
          </span>
        </div>
      </div>

      {/* 📋 PARTNER STORES LIST AND TENANCY DATABASE OVERVIEW */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Store className="w-5 h-5 text-[#f1c40f]" />
            قائمة المحلات والعملاء الشريكة في JAM SYSTEM
          </h3>
          <p className="text-[11px] text-zinc-500 mt-1">توضح كل متجر مع اسم صاحبه وعدد عماله النشطين وحجم مبيعات المحل المعزول تماماً ومستقل البيانات.</p>
        </div>

        <div className="overflow-x-auto border border-zinc-850 rounded-lg">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-zinc-900 border-b border-zinc-800 text-zinc-400 font-extrabold h-10">
                <th className="px-4 py-2">رقم المعرّف (ID)</th>
                <th className="px-4 py-2">اسم المركز / المحل</th>
                <th className="px-4 py-2 text-center">نوع النشاط</th>
                <th className="px-4 py-2">مالك المحل الرئيسي</th>
                <th className="px-4 py-2">رقم الهاتف</th>
                <th className="px-4 py-2 text-center">عدد العمال والموظفين</th>
                <th className="px-4 py-2 text-center">أصناف المخزن</th>
                <th className="px-4 py-2 text-center">أرقام المبيعات</th>
                <th className="px-4 py-2 text-center">إجمالي المبيعات</th>
                <th className="px-4 py-2 text-left">خصائص التحكم</th>
              </tr>
            </thead>
            <tbody>
              {storesOverviewData.map((store) => {
                const isActive = store.id === workingStoreId;
                return (
                  <tr 
                    key={store.id} 
                    className={`border-b border-zinc-900 hover:bg-zinc-900/60 transition h-12 text-zinc-300 ${
                      isActive ? 'bg-zinc-900/40 border-r-4 border-r-[#f1c40f]' : ''
                    }`}
                  >
                    <td className="px-4 py-2 font-mono text-[10px] text-zinc-500">{store.id}</td>
                    <td className="px-4 py-2 font-bold text-white flex items-center gap-1.5 mt-2">
                      <Store className="w-3.5 h-3.5 text-[#f1c40f]" />
                      <span>{store.name}</span>
                      {isActive && (
                        <span className="text-[8px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded border border-emerald-500/30 font-bold">تحت المعاينة الفورية</span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-center">
                      {store.businessType === 'motorcycles' ? (
                        <span className="bg-amber-950/40 text-amber-500 border border-amber-800/40 px-2 py-0.5 rounded text-[10px] font-bold">
                          🏍️ دراجات نارية
                        </span>
                      ) : (
                        <span className="bg-[#f1c40f]/10 text-[#f1c40f] border border-[#f1c40f]/20 px-2 py-0.5 rounded text-[10px] font-bold">
                          📱 جوالات
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-xs font-semibold">{store.ownerName}</td>
                    <td className="px-4 py-2 font-mono text-zinc-400">{store.ownerPhone}</td>
                    <td className="px-4 py-2 text-center font-bold">
                      <span className="bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded font-mono text-zinc-300">
                        {store.employeeCount} موظفين
                      </span>
                    </td>
                    <td className="px-4 py-2 text-center font-mono">{store.itemsCount} مادة</td>
                    <td className="px-4 py-2 text-center font-mono">{store.salesCount} فاتورة</td>
                    <td className="px-4 py-2 text-center font-mono font-bold text-[#f1c40f]">${store.salesTotal.toFixed(2)}</td>
                    <td className="px-4 py-2 text-left">
                      <button
                        onClick={() => {
                          onSelectWorkingStore(store.id);
                          alert(`🔒 تم تبديل نطاق كبينة التحكم بنجاح لمحل: (${store.name}). المواد، طاقم العمل، التقارير والدرج الآن تعكس هذا النطاق المعزول.`);
                        }}
                        className={`px-3 py-1.5 rounded text-[10px] font-black transition cursor-pointer flex items-center gap-1 ${
                          isActive 
                            ? 'bg-zinc-800 text-zinc-500 cursor-default border border-zinc-700'
                            : 'bg-gradient-to-r from-emerald-900 to-emerald-850 hover:from-emerald-800 hover:to-emerald-700 text-emerald-300 border border-emerald-800/80'
                        }`}
                        disabled={isActive}
                      >
                        <Eye className="w-3.5 h-3.5" />
                        تفقد وإدارة هذا المحل 🔍
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 🔐 SECTION: SECURITY, PIN RECOVERY & DEVICE ANCHORING CONTROLS */}
      {selectedStore && storeOwnerUser && (
        <div className="bg-zinc-900 border border-[#f1c40f]/20 rounded-2xl p-5 space-y-4 animate-fadeIn">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-[#f1c40f]/10 flex items-center justify-center border border-[#f1c40f]/20">
                <ShieldAlert className="w-5 h-5 text-[#f1c40f]" />
              </div>
              <div>
                <h4 className="text-xs font-black text-white">إدارة الحماية وتراخيص الأجهزة للمحل: ({selectedStore.name}) 🛡️</h4>
                <p className="text-[10px] text-zinc-400">استعادة كلمات المرور، تصفير أجهزة الارتباط، وتوليد أكواد الترخيص والتفعيل الآمنة.</p>
              </div>
            </div>

            <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded text-[9px] font-bold font-mono">
              عزل رقمي نشط
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
            {/* Owner accounts display */}
            <div className="lg:col-span-5 bg-zinc-950 p-4 border border-zinc-850 rounded-xl space-y-3 flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-zinc-500 block font-bold mb-2">الملف التجاري لمالك المحل الرئيسي:</span>
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-400">اسم المالك الأول:</span>
                    <strong className="text-white font-bold">{storeOwnerUser.name}</strong>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-400">اسم الدخول (هاتف العمل):</span>
                    <strong className="text-zinc-200 font-mono">{storeOwnerUser.phone || 'غير مسجل'}</strong>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-400">الرمز السري الأمني الحالي (PIN):</span>
                    <strong className="text-[#f1c40f] font-mono bg-[#f1c40f]/10 border border-[#f1c40f]/20 px-2 py-0.5 rounded text-[10.5px]">
                      {storeOwnerUser.password || '1111 (الافتراضي)'}
                    </strong>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-400">صلاحية الترخيص بالنظام:</span>
                    <span className="px-1.5 py-0.2 bg-purple-500/10 text-purple-400 border border-purple-500/20 rounded text-[9px] font-bold">
                      {storeOwnerUser.isLifetime ? 'غير محدود (Lifetime)' : 'رخصة شهرية نشطة'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-zinc-900 space-y-2">
                <span className="text-[9.5px] text-zinc-500 block font-bold">الأجهزة المرتبطة المعتمدة في هذا الحساب:</span>
                <div className="flex flex-wrap gap-1.5">
                  {storeOwnerUser.trustedDevices && storeOwnerUser.trustedDevices.length > 0 ? (
                    storeOwnerUser.trustedDevices.map((dev, i) => (
                      <span key={i} className="px-2 py-0.5 bg-zinc-900 border border-zinc-800 text-zinc-400 rounded text-[9px] font-mono flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        {dev}
                      </span>
                    ))
                  ) : (
                    <span className="text-[9px] text-[#f1c40f] bg-[#f1c40f]/5 border border-[#f1c40f]/10 px-2.5 py-1 rounded">
                      ⚠️ لم يتم ربط أي كمبيوتر أو جوال بعد. سيتم الربط التلقائي فور قيامه بأول تسجيل دخول!
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Actions Panel */}
            <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* BUTTON 1: Reset PIN code */}
                <div className="bg-zinc-950 p-4 border border-zinc-850 hover:border-zinc-805 rounded-xl space-y-2.5 flex flex-col justify-between">
                  <div>
                    <h5 className="text-xs font-black text-white flex items-center gap-1">
                      <Key className="w-4 h-4 text-[#f1c40f]" />
                      استعادة الرمز السري للمحل
                    </h5>
                    <p className="text-[9.5px] text-zinc-500 mt-1 leading-relaxed">
                      يمكّنك هذا الزر من الدخول لحساب المالك المشترك وتصحيح أو إعادة تعيين PIN الدخول بدلاً من القديم المفقود.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const newPin = prompt(`أدخل الرمز السري الجديد (PIN) للمالك [${storeOwnerUser.name}]:`, storeOwnerUser.password || '1111');
                      if (newPin === null) return;
                      if (newPin.trim().length < 4) {
                        alert('⚠️ عذراً الرمز السري يجب أن يحتوي على 4 أرقام أو أحرف على الأقل!');
                        return;
                      }
                      const updated = users.map(u => u.uid === storeOwnerUser.uid ? { ...u, password: newPin.trim() } : u);
                      if (onUpdateUsers) {
                        onUpdateUsers(updated);
                        alert(`🎉 تم نجاح استعادة الرمز السري لمتجر (${selectedStore.name}) للمشترك وتعيين الرمز الجديد [ ${newPin.trim()} ] بنجاح!`);
                      }
                    }}
                    className="w-full py-2 bg-gradient-to-r from-amber-600 to-amber-500 text-white hover:opacity-90 font-extrabold text-[11px] rounded-lg transition cursor-pointer text-center"
                  >
                    استعادة وتعديل كلمة سر المحل 🔑
                  </button>
                </div>

                {/* BUTTON 2: Clear hardware bindings */}
                <div className="bg-zinc-950 p-4 border border-zinc-850 hover:border-zinc-805 rounded-xl space-y-2.5 flex flex-col justify-between">
                  <div>
                    <h5 className="text-xs font-black text-white flex items-center gap-1">
                      <RotateCcw className="w-4 h-4 text-emerald-400" />
                      تصفير الارتباط بالأجهزة 📱
                    </h5>
                    <p className="text-[9.5px] text-zinc-500 mt-1 leading-relaxed">
                      يفك الارتباط بالكمبيوتر أو الجوال القديم ويمسح السجل بحيث يمكن لصاحب المحل فتح حسابه فوراً على جوال أو كمبيوتر جديد وتوثيقه تلقائياً.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!confirm(`تحذير أمني: هل تريد تصفير الأجهزة المرتبطة لمتجر [${selectedStore.name}]؟ هذا سيمكّنه من إعادة ربط أول جهاز يدخل منه تلقائياً.`)) return;
                      const updated = users.map(u => u.uid === storeOwnerUser.uid ? { ...u, trustedDevices: [] } : u);
                      if (onUpdateUsers) {
                        onUpdateUsers(updated);
                        alert(`⚙️ تم تصفير وفك الأجهزة المرتبطة للعميل بنجاح! يمكنه الآن فتح حسابه من أي جهاز جديد ليرتبط به تلقائياً.`);
                      }
                    }}
                    className="w-full py-2 bg-[#1f1f1f] border border-zinc-800 hover:bg-zinc-850 text-zinc-300 font-extrabold text-[11px] rounded-lg transition cursor-pointer text-center flex items-center justify-center gap-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
                    تصفير الأجهزة المرتبطة للحساب
                  </button>
                </div>
              </div>

              {/* Activation Code Generator Section */}
              <div className="bg-zinc-950 p-4 border border-[#f1c40f]/10 rounded-xl space-y-3">
                <div className="flex justify-between items-center">
                  <h5 className="text-xs font-black text-white flex items-center gap-1.5">
                    <QrCode className="w-4 h-4 text-[#f1c40f]" />
                    إنشاء كود تفعيل أجهزة للعمل الإضافي
                  </h5>
                  <span className="text-[9px] text-zinc-500 font-bold font-mono">JAM SECURE GEN</span>
                </div>
                
                <p className="text-[9.5px] text-zinc-500 leading-relaxed">
                  إذا أراد المالك تشغيل الحساب على جهاز كمبيوتر أو هاتف إضافي آخر بجانب خطه الأساسي، قم بإنشاء كود تفعيل وأرسله للعميل ليكتبه في كرت فحص الترخيص.
                </p>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const phone = storeOwnerUser.phone;
                      if (!phone) {
                        alert('⚠️ لا يوجد رقم هاتف مخصص للمستخدم لإصدار كود تفعيل له!');
                        return;
                      }
                      const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
                      
                      // Write to local device_activation_codes
                      const currentCodesStr = localStorage.getItem('device_activation_codes') || '{}';
                      const currentCodes = JSON.parse(currentCodesStr);
                      currentCodes[phone] = randomCode;
                      localStorage.setItem('device_activation_codes', JSON.stringify(currentCodes));

                      if (onUpdateActivationCodes) {
                        onUpdateActivationCodes(prev => ({
                          ...prev,
                          [phone]: randomCode
                        }));
                      }
                      
                      setLastGenerated({
                        name: storeOwnerUser.name,
                        phone: phone,
                        code: randomCode
                      });
                      
                      alert(`🎉 تم نجاح إنشاء وتدوين كود تفعيل الأجهزة الجديد!\nالكود الخاص بالمتجر هو: [ ${randomCode} ]`);
                    }}
                    className="flex-1 py-2 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-extrabold text-[11px] rounded-lg transition cursor-pointer text-center flex items-center justify-center gap-1.5"
                  >
                    <QrCode className="w-3.5 h-3.5 text-black" />
                    توليد كود تفعيل جهاز جديد 🔑
                  </button>
                </div>

                {lastGenerated && lastGenerated.phone === storeOwnerUser.phone && (
                  <div className="p-3 bg-[#f1c40f]/10 border border-[#f1c40f]/30 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-2.5">
                    <div className="text-right">
                      <span className="text-[9px] text-[#f1c40f] font-bold block">كود تفعيل الأجهزة النشط حالياً:</span>
                      <strong className="text-lg font-mono text-white tracking-widest block pt-0.5">{lastGenerated.code}</strong>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(lastGenerated.code);
                          alert('📋 تم نسخ كود التفعيل إلى الحافظة بنجاح، يمكنك إرساله الآن للمستفيد عبر الواتساب!');
                        }}
                        className="px-3 py-1.5 bg-[#f1c40f] text-black text-[10px] font-black rounded hover:bg-[#d2ac0a] transition cursor-pointer"
                      >
                        نسخ الكود لإرساله 📋
                      </button>
                      
                      {(() => {
                        const cleanPhoneNum = (lastGenerated.phone || '').replace(/\D/g, '');
                        let finalPhone = cleanPhoneNum;
                        if (cleanPhoneNum.startsWith('7') && cleanPhoneNum.length === 9) {
                          finalPhone = '967' + cleanPhoneNum;
                        } else if (cleanPhoneNum.startsWith('0') && cleanPhoneNum.length === 10) {
                          finalPhone = '967' + cleanPhoneNum.slice(1);
                        }
                        const waText = `السلام عليكم ورحمة الله وبركاته، الأخ العزيز المالك شريكنا في النظام 🌹\n\nنحيطك علماً بأن كود تفعيل الأجهزة والترخيص الإضافي الخاص بمتجرك المعتمد هو:\n🔑 [ ${lastGenerated.code} ]\n\nتفضل بإدخال كود التفعيل في شاشة فحص الترخيص لربط جهازك الجديد والبدء بالعمل بنجاح.\nمع تحيات: الإدارة العامة للنظام 🇾🇪`;
                        return (
                          <a
                            href={`https://wa.me/${finalPhone}?text=${encodeURIComponent(waText)}`}
                            target="_blank"
                            referrerPolicy="no-referrer"
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black rounded transition flex items-center justify-center gap-1 cursor-pointer decoration-transparent"
                          >
                            إرسال الترخيص عبر الواتس 🟢
                          </a>
                        );
                      })()}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 🛑 MODAL: ADD PARTNER STORE */}
      {isAddStoreOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 max-w-md w-full text-right shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-[#f1c40f] to-emerald-500"></div>
            
            <div className="flex items-center gap-2 mb-4">
              <Store className="text-[#f1c40f] w-6 h-6 animate-pulse" />
              <div>
                <h3 className="font-extrabold text-white text-base">
                  تأسيس وترخيص متجر شريك جديد
                </h3>
                <p className="text-[10px] text-zinc-500">أنشئ قاعدة بيانات معزولة وحساب مالك مستقل بالكامل للمحل الجديد.</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-[11px] text-zinc-400 block mb-1">اسم المحل / المركز الجديد <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  placeholder="مثال: الفرسان للاتصالات وصيانة الموبايل"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white focus:outline-none focus:border-[#f1c40f]"
                />
              </div>

              {/* 🏷️ Select Business Classification Type */}
              <div>
                <label className="text-[11px] text-zinc-300 font-bold block mb-1.5">تصنيف ونوع نشاط المحل (لتأهيل المنتجات التلقائية) 🏷️</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setBusinessType('mobiles')}
                    className={`py-2 px-3 text-xs font-bold rounded-lg border transition cursor-pointer flex flex-col items-center justify-center gap-1 ${
                      businessType === 'mobiles'
                        ? 'bg-[#f1c40f]/10 border-[#f1c40f] text-[#f1c40f]'
                        : 'bg-zinc-950 border-zinc-850 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span className="text-sm">📱</span>
                    <span>جوالات وإلكترونيات</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setBusinessType('motorcycles')}
                    className={`py-2 px-3 text-xs font-bold rounded-lg border transition cursor-pointer flex flex-col items-center justify-center gap-1 ${
                      businessType === 'motorcycles'
                        ? 'bg-[#f1c40f]/10 border-[#f1c40f] text-[#f1c40f]'
                        : 'bg-zinc-950 border-zinc-850 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <span className="text-sm">🏍️</span>
                    <span>دراجات وبابات</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[11px] text-zinc-400 block mb-1">اسم المالك الأول للمحل <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  placeholder="مثال: م/ صادق السعيدي"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white focus:outline-none focus:border-[#f1c40f]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1">هاتف المالك (اسم المستخدم) <span className="text-rose-500">*</span></label>
                  <input
                    type="tel"
                    required
                    placeholder="770000000"
                    value={ownerPhone}
                    onChange={(e) => setOwnerPhone(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white text-left font-mono focus:outline-none focus:border-[#f1c40f]"
                  />
                  <span className="text-[9px] text-zinc-600 block mt-0.5">يسجل به من كبينة الدخول</span>
                </div>

                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1">رمز الـ PIN لولوج المالك <span className="text-[#f1c40f]">(الافتراضي)</span></label>
                  <input
                    type="text"
                    placeholder="1234"
                    value={ownerPIN}
                    onChange={(e) => setOwnerPIN(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white text-left font-mono focus:outline-none focus:border-[#f1c40f]"
                  />
                  <span className="text-[9px] text-zinc-650 block mt-0.5">مثال: 1234 أو 1111</span>
                </div>
              </div>

              <div className="text-[10px] text-zinc-500 bg-zinc-950 p-3 rounded-lg border border-zinc-850 leading-relaxed">
                ℹ️ قيد وتسجيل هذا المتجر يقوم تلقائياً بإنشاء **حساب المالك** باسم الدخول (رقم هاتف المالك للولوج) وتخصيص معرّف عزل سحابي معقّد يمنع تداخل الجرد والميزانيات أو المواد بين المتاجر.
              </div>

              <div className="flex gap-3 pt-4 border-t border-zinc-800">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-extrabold rounded text-xs transition cursor-pointer"
                >
                  تأكيد الترخيص وتأسيس المتجر ✅
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddStoreOpen(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition cursor-pointer"
                >
                  إلغاء الأمر
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
