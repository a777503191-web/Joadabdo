import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  Shield, 
  Phone, 
  Lock, 
  Mail, 
  Trash2, 
  Check, 
  Play, 
  Slash,
  AlertCircle,
  Clock
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';

interface EmployeesAndEngineersProps {
  users: UserProfile[];
  currentUser: UserProfile;
  onUpdateUsers: (updated: UserProfile[]) => void;
}

export default function EmployeesAndEngineers({
  users,
  currentUser,
  onUpdateUsers
}: EmployeesAndEngineersProps) {
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  
  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('sales');
  const [status, setStatus] = useState<UserProfile['status']>('active');

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      alert('⚠️ الرجاء تعبئة الحقول الأساسية مثل الاسم والبريد الإلكتروني');
      return;
    }

    // Check if email already exists
    if (users.some(u => u.email === email.trim())) {
      alert('⚠️ هذا البريد الإلكتروني مسجل لمستخدم آخر بالفعل!');
      return;
    }

    const newUser: UserProfile = {
      uid: `user-${Date.now().toString().slice(-6)}`,
      name: name.trim(),
      email: email.trim(),
      password: password.trim() || '123456', // default password
      phone: phone.trim() || '+967770000000',
      role,
      status,
      ownerId: currentUser.ownerId,
      custodyBalance: 0,
      trustedDevices: ['HWID-WEB-DEVICE'],
      maxDevices: 2,
    };

    onUpdateUsers([newUser, ...users]);
    alert(`🎉 تم إضافة المستخدم (${name}) بنجاح بدقة وحرص!`);
    
    // Reset form
    setName('');
    setEmail('');
    setPassword('');
    setPhone('');
    setRole('sales');
    setStatus('active');
    setIsAddUserOpen(false);
  };

  const handleToggleUserStatus = (uid: string) => {
    if (uid === currentUser.uid) {
      alert('❌ لا يمكنك تعطيل حسابك الشخصي النشط حالياً!');
      return;
    }

    const updated = users.map(u => {
      if (u.uid === uid) {
        const nextStatus: UserProfile['status'] = u.status === 'active' ? 'disabled' : 'active';
        return { ...u, status: nextStatus };
      }
      return u;
    });
    onUpdateUsers(updated);
    alert('⚡ تم تحديث مصفوفة الأمان وصلاحية المستخدم الفنية.');
  };

  const handleDeleteUser = (uid: string, userName: string) => {
    if (uid === currentUser.uid) {
      alert('❌ لا يمكنك حذف حسابك الشخصي الذي تدير المنظومة من خلاله!');
      return;
    }

    if (!confirm(`⚠️ هل أنت متأكد من حذف الحساب (${userName}) بالكامل وقص صلاحياته؟ لا يمكن التراجع عن هذا الإجراء.`)) {
      return;
    }

    const filtered = users.filter(u => u.uid !== uid);
    onUpdateUsers(filtered);
    alert('🗑️ تم إزالة المستخدم نهائياً وتصفية الدفاتر.');
  };

  const getRoleBadgeColor = (r: UserRole) => {
    switch (r) {
      case 'owner': return 'bg-purple-500/20 text-purple-400 border border-purple-500/30';
      case 'manager': return 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
      case 'engineer': return 'bg-[#f1c40f]/20 text-[#f1c40f] border border-[#f1c40f]/30';
      case 'sales': return 'bg-sky-500/20 text-sky-400 border border-sky-500/30';
      default: return 'bg-zinc-800 text-zinc-400 border border-zinc-700';
    }
  };

  const getRoleNameArabic = (r: UserRole) => {
    switch (r) {
      case 'owner': return 'المالك / المدير الأعلى';
      case 'manager': return 'مدير عام / مالي';
      case 'engineer': return 'مهندس صيانة فنية';
      case 'sales': return 'مسؤول نقطة مبيعات POS';
      case 'customer': return 'عميل معتمد';
      default: return r;
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* 🚀 Header Toolbar */}
      <div className="p-4 bg-[#0d0d0d] border border-zinc-800 rounded-lg flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-[#f1c40f]" />
            بوابة إدارة شؤون الموظفين والمهندسين وأمان الصلاحيات
          </h2>
          <p className="text-[11px] text-zinc-500 mt-0.5">تسجيل الدخول، كلمات المرور، وهواتف الطاقم الإداري ومهندسي الورش.</p>
        </div>

        <button
          onClick={() => setIsAddUserOpen(true)}
          className="px-4 py-2 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-bold text-xs rounded transition flex items-center gap-1.5 cursor-pointer"
          id="btn-add-employee"
        >
          <UserPlus className="w-4 h-4" />
          تسجيل موظف / فني جديد
        </button>
      </div>

      {/* 📋 Employees List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map((u) => {
          const isMe = u.uid === currentUser.uid;
          
          return (
            <div 
              key={u.uid} 
              id={`user-card-${u.uid}`}
              className={`bg-zinc-900 border rounded-lg p-5 flex flex-col justify-between space-y-4 shadow-md transition duration-150 ${
                isMe ? 'border-purple-500/40 relative bg-zinc-900/90' : 'border-zinc-800 hover:border-zinc-700'
              }`}
            >
              {isMe && (
                <span className="absolute top-3 left-3 bg-purple-600 text-white font-extrabold text-[8px] px-2 py-0.5 rounded shadow-md font-mono">
                  أنت الآن
                </span>
              )}

              <div className="space-y-2">
                <div className="flex justify-between items-start">
                  <div className="min-w-0">
                    <h4 className="text-sm font-bold text-white truncate max-w-[160px]" title={u.name}>
                      {u.name}
                    </h4>
                    <span className="text-[10px] text-zinc-500 font-mono block mt-0.5">ID: {u.uid}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getRoleBadgeColor(u.role)}`}>
                    {getRoleNameArabic(u.role)}
                  </span>
                </div>

                <div className="space-y-1.5 pt-3 border-t border-zinc-800 text-xs font-mono text-zinc-400">
                  <div className="flex items-center gap-1.5 min-w-0" title={u.email}>
                    <Mail className="w-3.5 h-3.5 text-zinc-500" />
                    <span className="truncate">{u.email}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-zinc-500" />
                    <span>{u.phone || 'غير محدد'}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-zinc-500" />
                    <span className="bg-[#0a0a0a] border border-zinc-850 px-1.5 py-0.2 rounded text-[10px] text-zinc-300 font-bold select-all">
                      {u.password || '123456'}
                    </span>
                    <span className="text-[9px] text-zinc-600">(كلمة السر)</span>
                  </div>

                  <div className="flex items-center gap-1.5 pt-1">
                    <Clock className="w-3.5 h-3.5 text-zinc-500" />
                    <span className="text-[10px]">الحالة الإدارية: </span>
                    <span className={`font-bold font-sans text-[10px] ${
                      u.status === 'active' ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {u.status === 'active' ? '✅ نشط جداً' : '🚫 معطل الصلاحيات'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Custody (Money collected) stats */}
              <div className="bg-[#0d0d0d] p-2.5 rounded border border-zinc-850 text-xs flex justify-between items-center text-zinc-400">
                <span>عهد العهدة المحصلة (بالكاسيت):</span>
                <strong className="text-[#f1c40f] font-mono text-xs font-bold">
                  {u.custodyBalance ? `$${u.custodyBalance}` : '$0.00'}
                </strong>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-3 border-t border-zinc-850/60 font-sans">
                <button
                  type="button"
                  onClick={() => handleToggleUserStatus(u.uid)}
                  className={`flex-1 py-1 px-2.5 rounded text-[10px] font-bold text-center transition cursor-pointer flex items-center justify-center gap-1 ${
                    u.status === 'active'
                      ? 'bg-zinc-800 hover:bg-zinc-750 text-amber-500 border border-zinc-700'
                      : 'bg-emerald-950/40 text-emerald-400 border border-emerald-800 hover:bg-emerald-900/30'
                  }`}
                >
                  <Slash className="w-3 h-3" />
                  {u.status === 'active' ? 'تجميد الحساب' : 'تنشيط الصلاحيات'}
                </button>

                <button
                  type="button"
                  onClick={() => handleDeleteUser(u.uid, u.name)}
                  className="py-1 px-2 text-zinc-500 hover:text-red-500 hover:bg-red-950/20 rounded border border-transparent hover:border-red-900/30 transition text-[10.5px]"
                  title="حذف حساب الموظف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* 🛑 MODAL: ADD USER */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-md w-full font-sans shadow-2xl">
            <div className="flex items-center gap-2 mb-4">
              <UserPlus className="text-[#f1c40f] w-5 h-5 animate-bounce" />
              <h3 className="font-bold text-white text-base">
                برمجة وتعيين موظف جديد بالمنظومة
              </h3>
            </div>

            <form onSubmit={handleAddUser} className="space-y-4">
              <div>
                <label className="text-[11px] text-zinc-400 block mb-1">الاسم الكامل للموظف <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  placeholder="مثال: المهندس جواد المحفلي"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white focus:outline-none focus:border-[#f1c40f]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1">البريد الإلكتروني (لتسجيل الدخول) <span className="text-rose-500">*</span></label>
                  <input
                    type="email"
                    required
                    placeholder="jawad@jam.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white text-left font-mono focus:outline-none focus:border-[#f1c40f]"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1">رقم الهاتف <span className="text-[#f1c40f]">(مهم للواتساب)</span></label>
                  <input
                    type="tel"
                    placeholder="772315106"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white text-left font-mono focus:outline-none focus:border-[#f1c40f]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1">كلمة المرور المشفرة للموظف</label>
                  <input
                    type="text"
                    placeholder="123456"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-white text-left font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-zinc-400 block mb-1">الصلاحية الوظيفية والرتبة</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-zinc-200 focus:outline-none focus:border-[#f1c40f]"
                  >
                    <option value="owner">المالك الأعلى للشبكة</option>
                    <option value="manager">مدير مالي ومخازن</option>
                    <option value="engineer">🔧 مهندس صيانة فنية وورشة</option>
                    <option value="sales">👤 محاسب ومبيعات الكاشير POS</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] text-zinc-400 block mb-1">حالة التفعيل الفوري</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-1 text-xs text-zinc-300 cursor-pointer">
                    <input
                      type="radio"
                      name="status_radio"
                      checked={status === 'active'}
                      onChange={() => setStatus('active')}
                      className="text-[#f1c40f] bg-zinc-950 border-zinc-800 focus:ring-0"
                    />
                    <span>نشط جداً وله كامل الصلاحية المحددة</span>
                  </label>
                  <label className="flex items-center gap-1 text-xs text-zinc-300 cursor-pointer">
                    <input
                      type="radio"
                      name="status_radio"
                      checked={status === 'disabled'}
                      onChange={() => setStatus('disabled')}
                      className="text-rose-600 bg-zinc-950 border-zinc-800 focus:ring-0"
                    />
                    <span>معطل مع الحظر التلقائي</span>
                  </label>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-zinc-800 mt-5">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-extrabold rounded text-xs transition cursor-pointer"
                >
                  حفظ وتسجيل الموظف ✅
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddUserOpen(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition cursor-pointer"
                >
                  إلغاء الأمر
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
