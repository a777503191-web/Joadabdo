/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  History, 
  User, 
  HelpCircle, 
  ClipboardCheck, 
  AlertTriangle, 
  Compass, 
  CheckCircle, 
  X,
  Lock
} from 'lucide-react';
import { ReturnFlow, InventoryItem, UserProfile } from '../types';

interface ReturnsManagerProps {
  returns: ReturnFlow[];
  inventory: InventoryItem[];
  currentUser: UserProfile;
  onAddReturn: (ret: ReturnFlow) => void;
  onApproveReturn: (id: string, destinationWarehouse: string, action: string) => void;
  onRejectReturn: (id: string) => void;
}

export default function ReturnsManager({
  returns,
  inventory,
  currentUser,
  onAddReturn,
  onApproveReturn,
  onRejectReturn
}: ReturnsManagerProps) {
  // Return Form states
  const [isNewReturnOpen, setIsNewReturnOpen] = useState(false);
  const [type, setType] = useState<'customer' | 'supplier'>('customer');
  const [itemId, setItemId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [reason, setReason] = useState('');

  // Approval config states
  const [activeApprovalId, setActiveApprovalId] = useState<string | null>(null);
  const [destinationWarehouse, setDestinationWarehouse] = useState('المستودع الرئيسي (التحرير)');
  const [financialAction, setFinancialAction] = useState<'cash_refund' | 'deduct_debt'>('cash_refund');

  const handleSubmitReturnDraft = (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedItem = inventory.find(i => i.id === itemId);
    if (!resolvedItem) {
      alert('الرجاء تحديد مادة عينية مسجلة في المخزن مسبقاً');
      return;
    }

    const calculatedTotalAmount = quantity * resolvedItem.price;

    const draft: ReturnFlow = {
      id: `ret-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      type,
      itemId,
      itemName: resolvedItem.name,
      quantity,
      totalAmount: calculatedTotalAmount,
      reason,
      inspectorId: currentUser.uid,
      inspectorName: currentUser.name,
      status: 'inspection',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onAddReturn(draft);
    setIsNewReturnOpen(false);
    setItemId('');
    setQuantity(1);
    setReason('');
  };

  const isAuthorizedToApprove = currentUser.role === 'owner' || currentUser.role === 'manager';

  return (
    <div className="space-y-6">
      
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-zinc-800 pb-5 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            🔒 قاعة تصديق وعمليات المرتجعات اللوجستية
          </h2>
          <p className="text-zinc-400 text-xs mt-1">
            عمليات الفحص الأولي من الطاقم، واعتماد التعويضات المالية الفورية والذمم من إدارة المتجر.
          </p>
        </div>
        <button
          onClick={() => setIsNewReturnOpen(true)}
          className="px-4 py-2 bg-[#f1c40f] text-black font-bold text-xs rounded hover:bg-[#d2ac0a] transition cursor-pointer flex items-center gap-1.5"
        >
          تسجيل طلب مرتجع فحص
        </button>
      </div>

      {/* Grid of active returns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left main: Pending Returns for Approval (2 columns) */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-bold text-zinc-300">الطلبات المقيدة قيد المعاينة والفحص المالي</h3>
          
          {returns.filter(r => r.status === 'inspection').length === 0 ? (
            <div className="p-8 text-center bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-500 text-xs text-center">
              لا توجد حالياً أي مرتجعات قيد الفحص الأولي.
            </div>
          ) : (
            <div className="space-y-4">
              {returns
                .filter(r => r.status === 'inspection')
                .map((order) => (
                  <div key={order.id} className="bg-zinc-900 border border-[#f1c40f]/20 rounded-lg p-5 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs px-2 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-zinc-300 font-bold font-mono">
                            #{order.id}
                          </span>
                          <span className="text-xs text-amber-400 font-semibold px-2 py-0.5 rounded bg-amber-400/5 border border-amber-400/10">
                            مطلوب فحص واعتماد
                          </span>
                        </div>
                        <h4 className="font-bold text-white mt-1 text-sm">{order.itemName}</h4>
                        <p className="text-xs text-zinc-400 font-mono mt-1">السبب: {order.reason}</p>
                      </div>
                      <div className="text-left font-mono">
                        <span className="text-white text-base font-bold">${order.totalAmount}</span>
                        <span className="text-[10px] text-zinc-500 block">العوائد لـ {order.quantity} قطع</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-zinc-500 border-t border-zinc-805/40 pt-3">
                      <span>الفاحص للمنتج: <strong>{order.inspectorName}</strong></span>
                      <span>تاريخ: {new Date(order.createdAt).toLocaleDateString()}</span>
                    </div>

                    {/* MANAGER DECISION TRIGGER */}
                    <div className="pt-3 border-t border-zinc-850 flex justify-end gap-2 text-xs">
                      {isAuthorizedToApprove ? (
                        <>
                          <button
                            onClick={() => setActiveApprovalId(order.id)}
                            className="px-4 py-1.5 bg-[#f1c40f] text-black hover:bg-[#d2ac0a] transition rounded font-bold cursor-pointer"
                          >
                            موافقة وتحديد مصير المخزون
                          </button>
                          <button
                            onClick={() => onRejectReturn(order.id)}
                            className="px-3 py-1.5 bg-zinc-800 text-zinc-400 hover:text-white rounded transition"
                          >
                            رفض الطلب
                          </button>
                        </>
                      ) : (
                        <div className="text-[11px] text-rose-400 flex items-center gap-1.5 bg-rose-500/10 px-3 py-1.5 rounded w-full justify-between">
                          <span>* هذا الإجراء يتطلب صلاحيات (مالك / مدير) لاعتماده مالياً.</span>
                          <Lock className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </div>

                    {/* Interactive Approval config context */}
                    {activeApprovalId === order.id && (
                      <div className="mt-4 p-4 rounded bg-zinc-950 border border-[#f1c40f]/20 space-y-4 animate-scaleUp">
                        <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                          <h4 className="font-semibold text-white text-xs">توجيه الجرد والمقاصّة المحررة</h4>
                          <button onClick={() => setActiveApprovalId(null)} className="text-zinc-500 hover:text-white">
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-3 text-xs">
                          <div>
                            <label className="text-zinc-400 block mb-1">المستودع المستقبل</label>
                            <select
                              value={destinationWarehouse}
                              onChange={(e) => setDestinationWarehouse(e.target.value)}
                              className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1 text-white"
                            >
                              <option value="المستودع الرئيسي (التحرير)">المستودع الرئيسي</option>
                              <option value="مستودع الفحص والصيانة">مستودع الصيانة</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-zinc-400 block mb-1">التسوية المالية القياسية</label>
                            <select
                              value={financialAction}
                              onChange={(e) => setFinancialAction(e.target.value as any)}
                              className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1 text-white"
                            >
                              <option value="cash_refund">استرداد نقدي فوري بالدرج</option>
                              <option value="deduct_debt">خصم الديون من ذمم العملاء</option>
                            </select>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            onApproveReturn(order.id, destinationWarehouse, financialAction);
                            setActiveApprovalId(null);
                          }}
                          className="w-full py-2 bg-[#f1c40f] text-black font-bold text-xs rounded hover:bg-[#d2ac0a] transition cursor-pointer"
                        >
                          ثبّت وأطلِق التغيُّير الدفتري
                        </button>
                      </div>
                    )}



                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Right side: Completed Returns History log (1 column) */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-zinc-300">سجل الترحيل التاريخي والتصديقات</h3>
          <div className="bg-zinc-900 border border-zinc-805/40 rounded-lg p-5 space-y-4">
            
            {returns.filter(r => r.status === 'completed' || r.status === 'rejected').length === 0 ? (
              <div className="text-center py-6 text-zinc-500 text-xs">
                لا توجد تسويات مرتجعة مؤرشفة للآونة الحالية.
              </div>
            ) : (
              <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                {returns
                  .filter(r => r.status === 'completed' || r.status === 'rejected')
                  .map((log) => (
                    <div key={log.id} className="p-3 bg-zinc-950 border border-zinc-800 rounded text-[11px] space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-white font-mono">#{log.id}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.status === 'completed' 
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                            : 'bg-zinc-800 text-zinc-400'
                        }`}>
                          {log.status === 'completed' ? 'تمت التسوية' : 'مرفوض'}
                        </span>
                      </div>
                      <h4 className="font-bold text-zinc-300 leading-tight">{log.itemName}</h4>
                      <p className="text-zinc-500 leading-relaxed font-mono">
                        المستودع: {log.destinationWarehouse || 'تجاهل جمركي'}
                        <br />
                        التسوية: {log.financialAction === 'cash_refund' ? 'حوالة راجحة كاش' : 'خصم ذمم العملاء'}
                      </p>
                      <div className="pt-2 border-t border-zinc-900 text-[10px] text-zinc-500 flex justify-between">
                        <span>المسؤول: {log.managerName || 'النظام'}</span>
                        <span>{new Date(log.updatedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
              </div>
            )}

          </div>
        </div>

      </div>

      {/* MODAL: DRAFT NEW RETURN FORM */}
      {isNewReturnOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-sm w-full">
            <h3 className="font-bold text-white text-base mb-4 flex items-center gap-1.5">
              <ClipboardCheck className="text-[#f1c40f] w-5 h-5" />
              تسجيل فاتورة مرتجعة وفحص جودة فنية
            </h3>
            <form onSubmit={handleSubmitReturnDraft} className="space-y-4">
              <div>
                <label className="text-xs text-zinc-400 block mb-1">حدد الصنف المطلوب إعادته</label>
                <select
                  required
                  value={itemId}
                  onChange={(e) => setItemId(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                >
                  <option value="">-- اختر السلعة المدققة --</option>
                  {inventory.map(item => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">الكمية المسحوبة</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">جهة المعاملة</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-805 px-2 py-1.5 text-xs text-white"
                  >
                    <option value="customer">عميل / مستخدم نهائي</option>
                    <option value="supplier">مورد خارجي للجملة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">توضيح تقرير العطل / المرتجع</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: غباش بالشاشة أو انتفاخ مسننات..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 pt-4 border-t border-zinc-800">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#f1c40f] text-black font-semibold rounded text-xs hover:bg-[#d2ac0a] transition cursor-pointer"
                >
                  حفظ وتعليق للفحص
                </button>
                <button
                  type="button"
                  onClick={() => setIsNewReturnOpen(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition"
                >
                  تراجع
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
