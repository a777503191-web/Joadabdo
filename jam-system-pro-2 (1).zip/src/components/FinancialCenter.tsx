/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building2, 
  Coins, 
  ArrowLeftRight, 
  FileText, 
  ChevronRight, 
  Briefcase, 
  TrendingUp, 
  Plus,
  ShieldAlert,
  Sliders,
  DollarSign,
  Printer
} from 'lucide-react';
import { AccountNode, FinancialTransaction, UserProfile } from '../types';
import { handlePrintSection } from '../utils/print';

interface FinancialCenterProps {
  accounts: AccountNode[];
  transactions: FinancialTransaction[];
  users: UserProfile[];
  currentUser: UserProfile;
  onAddTransaction: (tx: FinancialTransaction) => void;
  onReceiveCustody: (userId: string) => void;
  onAdjustAccountBalance: (id: string, amount: number) => void;
}

export default function FinancialCenter({
  accounts,
  transactions,
  users,
  currentUser,
  onAddTransaction,
  onReceiveCustody,
  onAdjustAccountBalance
}: FinancialCenterProps) {
  // Tabs within financial center
  const [financeTab, setFinanceTab] = useState<'chart' | 'logs' | 'payment-transfer' | 'salaries'>('chart');

  // Double-entry wire transfer form
  const [wireSource, setWireSource] = useState('');
  const [wireDest, setWireDest] = useState('');
  const [wireAmount, setWireAmount] = useState(1);
  const [wireReason, setWireReason] = useState('حوالة لغرض ترحيل سيولة دورية');

  // New expense form
  const [expAmount, setExpAmount] = useState(1);
  const [expCategory, setExpCategory] = useState('نفقات تشغيلية ورواتب فنية');
  const [expDesc, setExpDesc] = useState('');
  const [expAccount, setExpAccount] = useState('الصندوق النقدي العام');

  const handleWireTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (wireSource === wireDest) {
      alert('لا يمكن ترحيل السيولة لنفس الحساب مرتين!');
      return;
    }

    const sourceAcc = accounts.find(a => a.id === wireSource);
    if (!sourceAcc || sourceAcc.balance < wireAmount) {
      alert(`رصيد المصدر (${sourceAcc?.name}: $${sourceAcc?.balance}) لا يكفي للتحويل!`);
      return;
    }

    // Adjust balances
    onAdjustAccountBalance(wireSource, -Number(wireAmount));
    onAdjustAccountBalance(wireDest, Number(wireAmount));

    // Log double transaction
    const tx: FinancialTransaction = {
      id: `tx-tf-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      type: 'transfer',
      amount: Number(wireAmount),
      category: 'ترحيل ومقاصّة سيولة',
      description: `${wireReason} - من ${sourceAcc.name} إلى ${accounts.find(a => a.id === wireDest)?.name}`,
      accountId: sourceAcc.name,
      createdAt: new Date().toISOString()
    };

    onAddTransaction(tx);
    setWireAmount(1);
    setWireReason('حوالة لغرض ترحيل سيولة دورية');
    alert('تم تنفيذ ترحيل السيولة البنكية ومطابقة الدفاتر بنجاح!');
  };

  const handleAddDirectExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const sourceAcc = accounts.find(a => a.name === expAccount);
    if (!sourceAcc || sourceAcc.balance < expAmount) {
      alert(`عفواً، رصيد الحساب المالي المحدد لا يكفي لإتمام القيد الصادر!`);
      return;
    }

    onAdjustAccountBalance(sourceAcc.id, -Number(expAmount));
    
    const tx: FinancialTransaction = {
      id: `tx-ex-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      type: 'expense',
      amount: Number(expAmount),
      category: expCategory,
      description: expDesc || 'شراء لوازم أو مصاريف دورية',
      accountId: expAccount,
      createdAt: new Date().toISOString()
    };

    onAddTransaction(tx);
    setExpAmount(1);
    setExpDesc('');
    alert('تم قيد سند الصرف وتحوير أرصدة الضميمة!');
  };

  return (
    <div className="space-y-6">
      
      {/* Upper sub categories */}
      <div className="flex border-b border-zinc-805/40 pb-0 flex-wrap gap-2 overflow-x-auto">
        <button
          onClick={() => setFinanceTab('chart')}
          className={`px-5 py-2.5 text-xs font-bold transition flex items-center gap-1.5 ${
            financeTab === 'chart' 
              ? 'border-b-2 border-[#f1c40f] text-[#f1c40f]' 
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Building2 className="w-4 h-4" />
          شجرة الحسابات والخزن الرئيسية
        </button>
        <button
          onClick={() => setFinanceTab('logs')}
          className={`px-5 py-2.5 text-xs font-bold transition flex items-center gap-1.5 ${
            financeTab === 'logs' 
              ? 'border-b-2 border-[#f1c40f] text-[#f1c40f]' 
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4" />
          قيود وسندات الصرف واليومية المعترف بها
        </button>
        <button
          onClick={() => setFinanceTab('payment-transfer')}
          className={`px-5 py-2.5 text-xs font-bold transition flex items-center gap-1.5 ${
            financeTab === 'payment-transfer' 
              ? 'border-b-2 border-[#f1c40f] text-[#f1c40f]' 
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <ArrowLeftRight className="w-4 h-4" />
          قبو التسويات والتحويل والترحيل
        </button>
        <button
          onClick={() => setFinanceTab('salaries')}
          className={`px-5 py-2.5 text-xs font-bold transition flex items-center gap-1.5 ${
            financeTab === 'salaries' 
              ? 'border-b-2 border-[#f1c40f] text-[#f1c40f]' 
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          مسيرات رواتب الكادر والغياب والتحضير
        </button>
      </div>

      {/* RENDER TAB 1: CHART OF ACCOUNTS */}
      {financeTab === 'chart' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Account nodes */}
          <div className="lg:col-span-2 space-y-4">
            <h3 className="font-bold text-white text-sm">عروة القيود المالية الكبرى</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {accounts.map((acc) => (
                <div key={acc.id} className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 flex items-center justify-between group">
                  <div>
                    <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-zinc-950 text-zinc-500 border border-zinc-850">
                      رقم الكود الدفتري: {acc.code}
                    </span>
                    <h4 className="font-bold text-white text-sm mt-2">{acc.name}</h4>
                    <p className="text-zinc-500 text-[10px] mt-0.5">تصنيف المحاسبة: {acc.type === 'asset' ? 'أصول متداولة وعينية' : 'خصوم ودائنين للموردين'}</p>
                  </div>
                  <div className="text-left">
                    <span className={`text-base font-bold font-mono tracking-tight block ${
                      acc.balance < 0 ? 'text-rose-400' : 'text-[#f1c40f]'
                    }`}>
                      ${acc.balance.toLocaleString()}
                    </span>
                    <span className="text-[9px] text-zinc-500 block">نقد مقفل بالخزينة</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Expense creation column */}
          <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-lg h-fit space-y-4">
            <div>
              <h3 className="font-bold text-white text-sm">قيد سند صرف أو شراء لوازم فروع</h3>
              <p className="text-zinc-400 text-xs mt-0.5">خصم قطعي فوري يؤثر في الموازنة الإجمالية للمتجر.</p>
            </div>
            
            <form onSubmit={handleAddDirectExpense} className="space-y-4 text-xs">
              <div>
                <label className="text-zinc-400 block mb-1">مصدر سحب النقد</label>
                <select
                  value={expAccount}
                  onChange={(e) => setExpAccount(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-white"
                >
                  {accounts
                    .filter(a => a.type === 'asset' && a.balance > 0)
                    .map(a => (
                      <option key={a.id} value={a.name}>{a.name} - (متوفر: ${a.balance})</option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-zinc-400 block mb-1">قيمة المصروف ($)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={expAmount}
                    onChange={(e) => setExpAmount(parseFloat(e.target.value) || 1)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-zinc-400 block mb-1">فئة المصروف</label>
                  <select
                    value={expCategory}
                    onChange={(e) => setExpCategory(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-white"
                  >
                    <option value="نفقات تشغيلية ورواتب فنية">نفقات تشغيلية ورواتب</option>
                    <option value="نقل لوجستي وشحن">نقل لوجستي وشحن</option>
                    <option value="استرداد مبيعات">استرداد مبيعات عاطلة</option>
                    <option value="مصاريف كافية وفروع">مصاريف فروع هولندية</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">تبيان ونبذة عن سند الصرف</label>
                <input
                  type="text"
                  required
                  placeholder="ماء صحي، صيانة تكييف الفرع..."
                  value={expDesc}
                  onChange={(e) => setExpDesc(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-[#f1c40f] text-black font-bold rounded hover:bg-[#d2ac0a] transition cursor-pointer"
              >
                اعتماد وقيد مصروف من الخزنة
              </button>
            </form>
          </div>

        </div>
      )}

      {/* RENDER TAB 2: TRANSACTION LOGS */}
      {financeTab === 'logs' && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
          <div className="flex justify-between items-center mb-4 no-print">
            <h3 className="font-bold text-white text-sm">سجل الدفتر اليومي العام (General Ledger Daily Logs)</h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handlePrintSection('finance-printable-logs', 'سجل الدفتر اليومي العام وقيود الفروع والمصروفات')}
                className="px-3 py-1 bg-zinc-800 hover:bg-zinc-750 border border-zinc-700 text-[#f1c40f] font-bold text-xs rounded transition flex items-center gap-1 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                طباعة دفاتر الميزانية واليومية 🖨️
              </button>
              <span className="text-xs text-zinc-400 font-mono">طريقتين للتسوية: مباشر وشبكي</span>
            </div>
          </div>

          <div id="finance-printable-logs" className="overflow-x-auto text-xs">
            <table className="w-full border-collapse text-right">
              <thead>
                <tr className="border-b border-zinc-805/40 text-zinc-400 font-bold">
                  <th className="py-2.5">رقم السند</th>
                  <th className="py-2.5">النوع</th>
                  <th className="py-2.5">الحساب المستخدم</th>
                  <th className="py-2.5">بيان الوصف</th>
                  <th className="py-2.5">الفئة المعرّفة</th>
                  <th className="py-2.5 text-left font-mono">المبلغ المالي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/40 text-zinc-300">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-zinc-850/10">
                    <td className="py-3 font-mono font-bold text-white">#{tx.id}</td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        tx.type === 'income' 
                          ? 'bg-emerald-500/10 text-emerald-400' 
                          : tx.type === 'expense' 
                          ? 'bg-rose-500/10 text-rose-400' 
                          : 'bg-zinc-800 text-zinc-300'
                      }`}>
                        {tx.type === 'income' ? 'إيرادات مبيعات +' : tx.type === 'expense' ? 'سند صرف -' : 'ترحيل سيولة'}
                      </span>
                    </td>
                    <td className="py-3 font-medium">{tx.accountId || 'الدرج العام'}</td>
                    <td className="py-3 text-zinc-400 max-w-xs truncate">{tx.description}</td>
                    <td className="py-3">{tx.category}</td>
                    <td className="py-3 text-left font-mono font-bold text-white">${tx.amount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* RENDER TAB 3: PAYMENT / TRANSFERS */}
      {financeTab === 'payment-transfer' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          <div className="md:col-span-1 bg-zinc-900 border border-zinc-800 p-5 rounded-lg space-y-4">
            <div>
              <h3 className="font-bold text-white text-sm">سلك ترحيل النقود والموازنة البينية</h3>
              <p className="text-zinc-400 text-xs mt-0.5">
                تنزيل من حساب بنكي أو صندوق ورفعه في حساب مقابل (مثل: الكريمي إلى النجم).
              </p>
            </div>

            <form onSubmit={handleWireTransfer} className="space-y-4 text-xs">
              <div>
                <label className="text-zinc-400 block mb-1">حساب المصدر (سيتم الخصم منه)</label>
                <select
                  value={wireSource}
                  onChange={(e) => setWireSource(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-white"
                  required
                >
                  <option value="">-- اختر المصدر --</option>
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>{acc.name} - (رصيد: ${acc.balance})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">حساب المقصد (سيتم الإضافة إليه)</label>
                <select
                  value={wireDest}
                  onChange={(e) => setWireDest(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-white"
                  required
                >
                  <option value="">-- اختر المقصد --</option>
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>{acc.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-zinc-400 block mb-1 font-mono">القيمة المرحلة ($)</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={wireAmount}
                  onChange={(e) => setWireAmount(parseFloat(e.target.value) || 1)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">السبب المحاسبي للترحيل</label>
                <input
                  type="text"
                  required
                  value={wireReason}
                  onChange={(e) => setWireReason(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#f1c40f] text-black font-bold rounded hover:bg-[#d2ac0a] transition cursor-pointer"
              >
                ترحيل دفتري فوري
              </button>
            </form>
          </div>

          {/* Quick guide of distributed mobile cash boxes */}
          <div className="md:col-span-2 bg-zinc-900 border border-zinc-800 p-5 rounded-lg space-y-4">
            <h3 className="font-bold text-white text-sm">قنوات الصرافة المحلية وبنوك التداول بالمستند</h3>
            <p className="text-xs text-zinc-400">القيمة والسرية المعتمدة لأبواب الكريمي، النجم، يمن كاش في السوق العربية اليمنية.</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold">بوابة نشطة</span>
                  <span className="text-zinc-500 text-[10px]">API الكريمي v2</span>
                </div>
                <h4 className="font-bold text-white text-sm">بنك الكريمي الإسلامي المحمول</h4>
                <p className="text-zinc-400 text-xs">حوالات مبيعات تجزئة سريعة داعمة لتأكيد المعرف من العملاء.</p>
              </div>

              <div className="p-4 rounded-lg bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs px-2 py-0.5 rounded bg-amber-500/10 text-amber-500 font-bold">دفع شبكي</span>
                  <span className="text-zinc-500 text-[10px]">صرافة النجم</span>
                </div>
                <h4 className="font-bold text-white text-sm">صرافة النجم الدولي وعقد التراخيص</h4>
                <p className="text-zinc-400 text-xs">تعمل كمقاصّة لترحيل السيولة النقدية الكبيرة لتجار الجملة B2B.</p>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* RENDER TAB 4: EMPLOYEES & SALARIES */}
      {financeTab === 'salaries' && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-bold text-white text-sm">بيان مسيرات رواتب الكادر وحساب السلف والخصم</h3>
              <p className="text-xs text-zinc-400 mt-0.5">جدول آلي مركب لحساب ناتج ساعات الدوام والغيابات مع إخراج السلال السنوية.</p>
            </div>
            <span className="px-3 py-1 text-xs bg-zinc-800 text-zinc-300 rounded font-mono">طاقم الفروع: {users.length} موظفين مفعّلين</span>
          </div>

          <div className="overflow-x-auto text-xs">
            <table className="w-full border-collapse text-right">
              <thead>
                <tr className="border-b border-zinc-805/40 text-zinc-400 font-bold">
                  <th className="py-2.5">الموظف</th>
                  <th className="py-2.5">الرتبة</th>
                  <th className="py-2.5">الراتب الأساسي ($)</th>
                  <th className="py-2.5">العهد المعرّية حالياً</th>
                  <th className="py-2.5">الجزاءات والخصومات ($)</th>
                  <th className="py-2.5 text-left">التوقيع الدفتري</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/40 text-zinc-300">
                {users.map((u, i) => (
                  <tr key={i} className="hover:bg-zinc-850/15">
                    <td className="py-3 font-bold text-white">{u.name}</td>
                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-zinc-800 text-zinc-400 font-bold">
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 font-mono font-semibold">${u.role === 'owner' ? 3200 : u.role === 'manager' ? 1800 : u.role === 'engineer' ? 1000 : 650}</td>
                    <td className="py-3 font-mono text-amber-400 font-bold">${u.custodyBalance || 0}</td>
                    <td className="py-3 font-mono text-zinc-500">$0.00</td>
                    <td className="py-3 text-left">
                      <span className="text-[10px] text-emerald-400 px-2 py-0.5 bg-emerald-500/5 rounded border border-emerald-500/10 font-medium">مكتمل المطابقة التدقيقية</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
