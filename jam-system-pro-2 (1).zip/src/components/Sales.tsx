/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  ShoppingCart, 
  Trash2, 
  Printer, 
  Search, 
  User, 
  CreditCard, 
  Layers, 
  CheckCircle2, 
  Package, 
  Coins, 
  Zap, 
  AlertTriangle,
  RotateCcw,
  Check,
  DollarSign,
  Briefcase,
  Sliders,
  Barcode,
  Sparkles
} from 'lucide-react';
import { InventoryItem, SaleItem, Sale, UserProfile, AccountNode } from '../types';
import { formatMoney, roundToTwoDecimals } from '../utils/currency';

interface SalesProps {
  inventory: InventoryItem[];
  users: UserProfile[];
  accounts: AccountNode[];
  onAddSale: (sale: Sale) => void;
  currentUser: UserProfile;
}

export default function Sales({ inventory, users, accounts, onAddSale, currentUser }: SalesProps) {
  // Core POS States
  const [cart, setCart] = useState<{ 
    item: InventoryItem; 
    quantity: number; 
    unitId?: string; 
    selectedPrice: number;
    isReturn?: boolean;
    returnReason?: string;
    returnActionType?: 'damaged' | 'replacement';
  }[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [isWholesale, setIsWholesale] = useState(false);
  const [discount, setDiscount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'transfer' | 'debt'>('cash');
  const [accountId, setAccountId] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [receiptPreview, setReceiptPreview] = useState<Sale | null>(null);

  // Cashier Calculator States (For immediate change math on the spot)
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [changeDue, setChangeDue] = useState<number>(0);

  // Category list builder
  const categories = useMemo(() => {
    const cats = new Set(inventory.map(item => item.category));
    return ['All', ...Array.from(cats)];
  }, [inventory]);

  // Filter products based on search term & category selection
  const filteredProducts = useMemo(() => {
    return inventory.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            (p.barcode && p.barcode.includes(searchTerm));
      const matchesCategory = categoryFilter === 'All' || p.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [inventory, searchTerm, categoryFilter]);

  // Handle adding an item to the sales carriage
  const handleAddToCart = (product: InventoryItem, specifiedUnitId?: string) => {
    if (product.stock <= 0) {
      alert('⚠️ نعتذر، هذا الصنف نفد بالكامل ولا يوجد رصيد للاقتطاع!');
      return;
    }

    // Determine standard price based on current wholesale toggle
    let finalPrice = isWholesale ? (product.wholesalePrice || product.price) : product.price;
    let factor = 1;

    // Check if custom unit pack is selected (cartons, dozen, etc.)
    if (specifiedUnitId && product.units) {
      const foundUnit = product.units.find(u => u.id === specifiedUnitId);
      if (foundUnit) {
        finalPrice = foundUnit.price;
        factor = foundUnit.factor;
      }
    }

    const neededStock = factor;
    if (product.stock < neededStock) {
      alert(`⚠️ عبوة المبيعات المحددة تتطلب (${factor}) حبة، المتوفر بالمخزن (${product.stock}) حبة فقط.`);
      return;
    }

    const existingIndex = cart.findIndex(c => c.item.id === product.id && c.unitId === specifiedUnitId && !c.isReturn);
    if (existingIndex > -1) {
      const updated = [...cart];
      const newQty = updated[existingIndex].quantity + 1;
      
      const totalNeeded = newQty * factor;
      if (product.stock < totalNeeded) {
        alert('⚠️ لقد تجاوزت الكمية المتاحة بالكامل للفاتورة الحالية في مخازن التحرير!');
        return;
      }
      updated[existingIndex].quantity = newQty;
      setCart(updated);
    } else {
      setCart([...cart, { item: product, quantity: 1, unitId: specifiedUnitId, selectedPrice: finalPrice }]);
    }
  };

  // Live calculation utility
  const calculatedTotals = useMemo(() => {
    let subtotal = 0;
    let totalCost = 0;

    cart.forEach(c => {
      const lineTotal = roundToTwoDecimals(c.isReturn ? - (c.selectedPrice * c.quantity) : (c.selectedPrice * c.quantity));
      subtotal = roundToTwoDecimals(subtotal + lineTotal);

      const factor = c.unitId && c.item.units 
        ? (c.item.units.find(u => u.id === c.unitId)?.factor || 1)
        : 1;
      const unitCost = c.unitId && c.item.units
        ? (c.item.units.find(u => u.id === c.unitId)?.cost || c.item.cost * factor)
        : c.item.cost;
        
      const lineCost = roundToTwoDecimals(c.isReturn ? - (unitCost * c.quantity) : (unitCost * c.quantity));
      totalCost = roundToTwoDecimals(totalCost + lineCost);
    });

    const finalTotal = roundToTwoDecimals(subtotal - discount); // Allow negative total for net returns / cash refunding!
    const profit = roundToTwoDecimals(finalTotal - totalCost);

    return {
      subtotal,
      total: finalTotal,
      profit,
      totalCost
    };
  }, [cart, discount]);

  // Watch paid amount changes to recalculate money balance change
  useEffect(() => {
    if (paidAmount >= calculatedTotals.total) {
      setChangeDue(paidAmount - calculatedTotals.total);
    } else {
      setChangeDue(0);
    }
  }, [paidAmount, calculatedTotals.total]);

  // Auto-fill paid buttons triggers
  const handleQuickPay = (amount: number) => {
    if (amount === 0) {
      setPaidAmount(calculatedTotals.total);
    } else {
      setPaidAmount(amount);
    }
  };

  // Modify quantity directly from input or buttons inside cart list
  const handleUpdateQty = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(index);
      return;
    }
    const target = cart[index];
    const factor = target.unitId && target.item.units 
      ? (target.item.units.find(u => u.id === target.unitId)?.factor || 1)
      : 1;
      
    // Returns add to stock instead of subtracting, so skip stock check if return
    if (!target.isReturn && target.item.stock < newQty * factor) {
      alert(`⚠️ المخزون المتوفر في هذا الصنف هو (${target.item.stock}) حبة فقط.`);
      return;
    }
    const updated = [...cart];
    updated[index].quantity = newQty;
    setCart(updated);
  };

  const handleRemoveItem = (index: number) => {
    const updated = cart.filter((_, idx) => idx !== index);
    setCart(updated);
  };

  const handleClearCart = () => {
    if (confirm('هل أنت متأكد من مسح جميع السلع وإعادة تصفير مسودة الفاتورة؟')) {
      setCart([]);
      setDiscount(0);
      setPaidAmount(0);
    }
  };

  // Checkout submission handler
  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) {
      alert('⚠️ سلتك فارغة تماماً! الرجاء اختيار المواد وبياعتها أولاً.');
      return;
    }

    if (paymentMethod === 'transfer' && !accountId) {
      alert('⚠️ الرجاء اختيار حساب التحوية لتوثيق التحويل البنكي الكريمي/كاش المستلم.');
      return;
    }

    const saleItems: SaleItem[] = cart.map(c => {
      const factor = c.unitId && c.item.units 
        ? (c.item.units.find(u => u.id === c.unitId)?.factor || 1)
        : 1;
      return {
        id: c.item.id,
        name: c.unitId ? `${c.item.name} (${c.item.units?.find(u => u.id === c.unitId)?.name})` : c.item.name,
        quantity: c.quantity * factor, 
        price: c.selectedPrice / factor, 
        cost: c.item.cost,
        isReturn: c.isReturn,
        returnReason: c.returnReason,
        returnActionType: c.returnActionType
      };
    });

    const finalSale: Sale = {
      id: `sale-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      items: saleItems,
      total: calculatedTotals.total,
      profit: calculatedTotals.profit,
      paymentMethod,
      accountId: paymentMethod === 'transfer' ? accountId : undefined,
      customerId: selectedCustomerId || undefined,
      sellerId: currentUser.uid,
      sellerName: currentUser.name,
      isCustodyReceived: paymentMethod === 'cash' ? false : true, 
      createdAt: new Date().toISOString()
    };

    onAddSale(finalSale);
    setReceiptPreview(finalSale);
    setCart([]);
    setDiscount(0);
    setAccountId('');
    setSelectedCustomerId('');
    setPaidAmount(0);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn">
      
      {/* 1. LEFT SIDE: PRODUCTS DIRECTORY & FILTER MATRIX (7 Cols) */}
      <div className="lg:col-span-7 space-y-5">
        
        {/* Terminal Header Info Panel */}
        <div className="p-4 bg-[#0d0d0d] border border-zinc-800 rounded-lg flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#f1c40f]/10 text-[#f1c40f] border border-[#f1c40f]/20">
              <Barcode className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                كبينة محطة المبيعات اللوجستية السريعة
                <span className="text-[9px] bg-red-500/15 text-red-400 px-2 py-0.5 rounded-full border border-red-500/30">POS Term</span>
              </h2>
              <p className="text-[10px] text-zinc-500 mt-0.5 font-mono">USER_GATEWAY_SESSION_ID: {currentUser.uid.slice(0, 8)}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-xs text-zinc-400">نظام الجملة السريع:</span>
            <button
              type="button"
              onClick={() => {
                setIsWholesale(!isWholesale);
                // Adjust prices in cart if category changes
                setCart([]);
              }}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                isWholesale ? 'bg-[#f1c40f]' : 'bg-zinc-800'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-[#050505] shadow ring-0 transition duration-200 ease-in-out ${
                  isWholesale ? '-translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Unified Search & Dynamic Filters bar */}
        <div className="bg-[#0a0a0a] border border-zinc-800 rounded-lg p-3.5 space-y-3">
          <div className="relative">
            <Search className="absolute right-3.5 top-3 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="ابحث بالاسم، الموديل، المادة، أو امسح الباركود مباشرة بربط ليزري..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#050505] border border-zinc-800 rounded px-10 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#f1c40f] transition font-sans"
            />
          </div>

          {/* Categories Matrix Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`px-3.5 py-1.5 rounded text-[11px] font-bold whitespace-nowrap transition cursor-pointer ${
                  categoryFilter === cat 
                    ? 'bg-[#f1c40f] text-black shadow-[0_0_12px_rgba(241,196,15,0.25)]' 
                    : 'bg-[#0d0d0d] text-zinc-400 hover:text-white border border-zinc-800/60'
                }`}
              >
                {cat === 'All' ? '📌 جميع الفئات والقطع' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Interactive Products Grid Screen */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[580px] overflow-y-auto pr-1">
          {filteredProducts.length === 0 ? (
            <div className="col-span-2 p-12 text-center bg-[#0d0d0d] border border-zinc-850 rounded-lg text-zinc-500 text-xs">
              📂 لا توجد سلع مطابقة لمعايير البحث في مستودعات البيع الحالية.
            </div>
          ) : (
            filteredProducts.map((prod) => {
              const currentPrice = isWholesale ? (prod.wholesalePrice || prod.price) : prod.price;
              const isLowStock = prod.stock <= prod.minStock;
              
              return (
                <div 
                  key={prod.id} 
                  className={`bg-[#0d0d0d] border rounded p-4 flex flex-col justify-between hover:border-[#f1c40f]/30 transition group duration-150 ${
                    isLowStock 
                      ? 'border-amber-500/35 bg-gradient-to-b from-[#0d0d0d] to-amber-950/5' 
                      : 'border-zinc-800/80'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="font-mono px-2 py-0.5 rounded bg-[#050505] text-zinc-400 border border-zinc-800 font-bold">
                        {prod.category}
                      </span>
                      {isLowStock ? (
                        <div className="flex items-center gap-1 text-amber-500 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                          <AlertTriangle className="w-3 h-3" />
                          <span>شبه تالف/منخفض</span>
                        </div>
                      ) : (
                        <span className="text-zinc-500 font-mono">متاح للبيع</span>
                      )}
                    </div>

                    <h3 className="font-bold text-white text-xs group-hover:text-[#f1c40f] transition leading-tight">{prod.name}</h3>
                    
                    <div className="grid grid-cols-3 gap-1 pt-1.5 border-t border-zinc-800/40 text-[10px] text-zinc-500 font-mono">
                      <div>المخزون: <strong className="text-white font-bold">{prod.stock}</strong></div>
                      <div>التكلفة: <strong className="text-zinc-400">${prod.cost}</strong></div>
                      <div>الباركود: <strong className="text-zinc-400">{prod.id}</strong></div>
                    </div>
                  </div>

                  {/* Checkout interaction segment */}
                  <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-end justify-between">
                    <div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-lg font-black font-mono text-[#f1c40f]">${currentPrice}</span>
                        {isWholesale && prod.wholesalePrice && (
                          <span className="text-[9px] text-[#22c55e] font-bold">جملة</span>
                        )}
                      </div>
                      <span className="text-[9px] text-zinc-500 block">ثمن القطعة الواحدة</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleAddToCart(prod)}
                      className="px-3.5 py-1.5 text-[11px] font-bold rounded bg-zinc-800 text-[#f1c40f] hover:bg-[#f1c40f] hover:text-black transition cursor-pointer flex items-center gap-1"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      إضافة بيعة
                    </button>
                  </div>

                  {/* Dynamic Packaging options (Cartons/Packets/Dozens) */}
                  {prod.units && prod.units.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-dashed border-zinc-800/60">
                      <div className="text-[9px] text-zinc-500 mb-1.5 font-mono">عبوات بيع مجمعة متاحة:</div>
                      <div className="grid grid-cols-2 gap-1.5">
                        {prod.units.map(unit => (
                          <button
                            key={unit.id}
                            type="button"
                            onClick={() => handleAddToCart(prod, unit.id)}
                            className="px-2 py-1 bg-[#050505] text-[10px] text-zinc-300 border border-zinc-800 hover:border-[#f1c40f]/50 rounded text-right transition cursor-pointer flex justify-between items-center"
                          >
                            <span className="truncate">&bull; {unit.name}</span>
                            <strong className="text-[#f1c40f]">${unit.price}</strong>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              );
            })
          )}
        </div>

      </div>

      {/* 2. RIGHT SIDE: DETAILED CART & SECURED COIN DRAWER (5 Cols) */}
      <div className="lg:col-span-5 flex flex-col justify-between bg-[#0a0a0a] border border-zinc-800 rounded-lg p-5 min-h-[660px] shadow-xl relative">
        
        {/* Cart Item Header and clear button */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="relative">
                <ShoppingCart className="w-5 h-5 text-[#f1c40f]" />
                {cart.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white font-mono rounded-full w-4 h-4 text-[9px] flex items-center justify-center font-bold">
                    {cart.reduce((sum, c) => sum + c.quantity, 0)}
                  </span>
                )}
              </div>
              <h3 className="font-bold text-white text-xs">سلة الفاتورة الحالية</h3>
            </div>
            
            {cart.length > 0 && (
              <button
                type="button"
                onClick={handleClearCart}
                className="text-[10px] font-bold text-red-400 hover:text-red-500 transition flex items-center gap-1 cursor-pointer bg-red-500/5 px-2 py-1 rounded border border-red-500/10"
              >
                <Trash2 className="w-3.5 h-3.5" />
                تصفير السلة
              </button>
            )}
          </div>

          {/* Cart entries List */}
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="w-12 h-12 bg-[#050505] rounded-full flex items-center justify-center border border-zinc-800 text-zinc-600 mb-3">
                <Package className="w-6 h-6 animate-pulse" />
              </div>
              <p className="text-zinc-400 text-xs font-semibold">بوابة الفاتورة فارغة تماماً</p>
              <p className="text-zinc-600 text-[10px] mt-1">اضغط على "إضافة بيعة" أو فئات لقطع الغيار من جهة اليمين لتعبئة السلة.</p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
              {cart.map((cartItem, idx) => {
                const lineTotal = cartItem.isReturn 
                  ? - (cartItem.selectedPrice * cartItem.quantity) 
                  : (cartItem.selectedPrice * cartItem.quantity);
                const unitName = cartItem.unitId && cartItem.item.units 
                  ? cartItem.item.units.find(u => u.id === cartItem.unitId)?.name
                  : 'قطعة فردية';

                return (
                  <div 
                    key={idx} 
                    className={`border p-2.5 rounded space-y-2 transition font-sans ${
                      cartItem.isReturn 
                        ? 'bg-rose-950/20 border-rose-500/30' 
                        : 'bg-[#050505] border-zinc-800'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <h4 className="text-[11px] font-bold text-white truncate leading-tight flex items-center gap-1.5">
                          {cartItem.item.name}
                          {cartItem.isReturn && (
                            <span className="px-1.5 py-0.2 rounded bg-rose-500 text-white font-bold text-[8px] animate-pulse">
                              مرتجع
                            </span>
                          )}
                        </h4>
                        <div className="flex items-center gap-1.5 mt-1 text-[10px] font-mono">
                          <span className="text-zinc-400 bg-[#0d0d0d] px-1 py-0.2 rounded border border-zinc-800 text-[9px]">
                            {unitName}
                          </span>
                          <span className="text-[#f1c40f]">${cartItem.selectedPrice}</span>
                        </div>
                      </div>

                      {/* Qty controller widget */}
                      <div className="flex items-center gap-1 shrink-0 bg-[#0d0d0d] p-1 rounded border border-zinc-800">
                        <button
                          type="button"
                          onClick={() => handleUpdateQty(idx, cartItem.quantity - 1)}
                          className="w-5 h-5 rounded bg-zinc-800 hover:bg-zinc-700 text-white flex items-center justify-center text-xs font-black cursor-pointer leading-none"
                        >
                          -
                        </button>
                        <span className="w-6 text-center text-xs text-white font-bold font-mono">{cartItem.quantity}</span>
                        <button
                          type="button"
                          onClick={() => handleUpdateQty(idx, cartItem.quantity + 1)}
                          className="w-5 h-5 rounded bg-zinc-800 hover:bg-zinc-700 text-white flex items-center justify-center text-xs font-black cursor-pointer leading-none"
                        >
                          +
                        </button>
                      </div>

                      {/* Cost totals */}
                      <div className={`text-left font-bold text-[11px] w-14 shrink-0 font-mono ${cartItem.isReturn ? 'text-rose-400' : 'text-white'}`}>
                        ${lineTotal.toFixed(2)}
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="text-zinc-600 hover:text-red-500 transition p-1 shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Return details expansion block */}
                    <div className="pt-2 border-t border-zinc-900/40 flex flex-wrap items-center justify-between gap-2.5 text-[10px] text-zinc-400">
                      <label className="flex items-center gap-1.5 cursor-pointer font-bold select-none text-rose-400">
                        <input
                          type="checkbox"
                          checked={!!cartItem.isReturn}
                          onChange={(e) => {
                            const updated = [...cart];
                            updated[idx].isReturn = e.target.checked;
                            if (e.target.checked) {
                              updated[idx].returnActionType = 'replacement';
                              updated[idx].returnReason = 'تبديل فوري من السلة';
                            } else {
                              delete updated[idx].returnActionType;
                              delete updated[idx].returnReason;
                            }
                            setCart(updated);
                          }}
                          className="rounded bg-zinc-950 border-zinc-800 text-rose-600 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5 cursor-pointer"
                        />
                        <span>تحويل كارتجاع</span>
                      </label>

                      {cartItem.isReturn && (
                        <div className="flex items-center gap-2 flex-1 min-w-[150px] animate-fadeIn">
                          <input
                            type="text"
                            placeholder="سبب الارتجاع والخلل المكتشف..."
                            value={cartItem.returnReason || ''}
                            onChange={(e) => {
                              const updated = [...cart];
                              updated[idx].returnReason = e.target.value;
                              setCart(updated);
                            }}
                            className="bg-zinc-950 border border-zinc-800 rounded px-2 py-0.5 text-[9px] text-white flex-1 focus:outline-none focus:border-rose-500"
                          />

                          <select
                            value={cartItem.returnActionType || 'replacement'}
                            onChange={(e) => {
                              const updated = [...cart];
                              updated[idx].returnActionType = e.target.value as any;
                              setCart(updated);
                            }}
                            className="bg-zinc-950 border border-zinc-800 rounded px-1.5 py-0.5 text-[9px] text-zinc-300 focus:outline-none focus:border-rose-500"
                          >
                            <option value="replacement">🔄 تبديل / استبدال صنف</option>
                            <option value="damaged">⚠️ تالف / يرحل لملف التوالف</option>
                          </select>
                        </div>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* 3. COIN DRAWER & ACCOUNT SECURE SETTLEMENT FORM */}
        <form onSubmit={handleCheckoutSubmit} className="border-t border-zinc-800 pt-4 mt-4 space-y-4">
          
          {/* Quick math config row */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">الخصم الممنوح للمشتري ($)</label>
              <input
                type="number"
                min="0"
                value={discount || ''}
                onChange={(e) => setDiscount(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full bg-[#050505] border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-center text-white font-mono"
                placeholder="0"
              />
            </div>

            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">قناة ترحيل القيد المالي</label>
              <select
                value={paymentMethod}
                onChange={(e) => {
                  setPaymentMethod(e.target.value as any);
                  setAccountId('');
                  setSelectedCustomerId('');
                }}
                className="w-full bg-[#050505] border border-zinc-800 rounded px-2 py-1.5 text-xs text-white"
              >
                <option value="cash">💵 كاش (الخزنة المركزية)</option>
                <option value="transfer">🏦 تحويل بنكي/مصرفي</option>
                <option value="debt">⚖️ ذمم مدينة (آجل بالدفتر)</option>
              </select>
            </div>
          </div>

          {/* Conditional subforms based on channel selector */}
          {paymentMethod === 'transfer' && (
            <div className="p-3 bg-[#0d0d0d] border border-[#f1c40f]/20 rounded space-y-1.5 animate-fadeIn">
              <label className="text-[10px] text-zinc-400 block font-sans">حدد حساب التحويل المالي المطلوب</label>
              <select
                value={accountId}
                onChange={(e) => setAccountId(e.target.value)}
                className="w-full bg-[#050505] border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                required
              >
                <option value="">-- اختر الحساب المالي --</option>
                {accounts
                  .filter(acc => acc.code.startsWith('110')) 
                  .map(acc => (
                    <option key={acc.id} value={acc.name}>
                      {acc.name} - (متاح: ${acc.balance})
                    </option>
                  ))}
              </select>
            </div>
          )}

          {paymentMethod === 'debt' && (
            <div className="p-3 bg-[#0d0d0d] border border-zinc-800 rounded space-y-1.5 animate-fadeIn">
              <label className="text-[10px] text-zinc-400 block">اسم المندوب أو العميل الآجل</label>
              <input
                type="text"
                placeholder="ادخل اسم العميل ذي الذمة لفتح ورقة دين..."
                value={selectedCustomerId}
                onChange={(e) => setSelectedCustomerId(e.target.value)}
                className="w-full bg-[#050505] border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                required
              />
            </div>
          )}

          {/* CASH TRANSACTION CALCULATOR (FOR RETAIL SPEED) */}
          {paymentMethod === 'cash' && cart.length > 0 && (
            <div className="p-3.5 bg-[#050505] border border-zinc-800 rounded space-y-3 font-mono">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-zinc-400 font-sans">أداة حساب متبقي الكاش للعميل:</span>
                <span className="text-[10px] text-emerald-500 bg-emerald-500/10 px-1.5 rounded">نقدي فوري</span>
              </div>
              
              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <span className="text-[9px] text-zinc-500 block mb-1">المبلغ المقبوض للدرج ($)</span>
                  <input
                    type="number"
                    min="0"
                    value={paidAmount || ''}
                    onChange={(e) => setPaidAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#0d0d0d] border border-zinc-800 rounded py-1 px-2 text-xs font-bold text-[#f1c40f] text-center"
                    placeholder="0"
                  />
                </div>
                <div>
                  <span className="text-[9px] text-zinc-500 block mb-1">الباقي المرتجع للمشتري ($)</span>
                  <div className={`w-full py-1 text-center font-black text-xs border border-zinc-800 rounded ${
                    changeDue > 0 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-[#0d0d0d] text-zinc-400'
                  }`}>
                    ${changeDue.toFixed(2)}
                  </div>
                </div>
              </div>

              {/* Quick helper cash coins keypads */}
              <div className="flex flex-wrap gap-1 pt-1.5 justify-end">
                <button
                  type="button"
                  onClick={() => handleQuickPay(0)}
                  className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-white text-[9px] font-bold rounded transition cursor-pointer"
                >
                  Exact (مطابق)
                </button>
                {[5, 10, 20, 50, 100].map((note) => (
                  <button
                    key={note}
                    type="button"
                    onClick={() => handleQuickPay(note)}
                    className="px-2 py-0.5 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white text-[9px] font-bold rounded transition cursor-pointer"
                  >
                    +${note}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Grand Balance Sheets Display */}
          <div className="p-4 bg-[#050505] border border-zinc-800/80 rounded space-y-2 font-mono text-xs">
            <div className="flex justify-between text-zinc-400">
              <span>المجموع الفرعي الأولي:</span>
              <span>{formatMoney(calculatedTotals.subtotal)}</span>
            </div>

            {discount > 0 && (
              <div className="flex justify-between text-red-400">
                <span>خصم الفاتورة المستقطع:</span>
                <span>-{formatMoney(discount)}</span>
              </div>
            )}

            <div className="flex justify-between text-white font-black text-base pt-2 border-t border-zinc-800/80 border-dashed">
              <span>الإجمالي المطلوب دفعه:</span>
              <span className="text-[#f1c40f] text-lg font-black">{formatMoney(calculatedTotals.total)}</span>
            </div>

            <div className="flex justify-between text-[10px] text-zinc-500 pt-1 leading-tight font-sans">
              <span>هامش الربح المحقق (المحتسب خلف الكواليس):</span>
              <span className="text-emerald-500 font-bold font-mono">{formatMoney(calculatedTotals.profit)}</span>
            </div>
          </div>

          {/* Submit register checkout button */}
          <button
            type="submit"
            className="w-full py-3 bg-[#f1c40f] text-[#050505] font-black text-xs uppercase tracking-widest rounded shadow-[0_0_20px_rgba(241,196,15,0.25)] hover:bg-[#d2ac0a] transition duration-200 cursor-pointer flex items-center justify-center gap-2"
          >
            <Coins className="w-4 h-4" />
            ترحيل واعتماد الفاتورة المحاسبية للدفاتر
          </button>

        </form>

      </div>

      {/* 4. THERMAL RECEIPT PREVIEW MODAL */}
      {receiptPreview && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white text-zinc-900 border-4 border-zinc-300 rounded p-5 max-w-sm w-full font-mono text-[11px] space-y-4 shadow-2xl relative">
            
            {/* Design elements */}
            <div className="absolute top-1 right-2 left-2 flex justify-between text-[8px] text-zinc-400 pointer-events-none">
              <span>* THERMAL RECEIPT MODE *</span>
              <span>ISO-9001 SYSTEM</span>
            </div>

            {/* Ticket Header */}
            <div className="text-center pb-3 border-b border-dashed border-zinc-400 space-y-1 pt-2">
              <h4 className="text-sm font-black text-[#050505]">{localStorage.getItem('default_shop_name') || 'JAM SYSTEM PRO'}</h4>
              <p className="text-[10px] text-zinc-500 font-sans font-bold">{localStorage.getItem('default_shop_slogan') || 'للهواتف الإلكترونية والصيانة الفنية الدقيقة'}</p>
              <div className="h-0.5 bg-black w-1/2 mx-auto my-1"></div>
              <p className="text-[9px] text-zinc-500">{new Date(receiptPreview.createdAt).toLocaleString('ar-YE')}</p>
            </div>

            {/* General parameters */}
            <div className="py-2 border-b border-zinc-200 space-y-0.5 text-zinc-700 leading-normal">
              <p><strong>سند ترحيل رقم:</strong> {receiptPreview.id}</p>
              <p><strong>أمين الصندوق:</strong> {receiptPreview.sellerName}</p>
              <p><strong>طريقة التفريغ المالية:</strong> {
                receiptPreview.paymentMethod === 'cash' ? '💵 كاش بالخزينة' : 
                receiptPreview.paymentMethod === 'transfer' ? `🏦 تحويل بنكي (${receiptPreview.accountId})` : 
                `⚖️ دين آجل (${receiptPreview.customerId})`
              }</p>
              <p><strong>العنوان:</strong> {localStorage.getItem('default_shop_address') || 'صنعاء التحرير، اليمن'}</p>
              <p><strong>رقم هاتف العمل:</strong> {localStorage.getItem('default_shop_phone') || '772315106'}</p>
            </div>

            {/* Items table list */}
            <div className="py-2 space-y-1 border-b border-dashed border-zinc-300">
              <div className="grid grid-cols-4 font-bold text-black border-b border-zinc-200 pb-1 text-center">
                <span className="col-span-2 text-right">المادة/الوصف</span>
                <span>الكمية</span>
                <span className="text-left">المجموع</span>
              </div>
              
              {receiptPreview.items.map((it, idx) => (
                <div key={idx} className="grid grid-cols-4 text-zinc-800 py-0.5 text-center">
                  <span className="col-span-2 text-right truncate font-bold">{it.name}</span>
                  <span>{it.quantity}</span>
                  <span className="text-left font-bold">{formatMoney(it.quantity * it.price)}</span>
                </div>
              ))}
            </div>

            {/* Accounting calculations bottom */}
            <div className="py-1 space-y-1.5 text-sm font-black border-b border-zinc-900">
              <div className="flex justify-between text-xs text-zinc-500">
                <span>المجموع الكلي:</span>
                <span>{formatMoney(receiptPreview.total)}</span>
              </div>
              <div className="flex justify-between text-[#050505] text-base font-black">
                <span>الصافي المقبوض:</span>
                <span>{formatMoney(receiptPreview.total)}</span>
              </div>
            </div>

            {/* System barcodes representation */}
            <div className="text-center space-y-1 py-1">
              <div className="text-[15px] font-mono tracking-widest bg-zinc-100 text-black py-1 font-bold">
                |||| | || ||||| | |||
              </div>
              <p className="text-[8px] text-zinc-400 font-mono">MD5_VERIFIED_TRANSACTION_KEY: {receiptPreview.id}</p>
            </div>

            {/* Quick action buttons */}
            <div className="flex gap-2 pt-2 border-t border-dashed border-zinc-400">
              <button
                type="button"
                onClick={() => {
                  window.print();
                  alert('تم إرسال مستند ترحيل الفاتورة #'+ receiptPreview.id +' للطباعة الحرارية بنجاح.');
                }}
                className="flex-1 py-2 bg-[#050505] text-white rounded font-sans font-bold hover:bg-zinc-800 transition text-[11px] flex justify-center items-center gap-1.5 cursor-pointer shadow-lg"
              >
                <Printer className="w-3.5 h-3.5 text-[#f1c40f]" />
                إرسال ورق حراري
              </button>
              <button
                type="button"
                onClick={() => setReceiptPreview(null)}
                className="flex-1 py-2 bg-zinc-200 hover:bg-zinc-300 text-zinc-800 rounded font-sans font-bold transition text-[11px] cursor-pointer text-center"
              >
                إغلاق
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
