/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { handlePrintSection } from '../utils/print';
import { 
  Plus, 
  Package, 
  AlertCircle, 
  Warehouse, 
  Trash,
  AlertTriangle,
  TrendingDown,
  RefreshCcw,
  History,
  ClipboardCheck,
  Search,
  Filter,
  ArrowDownToLine,
  ThumbsUp,
  Activity,
  Archive,
  Ban,
  UserCheck,
  Printer,
  QrCode
} from 'lucide-react';
import { InventoryItem, DamagedItem, UserProfile, ReturnFlow } from '../types';

interface InventoryProps {
  inventory: InventoryItem[];
  damagedItems: DamagedItem[];
  currentUser: UserProfile;
  returns?: ReturnFlow[];
  onAddItem: (item: InventoryItem) => void;
  onUpdateItem: (item: InventoryItem) => void;
  onDeleteItem: (id: string) => void;
  onAddDamaged: (dmg: DamagedItem) => void;
  onAddReturn?: (ret: ReturnFlow) => void;
}

export default function Inventory({
  inventory,
  damagedItems,
  currentUser,
  returns = [],
  onAddItem,
  onUpdateItem,
  onDeleteItem,
  onAddDamaged,
  onAddReturn
}: InventoryProps) {
  // Sub-tabs for detailed inventory operations
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'shortages' | 'damaged' | 'returns' | 'warehouses' | 'barcodes'>('all');
  
  // --- BARCODE LABEL GENERATION & PRINT SYSTEM ---
  const [barcodeSearchQuery, setBarcodeSearchQuery] = useState('');
  const [barcodePrintList, setBarcodePrintList] = useState<Record<string, number>>({}); // maps itemId to print stickers quantity
  
  // Search and Category filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // --- SHORTAGES EXTENDED STATES ---
  const [manualShortages, setManualShortages] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('manual_shortages');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  React.useEffect(() => {
    try {
      const saved = localStorage.getItem('manual_shortages');
      if (saved) {
        setManualShortages(JSON.parse(saved));
      }
    } catch (e) {
      console.error(e);
    }
  }, [activeSubTab]);

  const [selectedShortageCategory, setSelectedShortageCategory] = useState<'all' | 'شرايح' | 'قطع غيار' | 'جوالات' | 'إكسسوارات'>('all');
  const [isAddManualShortageOpen, setIsAddManualShortageOpen] = useState(false);
  const [manualShortName, setManualShortName] = useState('');
  const [manualShortCategory, setManualShortCategory] = useState<'شرايح' | 'قطع غيار' | 'جوالات' | 'إكسسوارات'>('قطع غيار');
  const [manualShortQty, setManualShortQty] = useState(1);
  const [manualShortNotes, setManualShortNotes] = useState('');

  const [selectedShortageIds, setSelectedShortageIds] = useState<string[]>([]);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [waRecipient, setWaRecipient] = useState<'supplier' | 'owner'>('supplier');
  const [waPhone, setWaPhone] = useState('772315106');
  const [waSendScope, setWaSendScope] = useState<'all' | 'selected'>('all');
  const [waCategoryScope, setWaCategoryScope] = useState<'all' | 'current'>('all');
  // ----------------------------------

  // Modals visibility
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isDamagedOpen, setIsDamagedOpen] = useState(false);
  const [isReturnOpen, setIsReturnOpen] = useState(false);

  // New item form states
  const [name, setName] = useState('');
  const [category, setCategory] = useState('قطع غيار لشاشات');
  const [minStock, setMinStock] = useState(5);
  const [price, setPrice] = useState(0);
  const [wholesalePrice, setWholesalePrice] = useState(0);
  const [cost, setCost] = useState(0);
  const [barcode, setBarcode] = useState('');
  const [compatibility, setCompatibility] = useState('');
  const [warehouseMain, setWarehouseMain] = useState(0);
  const [warehouseSub, setWarehouseSub] = useState(0);

  // Damaged Item form state
  const [selectedDmgItemId, setSelectedDmgItemId] = useState('');
  const [dmgQty, setDmgQty] = useState(1);
  const [dmgWarehouse, setDmgWarehouse] = useState('المستودع الرئيسي (التحرير)');
  const [dmgReason, setDmgReason] = useState('خدوش داخلية أثناء النقل الجوي');

  // Quick Return form state
  const [selectedRetItemId, setSelectedRetItemId] = useState('');
  const [retQty, setRetQty] = useState(1);
  const [retType, setRetType] = useState<'customer' | 'supplier'>('customer');
  const [retReason, setRetReason] = useState('عدم ملاءمة الفولتية الفنية للمورد القياسي');

  // Warehouse dynamic states
  const [warehousesList, setWarehousesList] = useState<string[]>(() => {
    const saved = localStorage.getItem('warehousesList_pos');
    return saved ? JSON.parse(saved) : ['المستودع الرئيسي (التحرير)', 'مستودع الفحص والصيانة', 'المستودع الاحتياطي'];
  });

  const [isAddWarehouseOpen, setIsAddWarehouseOpen] = useState(false);
  const [newWarehouseName, setNewWarehouseName] = useState('');

  const [isAuditOpen, setIsAuditOpen] = useState(false);
  const [selectedAuditWarehouse, setSelectedAuditWarehouse] = useState('المستودع الرئيسي (التحرير)');
  const [auditQuantities, setAuditQuantities] = useState<{ [itemId: string]: number }>({});

  const handleAddWarehouse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWarehouseName.trim()) return;
    if (warehousesList.includes(newWarehouseName.trim())) {
      alert('⚠️ هذا المستودع موجود مسبقاً!');
      return;
    }
    const newList = [...warehousesList, newWarehouseName.trim()];
    setWarehousesList(newList);
    localStorage.setItem('warehousesList_pos', JSON.stringify(newList));
    setNewWarehouseName('');
    setIsAddWarehouseOpen(false);
    alert('🎉 تم إنشاء المستودع الجديد بنجاح ويمكنك توزيع السلع إليه الآن.');
  };

  const handleOpenAudit = (warehouseName: string) => {
    setSelectedAuditWarehouse(warehouseName);
    const initialQuants: { [itemId: string]: number } = {};
    inventory.forEach(item => {
      initialQuants[item.id] = item.warehouses?.[warehouseName] ?? 0;
    });
    setAuditQuantities(initialQuants);
    setIsAuditOpen(true);
  };

  const handleSaveAudit = () => {
    if (!confirm(`⚠️ هل أنت متأكد من حفظ نتائج الجرد ومطابقتها للمخزن (${selectedAuditWarehouse})؟ سيتم تعديل كميات الأصناف ومزامنة الأرقام المحاسبية.`)) {
      return;
    }

    inventory.forEach(item => {
      const newWhQty = auditQuantities[item.id] ?? 0;
      const warehouses = item.warehouses ? { ...item.warehouses } : {};
      warehouses[selectedAuditWarehouse] = newWhQty;

      // Sum other allocations
      const otherWarehousesSum = Object.keys(warehouses)
        .filter(k => k !== selectedAuditWarehouse)
        .reduce((sum, key) => sum + (warehouses[key] ?? 0), 0);
      
      const newTotalStock = otherWarehousesSum + newWhQty;

      onUpdateItem({
        ...item,
        stock: newTotalStock,
        warehouses
      });
    });

    setIsAuditOpen(false);
    alert('🎉 تم توثيق وحفظ قيد الجرد وإجراء المزامنة الذكية للمخزون بنجاح!');
  };

  // Categories helper definition
  const categories = useMemo(() => {
    const list = new Set(inventory.map(item => item.category));
    return ['all', ...Array.from(list)];
  }, [inventory]);

  // Filters computed lists
  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            (item.barcode && item.barcode.includes(searchQuery)) ||
                            (item.id && item.id.includes(searchQuery));
      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [inventory, searchQuery, selectedCategory]);

  // shortages: stock <= minStock
  const shortagesList = useMemo(() => {
    return inventory.filter(item => item.stock <= item.minStock);
  }, [inventory]);

  // --- SHORTAGES EXTENSION UTILITIES ---
  const mapCategoryToShortageSection = (categoryName: string): 'شرايح' | 'قطع غيار' | 'جوالات' | 'إكسسوارات' => {
    const cat = (categoryName || '').toLowerCase();
    if (cat.includes('شريحة') || cat.includes('شرايح') || cat.includes('sim') || cat.includes('اتصا') || cat.includes('رصيد')) {
      return 'شرايح';
    }
    if (cat.includes('قطع') || cat.includes('غيار') || cat.includes('صيانة') || cat.includes('شاشات') || cat.includes('بطارية') || cat.includes('سلك') || cat.includes('أدوات') || cat.includes('لحام') || cat.includes('فني')) {
      return 'قطع غيار';
    }
    if (cat.includes('جوال') || cat.includes('هاتف') || cat.includes('تلفون') || cat.includes('ايفون') || cat.includes('سامسونج') || cat.includes('شاومي') || cat.includes('جالكسي') || cat.includes('أجهزة')) {
      return 'جوالات';
    }
    return 'إكسسوارات';
  };

  const dynamicShortages = useMemo(() => {
    return shortagesList.map(item => ({
      id: item.id,
      name: item.name,
      category: mapCategoryToShortageSection(item.category),
      originalCategory: item.category,
      requiredQty: Math.max(1, item.minStock - item.stock),
      stock: item.stock,
      minStock: item.minStock,
      cost: item.cost,
      price: item.price,
      isDynamic: true,
      notes: `تنبيه الأمان التلقائي: المخزون الحالي (${item.stock}) أقل من الحد الأدنى (${item.minStock})`
    }));
  }, [shortagesList]);

  const combinedShortages = useMemo(() => {
    const formattedManuals = manualShortages.map(item => ({
      id: item.id,
      name: item.name,
      category: item.category,
      originalCategory: 'إدخال يدوي',
      requiredQty: item.requiredQty || 1,
      stock: item.stock || 0,
      minStock: item.requiredQty || 1,
      cost: 0,
      price: 0,
      isDynamic: false,
      notes: item.notes || 'تم رصد العجز يدوياً'
    }));
    return [...dynamicShortages, ...formattedManuals];
  }, [dynamicShortages, manualShortages]);

  const displayedShortages = useMemo(() => {
    if (selectedShortageCategory === 'all') return combinedShortages;
    return combinedShortages.filter(item => item.category === selectedShortageCategory);
  }, [combinedShortages, selectedShortageCategory]);

  const handleAddManualShortage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualShortName.trim()) {
      alert('⚠️ فضلاً، أدخل اسم الصنف أو العجز المطلوبة!');
      return;
    }

    const newShort = {
      id: 'short-manual-' + Date.now(),
      name: manualShortName.trim(),
      category: manualShortCategory,
      requiredQty: Number(manualShortQty) || 1,
      stock: 0,
      notes: manualShortNotes.trim() || 'إضافة يدوية عاجلة',
      createdAt: new Date().toISOString()
    };

    const updated = [newShort, ...manualShortages];
    setManualShortages(updated);
    localStorage.setItem('manual_shortages', JSON.stringify(updated));

    // Reset Form
    setManualShortName('');
    setManualShortQty(1);
    setManualShortNotes('');
    setIsAddManualShortageOpen(false);
    alert(`🎉 تم قيد القطعة الناقصة بنجاح تحت قسم: ${manualShortCategory}`);
  };

  const handleDeleteManualShortage = (id: string) => {
    if (confirm('🚫 هل أنت متأكد من حذف هذا العجز اليدوي المقيد؟')) {
      const updated = manualShortages.filter(item => item.id !== id);
      setManualShortages(updated);
      localStorage.setItem('manual_shortages', JSON.stringify(updated));
    }
  };

  const handleToggleSelectShortage = (id: string) => {
    setSelectedShortageIds(current => {
      if (current.includes(id)) {
        return current.filter(x => x !== id);
      } else {
        return [...current, id];
      }
    });
  };

  const handleSelectAllShortages = () => {
    const displayedIds = displayedShortages.map(item => item.id);
    const allDisplayedSelected = displayedIds.every(id => selectedShortageIds.includes(id));

    if (allDisplayedSelected) {
      setSelectedShortageIds(current => current.filter(id => !displayedIds.includes(id)));
    } else {
      setSelectedShortageIds(current => {
        const union = new Set([...current, ...displayedIds]);
        return Array.from(union);
      });
    }
  };

  const handleSendWhatsAppShortages = () => {
    let itemsToReport = [...combinedShortages];

    if (waSendScope === 'selected') {
      itemsToReport = itemsToReport.filter(item => selectedShortageIds.includes(item.id));
    }

    if (waCategoryScope === 'current' && selectedShortageCategory !== 'all') {
      itemsToReport = itemsToReport.filter(item => item.category === selectedShortageCategory);
    }

    if (itemsToReport.length === 0) {
      alert('⚠️ عذراً، لا يمكن إرسال كشف فارغ! حدد الأصناف أو غير النطاق للفلترة.');
      return;
    }

    const emojiMap = {
      'شرايح': '📱',
      'قطع غيار': '🔧',
      'جوالات': '🔌',
      'إكسسوارات': '🎧'
    };

    const titleText = waRecipient === 'owner' ? '*المشرف المالك المحترم*' : '*المورد اللوجستي المعتمد*';
    const currentCatTitle = selectedShortageCategory === 'all' ? 'جميع الأقسام' : `قسم ${selectedShortageCategory}`;

    let message = `السلام عليكم ورحمة الله وبركاته،\nالأخ العزيز ${titleText} 🌹\n\n`;
    message += `*📋 كشف تلقائي ويدوي بالنواقص المطلوب توريدها للورشة والمخزن*\n`;
    message += `*الجهة / المحل:* ${localStorage.getItem('default_shop_name') || 'مركز الصيانة والمخازن'}\n`;
    message += `*الأقسام المدرجة:* ${currentCatTitle}\n`;
    message += `*إجمالي الأصناف:* ${itemsToReport.length} أصناف\n`;
    message += `*تاريخ الطلب:* ${new Date().toLocaleDateString('ar-YE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\n`;
    message += `-------------------------------------------------\n\n`;

    itemsToReport.forEach((item, idx) => {
      const emoji = emojiMap[item.category as keyof typeof emojiMap] || '📦';
      message += `${idx + 1}. *${item.name}*\n`;
      message += `   ${emoji} الفئة: *${item.category}*\n`;
      message += `   🔢 الكمية المطلوبة: *${item.requiredQty}* حبة\n`;
      if (item.notes) {
        message += `   📝 ملاحظة: _${item.notes}_\n`;
      }
      message += `\n`;
    });

    message += `-------------------------------------------------\n`;
    message += `*يرجى تأمين هذه السلع بأسرع وقت لضمان ديمومة العمل وتجنب الركود والتعطيل.*`;

    let cleanPhone = waPhone.replace(/\D/g, '');
    if (cleanPhone.startsWith('7') && cleanPhone.length === 9) {
      cleanPhone = '967' + cleanPhone;
    } else if (cleanPhone.startsWith('0') && cleanPhone.length === 10) {
      cleanPhone = '967' + cleanPhone.slice(1);
    }

    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
    setIsWhatsAppModalOpen(false);
  };
  // -------------------------------------

  // Calculate quick stats
  const stats = useMemo(() => {
    const totalItemsCount = inventory.length;
    const itemsShortVal = combinedShortages.length;
    const damagedCost = damagedItems.reduce((sum, d) => sum + d.cost, 0);
    const completedReturns = returns.filter(r => r.status === 'completed');
    const pendingReturnsCount = returns.filter(r => r.status === 'inspection').length;
    
    return {
      totalItemsCount,
      itemsShortVal,
      damagedCost,
      completedReturnsCount: completedReturns.length,
      pendingReturnsCount
    };
  }, [inventory, combinedShortages, damagedItems, returns]);

  // Form Handlers
  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) {
      alert('الرجاء كتابة اسم الصنف اللوجستي أولاً');
      return;
    }

    const warehousesList: { [name: string]: number } = {
      'المستودع الرئيسي (التحرير)': Number(warehouseMain),
      'مستودع الفحص والصيانة': Number(warehouseSub)
    };

    const totalStock = Number(warehouseMain) + Number(warehouseSub);

    const newItem: InventoryItem = {
      id: barcode || `inv-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      name,
      category,
      stock: totalStock,
      minStock: Number(minStock),
      price: Number(price),
      wholesalePrice: Number(wholesalePrice) || Number(price),
      cost: Number(cost),
      lastBuyPrice: Number(cost),
      barcode: barcode || undefined,
      compatibilityList: compatibility ? compatibility.split(',').map(s => s.trim()) : undefined,
      warehouses: warehousesList,
      units: []
    };

    onAddItem(newItem);
    setIsAddOpen(false);
    resetProductForm();
  };

  const handleRegisterDamage = (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedItem = inventory.find(i => i.id === selectedDmgItemId);
    if (!resolvedItem) {
      alert('يرجى تحديد مادة صحيحة تالفة من القائمة المنسدلة');
      return;
    }

    const availableInWarehouse = resolvedItem.warehouses?.[dmgWarehouse] || 0;
    if (availableInWarehouse < dmgQty) {
      alert(`عفواً، الكمية المطلوبة تالفة (${dmgQty}) تتجاوز المتواجد الفعلي في المخزن المحدد (${availableInWarehouse})`);
      return;
    }

    // Deduct from inventory in code dynamically
    const updatedWarehouses = { ...(resolvedItem.warehouses || {}) };
    updatedWarehouses[dmgWarehouse] = Math.max(0, availableInWarehouse - Number(dmgQty));
    
    const updatedItem: InventoryItem = {
      ...resolvedItem,
      stock: Math.max(0, resolvedItem.stock - Number(dmgQty)),
      warehouses: updatedWarehouses
    };
    onUpdateItem(updatedItem);

    const damageRecord: DamagedItem = {
      id: `dmg-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      itemId: resolvedItem.id,
      itemName: resolvedItem.name,
      quantity: Number(dmgQty),
      cost: resolvedItem.cost * Number(dmgQty),
      reason: dmgReason,
      reportedBy: currentUser.uid,
      reportedByName: currentUser.name,
      createdAt: new Date().toISOString()
    };

    onAddDamaged(damageRecord);
    setIsDamagedOpen(false);
    setSelectedDmgItemId('');
    setDmgQty(1);
    setDmgReason('خدوش داخلية أثناء النقل الجوي');
  };

  const handleRegisterReturn = (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedItem = inventory.find(i => i.id === selectedRetItemId);
    if (!resolvedItem) {
      alert('الرجاء تحديد صنف صحيح لطلب المرتجع');
      return;
    }

    if (!onAddReturn) {
      alert('عفواً، ميزة إضافة المرتجع الفوري غير مهيأة بالشكل الكافي في نوافذ النطاق');
      return;
    }

    const calculatedTotalAmount = Number(retQty) * resolvedItem.price;

    const draft: ReturnFlow = {
      id: `ret-${Date.now().toString().slice(-4)}`,
      ownerId: currentUser.ownerId,
      type: retType,
      itemId: resolvedItem.id,
      itemName: resolvedItem.name,
      quantity: Number(retQty),
      totalAmount: calculatedTotalAmount,
      reason: retReason,
      inspectorId: currentUser.uid,
      inspectorName: currentUser.name,
      status: 'inspection',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onAddReturn(draft);
    setIsReturnOpen(false);
    setSelectedRetItemId('');
    setRetQty(1);
    setRetReason('عدم ملاءمة الفولتية الفنية للمورد القياسي');
  };

  const handleSimulateRestock = (item: InventoryItem) => {
    // Easily restock or place an order recommend to add +10 items
    const restockQty = item.minStock * 2 || 10;
    const updatedWarehouses = { ...(item.warehouses || {}) };
    const mainWh = 'المستودع الرئيسي (التحرير)';
    updatedWarehouses[mainWh] = (updatedWarehouses[mainWh] || 0) + restockQty;

    const updatedItem: InventoryItem = {
      ...item,
      stock: item.stock + restockQty,
      warehouses: updatedWarehouses
    };
    onUpdateItem(updatedItem);
    alert(`⚡ تم توريد وتغذية المخزون لـ (${item.name}) بزيادة (+${restockQty}) قطع في مستودع التحرير بنجاح!`);
  };

  const resetProductForm = () => {
    setName('');
    setPrice(0);
    setWholesalePrice(0);
    setCost(0);
    setBarcode('');
    setCompatibility('');
    setWarehouseMain(0);
    setWarehouseSub(0);
  };

  return (
    <div className="space-y-6">
      
      {/* Upper Status Cards Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded flex items-center justify-between shadow-md">
          <div className="space-y-1">
            <span className="text-[10px] text-zinc-400 font-bold block">إجمالي سلع الجرد الفاعلة</span>
            <span className="text-xl font-bold text-white font-mono">{stats.totalItemsCount} صنف</span>
          </div>
          <Package className="w-8 h-8 text-[#f1c40f]/20" />
        </div>

        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded flex items-center justify-between shadow-md">
          <div className="space-y-1">
            <span className="text-[10px] text-zinc-400 font-bold block">النواقص وتحت الحد الأدنى</span>
            <span className="text-xl font-bold text-red-400 font-mono flex items-center gap-1.5">
              {stats.itemsShortVal} مواد
              {stats.itemsShortVal > 0 && (
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
              )}
            </span>
          </div>
          <AlertTriangle className="w-8 h-8 text-red-500/20" />
        </div>

        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded flex items-center justify-between shadow-md">
          <div className="space-y-1">
            <span className="text-[10px] text-zinc-400 font-bold block">قيمة الخسارة من التالف</span>
            <span className="text-xl font-bold text-rose-400 font-mono">${stats.damagedCost.toLocaleString()}</span>
          </div>
          <TrendingDown className="w-8 h-8 text-rose-500/20" />
        </div>

        <div className="bg-zinc-950 border border-zinc-800 p-4 rounded flex items-center justify-between shadow-md">
          <div className="space-y-1">
            <span className="text-[10px] text-zinc-400 font-bold block">المرتجعات الموثقة</span>
            <span className="text-xl font-bold text-emerald-400 font-mono flex items-center gap-1.5">
              {returns.length} طلبات
              {stats.pendingReturnsCount > 0 && (
                <span className="text-[9px] px-1.5 py-0.5 bg-amber-500/10 text-amber-500 border border-amber-500/20 font-bold rounded">
                  {stats.pendingReturnsCount} معلق
                </span>
              )}
            </span>
          </div>
          <RefreshCcw className="w-8 h-8 text-emerald-500/20" />
        </div>

      </div>

      {/* Main Tab Controls Inside Inventory */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between border-b border-zinc-800 pb-4 gap-4">
        
        {/* Navigation sub-tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 xl:pb-0 scrollbar-none">
          <button
            onClick={() => setActiveSubTab('all')}
            className={`px-4 py-2 rounded text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeSubTab === 'all' 
                ? 'bg-[#f1c40f] text-black shadow-md' 
                : 'bg-zinc-950 border border-zinc-850 text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            <Package className="w-4 h-4" />
            جدول المواد العام ({inventory.length})
          </button>

          <button
            onClick={() => setActiveSubTab('shortages')}
            className={`px-4 py-2 rounded text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeSubTab === 'shortages' 
                ? 'bg-rose-600 text-white shadow-md' 
                : 'bg-zinc-950 border border-zinc-850 text-zinc-400 hover:text-rose-400 hover:bg-rose-950/10'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            قسم النواقص والعجز ({stats.itemsShortVal})
          </button>

          <button
            onClick={() => setActiveSubTab('damaged')}
            className={`px-4 py-2 rounded text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeSubTab === 'damaged' 
                ? 'bg-amber-600 text-white shadow-md' 
                : 'bg-zinc-950 border border-zinc-850 text-zinc-400 hover:text-amber-400 hover:bg-amber-950/10'
            }`}
          >
            <Ban className="w-4 h-4" />
            قسم التالف والفاقد ({damagedItems.length})
          </button>

          <button
            onClick={() => setActiveSubTab('returns')}
            className={`px-4 py-2 rounded text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeSubTab === 'returns' 
                ? 'bg-emerald-600 text-white shadow-md' 
                : 'bg-zinc-950 border border-zinc-850 text-zinc-400 hover:text-emerald-400 hover:bg-emerald-950/10'
            }`}
          >
            <RefreshCcw className="w-4 h-4" />
            قسم المرتجعات والذمم ({returns.length})
          </button>

          <button
            onClick={() => setActiveSubTab('warehouses')}
            className={`px-4 py-2 rounded text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeSubTab === 'warehouses' 
                ? 'bg-zinc-800 text-white shadow-md' 
                : 'bg-zinc-950 border border-zinc-850 text-zinc-400 hover:text-white'
            }`}
          >
            <Warehouse className="w-4 h-4" />
            المستودعات الجغرافية
          </button>

          <button
            onClick={() => setActiveSubTab('barcodes')}
            className={`px-4 py-2 rounded text-xs font-black transition whitespace-nowrap flex items-center gap-2 ${
              activeSubTab === 'barcodes' 
                ? 'bg-amber-500 text-black shadow-md font-black' 
                : 'bg-zinc-950 border border-zinc-850 text-zinc-400 hover:text-amber-400 hover:bg-amber-950/10'
            }`}
          >
            <QrCode className="w-4 h-4" />
            طباعة وتوليد الباركود 🏷️
          </button>
        </div>

        {/* Global actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => handlePrintSection('inventory-printable-table', 'كشف الجرد العام للأصناف والمواد بالمستودع')}
            className="px-3.5 py-2 bg-zinc-900 border border-zinc-800 hover:border-amber-500 hover:bg-amber-950/15 text-zinc-300 text-xs rounded transition flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-500" />
            <span>طباعة تقرير الجرد 🖨️</span>
          </button>

          {currentUser.role !== 'sales' && (
            <button
               onClick={() => setIsAddOpen(true)}
               className="px-4 py-2 bg-[#f1c40f] text-black font-bold text-xs rounded hover:bg-[#d2ac0a] transition flex items-center gap-1.5 cursor-pointer shadow-sm"
               id="btn-inventory-add-product"
            >
               <Plus className="w-4 h-4" />
               <span>إدخال صنف جديد بالباركود</span>
            </button>
          )}

          <button
            onClick={() => setIsDamagedOpen(true)}
            className="px-3.5 py-2 bg-rose-950/40 text-rose-400 border border-rose-900 hover:border-rose-500 hover:bg-rose-900 hover:text-white text-xs rounded transition flex items-center gap-1.5 cursor-pointer"
            id="btn-inventory-add-damage"
          >
            <AlertCircle className="w-4 h-4" />
            <span>قيد تالف عاجل</span>
          </button>

          {onAddReturn && (
            <button
              onClick={() => setIsReturnOpen(true)}
              className="px-3.5 py-2 bg-emerald-950/40 text-emerald-400 border border-emerald-950 hover:border-emerald-500 hover:bg-emerald-900 hover:text-white text-xs rounded transition flex items-center gap-1.5 cursor-pointer"
              id="btn-inventory-add-return"
            >
              <History className="w-4 h-4" />
              <span>إصدار مرتجع جديد</span>
            </button>
          )}
        </div>

      </div>

      {/* FILTER RIBBON FOR ALL ITEMS TAB */}
      {activeSubTab === 'all' && (
        <div className="bg-zinc-950 p-4 border border-zinc-850 rounded-lg flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-2 w-full md:w-auto">
            <Search className="w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="البحث بالاسم، الباركود أو الرقم التسلسلي..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full md:w-80 bg-zinc-900 border border-zinc-800 text-xs px-3 py-2 text-white rounded focus:border-[#f1c40f] focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2 scrollbar-none overflow-x-auto w-full md:w-auto">
            <span className="text-xs text-zinc-400 font-bold whitespace-nowrap flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-[#f1c40f]" />
              الفئة اللوجستية:
            </span>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded text-[11px] font-bold whitespace-nowrap border transition font-mono ${
                  selectedCategory === cat
                    ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-[#f1c40f]/40'
                    : 'bg-zinc-900 border-zinc-850 text-zinc-400 hover:text-white'
                }`}
              >
                {cat === 'all' ? 'جميع التصنيفات' : cat}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* RENDER TAB 1: ALL ITEMS TABLE */}
      {activeSubTab === 'all' && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden shadow-lg">
          <div className="p-4 bg-zinc-950 border-b border-zinc-850 flex items-center justify-between text-xs text-zinc-400">
            <div className="flex items-center gap-3">
              <span>* سجل تفصيلي يوضح كلف الشراء، تسعيرة التجزئة، وأعداد القطع المتبقية مقسمة على المستودعات.</span>
              <button
                type="button"
                onClick={() => handlePrintSection('inventory-printable-table', 'كشف جرد كميات وتقييم المواد في المخازن')}
                className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-750 border border-zinc-700 text-[#f1c40f] font-bold text-[10px] rounded transition flex items-center gap-1 cursor-pointer no-print whitespace-nowrap"
              >
                <Printer className="w-3.5 h-3.5" />
                طباعة كشف المخزن المحاسبي 🖨️
              </button>
            </div>
            <span>عدد النتائج المطابقة: {filteredInventory.length} أصناف</span>
          </div>
          
          <div id="inventory-printable-table">
            {filteredInventory.length === 0 ? (
              <div className="py-16 text-center text-zinc-500 text-xs">
                لا توجد أصناف مطابقة للبحث أو الفئة المحددة حالياً.
              </div>
            ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-right text-xs">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-400 font-bold bg-zinc-950">
                    <th className="p-4">الباركود والاسم التجاري للمادة</th>
                    <th className="p-4">الفئة المرجعية</th>
                    <th className="p-4">سعر التكلفة</th>
                    <th className="p-4 text-center">سعر جملة</th>
                    <th className="p-4 text-center">سعر التجزئة المعتمد</th>
                    <th className="p-4 text-center">مخزون المستودعات</th>
                    <th className="p-4 text-center">حالة النقص</th>
                    <th className="p-4 text-center">خيارات التحكم</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-805/40">
                  {filteredInventory.map((item) => {
                    const isShort = item.stock <= item.minStock;
                    return (
                      <tr key={item.id} className="hover:bg-zinc-850/20 text-zinc-300">
                        <td className="p-4">
                          <div className="font-bold text-white text-sm">{item.name}</div>
                          <div className="text-[10px] font-mono text-zinc-500 mt-1.5 flex items-center gap-2">
                            <span>الرمز: <strong className="text-zinc-400">{item.id}</strong></span>
                            {item.barcode && <span>• باركود: <strong className="text-zinc-400">{item.barcode}</strong></span>}
                            {item.compatibilityList && item.compatibilityList.length > 0 && (
                              <span className="text-amber-500/80 bg-amber-500/5 border border-amber-500/10 px-1 py-0.5 rounded text-[9px]">
                                متوافق: {item.compatibilityList.join(', ')}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="px-2 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-zinc-400 font-bold">
                            {item.category}
                          </span>
                        </td>
                        <td className="p-4 font-mono font-bold text-zinc-400">${item.cost || 0}</td>
                        <td className="p-4 font-mono font-semibold text-center text-zinc-300">${item.wholesalePrice || item.price}</td>
                        <td className="p-4 font-mono font-bold text-center text-[#f1c40f]">${item.price}</td>
                        <td className="p-4 text-center">
                          <div className="inline-flex flex-col gap-1 items-end">
                            <span className="font-mono text-white font-bold">{item.stock} حبة</span>
                            <span className="text-[9px] text-zinc-500 whitespace-nowrap">
                              الرئيسي ({item.warehouses?.['المستودع الرئيسي (التحرير)'] || 0}) • الورشة ({item.warehouses?.['مستودع الفحص والصيانة'] || 0})
                            </span>
                          </div>
                        </td>
                        <td className="p-4 text-center">
                          {isShort ? (
                            <span className="px-2 py-1 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20 font-bold text-[10px] inline-flex items-center gap-1 animate-pulse">
                              <AlertTriangle className="w-3 h-3" />
                              دون الحد ({item.minStock})
                            </span>
                          ) : (
                            <span className="px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold text-[10px] inline-flex items-center gap-1">
                              <ThumbsUp className="w-3 h-3" />
                              آمن وممتاز
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {isShort && (
                              <button
                                onClick={() => handleSimulateRestock(item)}
                                className="px-2 py-1 bg-zinc-800 hover:bg-[#f1c40f] hover:text-black rounded text-[10px] font-black text-zinc-400 transition cursor-pointer"
                                title="توريد تكميلي سريع"
                              >
                                تغذية بقوة +{item.minStock * 2}
                              </button>
                            )}
                            {currentUser.role !== 'sales' && (
                              <button
                                onClick={() => {
                                  if (confirm(`هل أنت متأكد من حذف وإسقاط الصنف (${item.name}) نهائياً من الجداول؟`)) {
                                    onDeleteItem(item.id);
                                  }
                                }}
                                className="p-1.5 rounded text-zinc-500 hover:bg-zinc-800 hover:text-rose-400 transition"
                                title="حذف الصنف"
                              >
                                <Trash className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
          </div>
        </div>
      )}

      {/* RENDER TAB 2: SHORTAGES SECTION (قسم النواقص والعجز) */}
      {activeSubTab === 'shortages' && (
        <div className="space-y-4 animate-fade-in">
          <div className="bg-[#1c0c0c] border border-rose-900/30 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
                منظومة الكشف وإدارة النواقص والعجوزات بالمخزن والورشة
              </h3>
              <p className="text-zinc-400 text-[11px]">
                تجمع هذه المنظومة تلقائياً كافة الأصناف اللوجستية التي هبطت تحت حد الأمان المطلوب، بالإضافة للمواد والنواقص التي قيدها المهندسون يدوياً أو تم استيرادها تلقائياً من بطاقات الصيانة.
              </p>
            </div>

            <div className="flex gap-2 shrink-0">
              <button
                onClick={() => setIsAddManualShortageOpen(true)}
                className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-extrabold rounded text-xs transition flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Plus className="w-3.5 h-3.5" />
                إضافة نقص يدوي ➕
              </button>

              <button
                onClick={() => {
                  if (combinedShortages.length === 0) {
                    alert('⚠️ لا توجد أي نواقص في الكشف لإرسالها!');
                    return;
                  }
                  setIsWhatsAppModalOpen(true);
                }}
                className="px-3.5 py-2 bg-[#25d366]/20 border border-[#25d366]/40 text-[#25d366] hover:bg-[#25d366]/30 font-extrabold rounded text-xs transition flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <span className="text-[11px]">📱</span>
                إرسال الكشف واتساب
              </button>
            </div>
          </div>

          {/* CLASSIFICATION TABS / SECTORS */}
          <div className="bg-zinc-900/40 p-1 rounded-xl border border-zinc-800 flex flex-wrap gap-1">
            {[
              { id: 'all', label: '🗂️ كافة القطاعات', count: combinedShortages.length },
              { id: 'شرايح', label: '📱 شرائح SIM ورصيد', count: combinedShortages.filter(item => item.category === 'شرايح').length },
              { id: 'قطع غيار', label: '🔧 قطع غيار الصيانة', count: combinedShortages.filter(item => item.category === 'قطع غيار').length },
              { id: 'جوالات', label: '🔌 هواتف وجوالات', count: combinedShortages.filter(item => item.category === 'جوالات').length },
              { id: 'إكسسوارات', label: '🎧 إكسسوارات وملحقات', count: combinedShortages.filter(item => item.category === 'إكسسوارات').length }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setSelectedShortageCategory(tab.id as any)}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 ${
                  selectedShortageCategory === tab.id
                    ? 'bg-[#f1c40f] text-black shadow-md font-black'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900 bg-transparent'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`px-2 py-0.5 text-[10px] rounded-full font-mono ${
                  selectedShortageCategory === tab.id ? 'bg-black/10 text-black' : 'bg-zinc-950 text-zinc-500'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
            <div className="p-4 bg-zinc-950 border-b border-zinc-850 flex items-center justify-between text-xs font-bold text-zinc-400 flex-wrap gap-2">
              <div className="flex items-center gap-3">
                <span className="text-rose-400 font-extrabold">قيد الاستعراض: {displayedShortages.length} أصناف</span>
                <span className="text-zinc-500">|</span>
                <span className="text-amber-400">المحدد للإرسال: {selectedShortageIds.length} عناصر</span>
              </div>
              <button
                onClick={handleSelectAllShortages}
                className="px-2.5 py-1 bg-zinc-850 hover:bg-zinc-800 text-zinc-300 rounded text-[10px] border border-zinc-800 transition cursor-pointer"
              >
                {displayedShortages.every(item => selectedShortageIds.includes(item.id)) ? 'إلغاء تحديد الكل' : 'تحديد كل المعروض'}
              </button>
            </div>

            {displayedShortages.length === 0 ? (
              <div className="py-20 text-center text-zinc-500 text-xs space-y-2">
                <p className="font-extrabold text-emerald-400 text-sm">✨ لا توجد نواقص في هذا القسم !</p>
                <p>جميع السلع اللوجستية في قسم ({selectedShortageCategory === 'all' ? 'الكل' : selectedShortageCategory}) لديها مخزونات كافية.</p>
              </div>
            ) : (
              <div className="overflow-x-auto text-xs">
                <table className="w-full border-collapse text-right">
                  <thead>
                    <tr className="border-b border-zinc-800 bg-zinc-950 text-zinc-400 font-bold select-none">
                      <th className="p-4 text-center w-12">تحديد</th>
                      <th className="p-4">البيان والصنف</th>
                      <th className="p-4">القسم والنوع</th>
                      <th className="p-4">كود التعقب والمنشأ</th>
                      <th className="p-4 text-center">الكمية اللوجستية الحالية</th>
                      <th className="p-4 text-center text-rose-400">العجز والطلب المطلق</th>
                      <th className="p-4">تفاصيل وحالة العطل</th>
                      <th className="p-4 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/40 text-zinc-300">
                    {displayedShortages.map((item, idx) => {
                      const isSelected = selectedShortageIds.includes(item.id);
                      return (
                        <tr
                          key={item.id}
                          className={`hover:bg-rose-500/[0.01] transition-all duration-150 ${
                            isSelected ? 'bg-rose-500/[0.02]/30' : ''
                          }`}
                        >
                          <td className="p-4 text-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => handleToggleSelectShortage(item.id)}
                              className="w-4 h-4 rounded bg-zinc-950 border-zinc-800 text-[#f1c40f] focus:ring-0 cursor-pointer"
                            />
                          </td>
                          <td className="p-4">
                            <div className="font-extrabold text-white text-sm flex items-center gap-2">
                              {item.name}
                              {!item.isDynamic && (
                                <span className="px-1.5 py-0.5 bg-rose-950/40 text-rose-400 border border-rose-900/40 rounded text-[9px] font-bold">
                                  يدوي ✍️
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-4">
                            <span className={`px-2 py-0.5 rounded border text-[10px] font-bold ${
                              item.category === 'شرايح' ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' :
                              item.category === 'قطع غيار' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' :
                              item.category === 'جوالات' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                              'bg-zinc-800 text-zinc-300 border-zinc-700'
                            }`}>
                              {item.category}
                            </span>
                          </td>
                          <td className="p-4 font-mono text-[10px] text-zinc-500">
                            ID: {item.id.slice(-6)}
                            <span className="block text-[9px] text-[#f1c40f]/60">{item.originalCategory}</span>
                          </td>
                          <td className="p-4 text-center font-mono text-zinc-400 font-bold">
                            {item.stock} قطع
                          </td>
                          <td className="p-4 text-center font-mono font-black text-rose-500 text-sm">
                            -{item.requiredQty} حبة
                          </td>
                          <td className="p-4 text-zinc-400 text-[11px] max-w-xs truncate">
                            {item.notes}
                          </td>
                          <td className="p-4 text-center">
                            {item.isDynamic ? (
                              <button
                                onClick={() => handleSimulateRestock(item as any)}
                                className="px-2.5 py-1 bg-zinc-850 hover:bg-zinc-800 text-zinc-300 font-bold rounded text-[10px] transition cursor-pointer flex items-center gap-1 mx-auto"
                              >
                                <ArrowDownToLine className="w-3 h-3 text-[#f1c40f]" />
                                توريد فوري
                              </button>
                            ) : (
                              <button
                                onClick={() => handleDeleteManualShortage(item.id)}
                                className="px-2.5 py-1 bg-rose-650/20 hover:bg-rose-600 border border-rose-900/40 hover:text-white text-rose-400 font-bold rounded text-[10px] transition cursor-pointer flex items-center gap-1 mx-auto"
                              >
                                🗑️ حذف
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* ADD MANUAL SHORTAGE MODAL */}
          {isAddManualShortageOpen && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl max-w-md w-full p-6 space-y-4 shadow-xl text-right animate-scale-up" dir="rtl">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                  <h3 className="text-white font-extrabold text-sm flex items-center gap-2">
                    <span>✍️</span> قيد نقص أو طلب بضاعة يدوي
                  </h3>
                  <button
                    onClick={() => setIsAddManualShortageOpen(false)}
                    className="text-zinc-500 hover:text-white transition font-mono text-lg"
                  >
                    ×
                  </button>
                </div>

                <form onSubmit={handleAddManualShortage} className="space-y-4 text-xs">
                  <div>
                    <label className="text-zinc-400 block mb-1 font-bold">اسم القطعة أو الصنف الناقص بالتفصيل</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: شاشة شاومي ريدمي نوت 12..."
                      value={manualShortName}
                      onChange={(e) => setManualShortName(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded p-2.5 text-xs text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-zinc-400 block mb-1 font-bold">القسم المستهدف</label>
                      <select
                        value={manualShortCategory}
                        onChange={(e) => setManualShortCategory(e.target.value as any)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-xs text-zinc-300 font-bold"
                      >
                        <option value="قطع غيار">🔧 قطع غيار الصيانة</option>
                        <option value="شرايح">📱 شرائح SIM ورصيد</option>
                        <option value="جوالات">🔌 هواتف وجوالات</option>
                        <option value="إكسسوارات">🎧 إكسسوارات وملحقات</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-zinc-400 block mb-1 font-bold">الكمية المطلوبة لتأمين العجز</label>
                      <input
                        type="number"
                        min="1"
                        required
                        value={manualShortQty}
                        onChange={(e) => setManualShortQty(parseInt(e.target.value) || 1)}
                        className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-xs text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-zinc-400 block mb-1 font-bold">ملاحظات وسبب الطلب (اختياري)</label>
                    <textarea
                      placeholder="مثال: مطلوبة لتكملة معاملة زبون عاجل أو لتغطية النقص الأسبوعي..."
                      value={manualShortNotes}
                      onChange={(e) => setManualShortNotes(e.target.value)}
                      rows={3}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded p-2.5 text-xs text-white"
                    />
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-extrabold rounded text-xs transition cursor-pointer"
                    >
                      تقييد في كشف النواقص 💾
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsAddManualShortageOpen(false)}
                      className="flex-1 py-2.5 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition cursor-pointer"
                    >
                      تراجع
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* WHATSAPP SHARING OPTIONS MODAL */}
          {isWhatsAppModalOpen && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-zinc-900 border border-zinc-800 rounded-xl max-w-md w-full p-6 space-y-4 shadow-xl text-right animate-scale-up" dir="rtl">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                  <h3 className="text-white font-extrabold text-sm flex items-center gap-1.5">
                    <span>📱</span> إعدادات إرسال كشف النواقص عبر الواتساب
                  </h3>
                  <button
                    onClick={() => setIsWhatsAppModalOpen(false)}
                    className="text-zinc-500 hover:text-white transition font-mono text-lg"
                  >
                    ×
                  </button>
                </div>

                <div className="space-y-4 text-xs">
                  <div>
                    <label className="text-zinc-400 block mb-1 font-bold">الجهة المستهدفة للطلب</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setWaRecipient('supplier');
                          setWaPhone('772315106'); // Sample supplier default
                        }}
                        className={`p-2.5 rounded border text-center transition font-bold ${
                          waRecipient === 'supplier'
                            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-[#f1c40f]'
                            : 'bg-zinc-950 text-zinc-400 border-zinc-850 hover:text-white'
                        }`}
                      >
                        💼 المورد الخارجي
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setWaRecipient('owner');
                          setWaPhone('772315106'); // Owner phone
                        }}
                        className={`p-2.5 rounded border text-center transition font-bold ${
                          waRecipient === 'owner'
                            ? 'bg-[#f1c40f]/10 text-[#f1c40f] border-[#f1c40f]'
                            : 'bg-zinc-950 text-zinc-400 border-zinc-850 hover:text-white'
                        }`}
                      >
                        👑 المالك (أبو جواد المحفلي)
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-zinc-400 block mb-1 font-bold">رقم الواتساب المستلم (تحت كود اليمن +967)</label>
                    <input
                      type="text"
                      value={waPhone}
                      onChange={(e) => setWaPhone(e.target.value)}
                      placeholder="772315106..."
                      className="w-full bg-zinc-950 border border-zinc-800 rounded p-2.5 text-xs text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-zinc-400 block mb-1 font-bold">العناصر المزمع إرسالها (الكميات)</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setWaSendScope('all')}
                        className={`p-2 rounded border text-center transition ${
                          waSendScope === 'all'
                            ? 'bg-zinc-800 text-white border-zinc-700'
                            : 'bg-zinc-950 text-zinc-500 border-zinc-850 hover:text-zinc-300'
                        }`}
                      >
                        📦 إرسال الكشف الكلي للقسم
                      </button>
                      <button
                        type="button"
                        onClick={() => setWaSendScope('selected')}
                        className={`p-2 rounded border text-center transition ${
                          waSendScope === 'selected'
                            ? 'bg-zinc-800 text-white border-zinc-700'
                            : 'bg-zinc-950 text-zinc-500 border-zinc-850 hover:text-zinc-300'
                        }`}
                      >
                        ✔️ العناصر المحددة فقط ({selectedShortageIds.length})
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-zinc-400 block mb-1 font-bold">تصنيف جميع القطاعات أم قسم واحد</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setWaCategoryScope('all')}
                        className={`p-2 rounded border text-center transition ${
                          waCategoryScope === 'all'
                            ? 'bg-zinc-800 text-white border-zinc-700'
                            : 'bg-zinc-950 text-zinc-500 border-zinc-850 hover:text-zinc-300'
                        }`}
                      >
                        🗂️ دمج جميع القطاعات
                      </button>
                      <button
                        type="button"
                        disabled={selectedShortageCategory === 'all'}
                        onClick={() => setWaCategoryScope('current')}
                        className={`p-2 rounded border text-center transition disabled:opacity-30 ${
                          waCategoryScope === 'current'
                            ? 'bg-zinc-800 text-white border-zinc-700'
                            : 'bg-zinc-950 text-zinc-500 border-zinc-850 hover:text-zinc-300'
                        }`}
                      >
                        📁 نواقص قسم ({selectedShortageCategory === 'all' ? 'اختر قسماً أولا' : selectedShortageCategory}) فقط
                      </button>
                    </div>
                  </div>

                  <div className="bg-zinc-950 border border-zinc-850 p-3 rounded text-[11px] text-zinc-400 space-y-1">
                    <p className="text-rose-400 font-bold mb-1">📝 معاينة سريعة لمحتوى الرسالة:</p>
                    <p>المشرف: م/ أبو جواد المحفلي (772315106)</p>
                    <p>عدد الأصناف اللوجستية التي سيتم ترحيلها: {
                      (waSendScope === 'all' ? combinedShortages : combinedShortages.filter(i => selectedShortageIds.includes(i.id)))
                      .filter(i => waCategoryScope === 'all' || selectedShortageCategory === 'all' || i.category === selectedShortageCategory).length
                    } أصناف</p>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={handleSendWhatsAppShortages}
                      className="flex-1 py-3 bg-[#25d366] hover:bg-[#20ba5a] text-black font-black rounded text-xs transition cursor-pointer shadow-lg flex items-center justify-center gap-1.5"
                    >
                      <span>💬</span> إرسال الآن عبر الواتساب
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsWhatsAppModalOpen(false)}
                      className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition cursor-pointer"
                    >
                      تراجع
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* RENDER TAB 3: DAMAGED SECTION (قسم التالف) */}
      {activeSubTab === 'damaged' && (
        <div className="space-y-4">
          <div className="bg-amber-950/20 border border-amber-900/40 p-4 rounded-lg flex items-center justify-between flex-wrap gap-4">
            <div>
              <h3 className="font-bold text-white flex items-center gap-2">
                <Ban className="text-amber-500 w-5 h-5" />
                سجل المتروكات، التالف والمواد غير الصالحة للبيع
              </h3>
              <p className="text-zinc-400 text-xs mt-1">
                تصفية وتجنيب البضائع التالفة مع توثيق الأسباب التقنية للتلف (عيوب الشحن، الصيانة الفاشلة، كسر الشاشات، إلخ.) مع خصم كامل القيمة فورياً من قيمة رأس المال الحركي.
              </p>
            </div>
            <button
              onClick={() => setIsDamagedOpen(true)}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              تسجيل حالة تلف جديدة
            </button>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4 text-xs font-bold">
              <span className="text-amber-400">سجل الإهدار الحالي ({damagedItems.length} قيود مسجلة)</span>
              <span className="px-3 py-1 bg-rose-500/15 text-rose-400 border border-rose-500/20 rounded font-mono text-xs">
                إجمالي كلفة الفاقد المالي التراكمي: ${stats.damagedCost.toLocaleString()}
              </span>
            </div>

            {damagedItems.length === 0 ? (
              <div className="py-16 text-center text-zinc-500 text-xs">
                لا توجد بضائع تالفة مقيدة حالياً في مخازن التحرير والورشة.
              </div>
            ) : (
              <div className="overflow-x-auto text-xs">
                <table className="w-full border-collapse text-right">
                  <thead>
                    <tr className="border-b border-zinc-800 bg-zinc-950 text-zinc-400 font-bold">
                      <th className="py-3 px-2">معرف القيد</th>
                      <th className="py-3 px-2">السلعة التالفة</th>
                      <th className="py-3 px-2 text-center">الكمية المسحوبة</th>
                      <th className="py-3 px-2 text-center">تكلفة الفاقد الإجمالي</th>
                      <th className="py-3 px-2">سبب استبعاد السلعة ومحاضر الفحص</th>
                      <th className="py-3 px-2">الموظف المقيد للبلاغ</th>
                      <th className="py-3 px-2 text-center">التوثيق الزمني</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-805/40 text-zinc-300">
                    {damagedItems.map((dmg, idx) => (
                      <tr key={idx} className="hover:bg-zinc-850/10">
                        <td className="py-3 px-2 font-mono font-bold text-white">#{dmg.id}</td>
                        <td className="py-3 px-2">
                          <div className="font-bold text-zinc-100">{dmg.itemName}</div>
                          <div className="text-[9px] text-zinc-550 font-mono">السلع ID: {dmg.itemId}</div>
                        </td>
                        <td className="py-3 px-2 text-center font-mono text-amber-500 font-bold">{dmg.quantity} وحدة</td>
                        <td className="py-3 px-2 text-center font-mono text-rose-400 font-bold">${dmg.cost || 0}</td>
                        <td className="py-3 px-2 text-zinc-400 font-mono text-[11px]">{dmg.reason}</td>
                        <td className="py-3 px-2">
                          <span className="inline-flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-zinc-650"></span>
                            {dmg.reportedByName || 'مستخدم النظام'}
                          </span>
                        </td>
                        <td className="py-3 px-2 text-center font-mono text-zinc-500">
                          {new Date(dmg.createdAt).toLocaleString('ar-YE', {hour12:true})}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* RENDER TAB 4: RETURNS SECTION (قسم المرتجع) */}
      {activeSubTab === 'returns' && (
        <div className="space-y-4">
          <div className="bg-emerald-950/20 border border-emerald-900/40 p-4 rounded-lg flex items-center justify-between flex-wrap gap-4">
            <div>
              <h3 className="font-bold text-white flex items-center gap-2">
                <RefreshCcw className="text-emerald-500 w-5 h-5 animate-spin" style={{ animationDuration: '8s' }} />
                مرآة تداول البضائع والمواد المرتجعة للآونة الأخيرة
              </h3>
              <p className="text-zinc-400 text-xs mt-1">
                تتبع واستعراض طلبات مرتجع العملاء أو مرتجع الموردين الخارجيين مع الحفاظ على المقاصة الدفترية وتسوية الذمم والحسابات في درج الكاشير.
              </p>
            </div>
            {onAddReturn && (
              <button
                onClick={() => setIsReturnOpen(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded transition flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                تحرير طلب استرجاع جودة
              </button>
            )}
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
            <h3 className="font-bold text-white text-xs mb-3">تفاصيل حركة البضاعة الراجعة والمقاصة</h3>
            
            {returns.length === 0 ? (
              <div className="py-16 text-center text-zinc-500 text-xs space-y-2">
                <p className="font-black text-amber-500">🔄 لا توجد توثيقات أو طلبات مرتجعة حالياً بالجرد.</p>
                <p>قم بزيارة محطة المرتجعات أو انقر على الزر بالأعلى لتسجيل حركة مرتجعة.</p>
              </div>
            ) : (
              <div className="overflow-x-auto text-xs">
                <table className="w-full border-collapse text-right">
                  <thead>
                    <tr className="border-b border-zinc-800 bg-zinc-950 text-zinc-400 font-bold">
                      <th className="py-3 px-2">الرقم التسلسلي</th>
                      <th className="py-3 px-2">الصنف المسترجع</th>
                      <th className="py-3 px-2 text-center">الكمية المسحوبة</th>
                      <th className="py-3 px-2 text-center">القيمة الإجمالية</th>
                      <th className="py-3 px-2">نوع المرتجع</th>
                      <th className="py-3 px-2">حالة الفحص والمطابقة</th>
                      <th className="py-3 px-2">مسؤول الفحص</th>
                      <th className="py-3 px-2 text-center">التاريخ والوقت</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/40 text-zinc-300">
                    {returns.map((log, idx) => (
                      <tr key={idx} className="hover:bg-zinc-850/10">
                        <td className="py-3 px-2 font-mono font-bold text-[#f1c40f]">#{log.id}</td>
                        <td className="py-3 px-2">
                          <div className="font-bold text-zinc-100">{log.itemName}</div>
                          <div className="text-[10px] text-zinc-500">السبب المحرر: {log.reason}</div>
                        </td>
                        <td className="py-3 px-2 text-center font-mono font-bold text-zinc-200">{log.quantity} حبة</td>
                        <td className="py-3 px-2 text-center font-mono text-emerald-400 font-bold">${log.totalAmount}</td>
                        <td className="py-3 px-2 font-mono">
                          {log.type === 'customer' ? (
                            <span className="text-zinc-300">من عميل نهائي</span>
                          ) : (
                            <span className="text-orange-400">إلى مورد جملة</span>
                          )}
                        </td>
                        <td className="py-3 px-2">
                          <span className={`px-2 py-0.5 rounded font-black text-[9px] ${
                            log.status === 'completed'
                              ? 'bg-emerald-505/10 text-emerald-400 border border-emerald-500/20'
                              : log.status === 'inspection'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                              : 'bg-zinc-800 text-zinc-400'
                          }`}>
                            {log.status === 'completed' ? 'تمت التسوية بنجاح' : log.status === 'inspection' ? 'قيد الفحص والمطابقة والتسوية' : log.status}
                          </span>
                        </td>
                        <td className="py-3 px-2 text-zinc-400 font-semibold">{log.inspectorName || 'فاحص النظام المتكامل'}</td>
                        <td className="py-3 px-2 text-center font-mono text-zinc-500">
                          {new Date(log.createdAt).toLocaleDateString('ar-YE')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* RENDER TAB 5: WAREHOUSES & LOCATIONS (المستودعات والخرائط اللوجستية) */}
      {activeSubTab === 'warehouses' && (
        <div className="space-y-6">
          {/* Warehouse Operations Toolbar */}
          <div className="p-4 bg-[#0d0d0d] border border-zinc-800 rounded-lg flex flex-wrap items-center justify-between gap-4 shadow-sm font-sans">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Warehouse className="w-5 h-5 text-[#f1c40f]" />
                مستشعرات وبوابات الفروع والمستودعات والتحصينات المخزنية
              </h3>
              <p className="text-[11px] text-zinc-500 mt-0.5">توزيع، ومتابعة، وإدارة مستودعات الخامات، ومراكز الفحص الفني الذكي.</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsAddWarehouseOpen(true)}
                className="px-3 py-1.5 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-bold text-xs rounded transition flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                إضافة مستودع جديد
              </button>
              
              <button
                type="button"
                onClick={() => handleOpenAudit(warehousesList[0] || 'المستودع الرئيسي (التحرير)')}
                className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-[#f1c40f] border border-zinc-700 font-bold text-xs rounded transition flex items-center gap-1 cursor-pointer"
              >
                <ClipboardCheck className="w-4 h-4" />
                جرد ومطابقة المخزون
              </button>
            </div>
          </div>

          {/* Dynamic Grid of Warehouses */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {warehousesList.map((whName, wIdx) => {
              // Calculate stats for this warehouse
              const totalItemsInWh = inventory.filter(item => (item.warehouses?.[whName] ?? 0) > 0).length;
              const totalStockVal = inventory.reduce((sum, item) => sum + (item.warehouses?.[whName] ?? 0), 0);

              return (
                <div key={wIdx} className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 flex flex-col justify-between space-y-4 shadow-md hover:border-[#f1c40f]/20 transition">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-white text-sm flex items-center gap-2">
                        <Warehouse className="w-4 h-4 text-[#f1c40f]" />
                        {whName}
                      </h4>
                      <span className="text-[10px] bg-[#f1c40f]/15 text-[#f1c40f] px-2 py-0.5 rounded border border-[#f1c40f]/20 font-mono">
                        نشط
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-500">تم جرد وتأمين المواد المسجلة في هذا المستودع الفرعي.</p>

                    <div className="grid grid-cols-2 gap-2 mt-3.5 bg-zinc-950 p-2 border border-zinc-850 rounded font-mono text-[10px] text-zinc-400">
                      <div>المواد الفريدة: <strong className="text-white font-bold">{totalItemsInWh}</strong></div>
                      <div>إجمالي الوحدات: <strong className="text-white font-bold">{totalStockVal} حبة</strong></div>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-3 border-t border-zinc-805/60">
                    <div className="text-[10px] text-zinc-500 mb-1">الأصناف الحالية والأرصدة بالداخل:</div>
                    <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                      {inventory.map((item, cid) => {
                        const stockVal = item.warehouses?.[whName] || 0;
                        return (
                          <div key={cid} className="p-2 bg-zinc-950 rounded flex items-center justify-between text-[11px] border border-zinc-900">
                            <span className="text-zinc-350 truncate max-w-[120px]">{item.name}</span>
                            <span className="font-mono text-zinc-400 font-bold">{stockVal} حبة</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleOpenAudit(whName)}
                    className="w-full mt-3 py-1.5 bg-zinc-800 hover:bg-zinc-750 text-white text-[11px] font-bold rounded transition cursor-pointer flex items-center justify-center gap-1 border border-zinc-750"
                  >
                    <ClipboardCheck className="w-3.5 h-3.5 text-[#f1c40f]" />
                    بدء جرد وتسويات هذا المستودع
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* RENDER TAB 6: BARCODE LABELS GENERATOR (توليد وطباعة الباركودات) */}
      {activeSubTab === 'barcodes' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Barcode System Toolbar & Control Panel */}
          <div className="p-4 bg-[#0d0d0d] border border-zinc-850 rounded-lg flex flex-wrap items-center justify-between gap-4 shadow-sm font-sans">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <QrCode className="w-5 h-5 text-[#f1c40f]" />
                وحدة توليد وتشفير ملصقات الباركود اليمني الذكية
              </h3>
              <p className="text-[11px] text-zinc-500 mt-0.5">
                توليد أكواد باركود فنية فريدة بنقرة واحدة، وتحديد كميات الطباعة للملصقات الحرارية للمستودعات.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  let count = 0;
                  inventory.forEach(item => {
                    if (!item.barcode) {
                      const randomDigits = Math.floor(1000000000 + Math.random() * 9000000000).toString();
                      const generated = '77' + randomDigits; // 12-digit standard barcode format
                      onUpdateItem({ ...item, barcode: generated });
                      count++;
                    }
                  });
                  alert(`🎉 تم بنجاح توليد وتشفير ${count} كود باركود جديد للمواد مخزنياً!`);
                }}
                className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-[#f1c40f] border border-zinc-700 font-bold text-xs rounded transition flex items-center gap-1 cursor-pointer"
              >
                توليد باركود تلقائي للكل
              </button>

              <button
                type="button"
                onClick={() => {
                  const newList: Record<string, number> = {};
                  inventory.forEach(item => {
                    newList[item.id] = 1;
                  });
                  setBarcodePrintList(newList);
                  alert('📋 تم ضبط كمية ملصقات الطباعة لكل المواد على (1 نسخة) تلقائياً.');
                }}
                className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-800 font-bold text-xs rounded transition cursor-pointer"
              >
                تحديد الكل (1 ملصق)
              </button>

              <button
                type="button"
                onClick={() => {
                  setBarcodePrintList({});
                  alert('🧹 تم تصفير قائمة ملصقات الطباعة بنجاح.');
                }}
                className="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-900 text-red-400 border border-red-950 font-bold text-xs rounded transition cursor-pointer"
              >
                تصفير الكميات بالكامل
              </button>

              <button
                type="button"
                onClick={() => {
                  const itemsToPrint = inventory.filter(item => (barcodePrintList[item.id] || 0) > 0);
                  if (itemsToPrint.length === 0) {
                    alert('⚠️ يرجى تحديد كمية طباعة لمنتج واحد على الأقل أولاً!');
                    return;
                  }

                  const printWindow = window.open('', '_blank', 'width=850,height=750');
                  if (!printWindow) {
                    alert('⚠️ يرجى تفعيل وإلغاء حظر النوافذ المنبثقة لإرسال أمر الطباعة!');
                    return;
                  }

                  const shopName = localStorage.getItem('default_shop_name') || 'مركز جام برو الرئيسي';
                  const currencySymbol = localStorage.getItem('shop_currency_symbol') || 'ر.ي';
                  const currencyRate = parseFloat(localStorage.getItem('shop_currency_rate') || '1');

                  printWindow.document.write(`
                    <!DOCTYPE html>
                    <html dir="rtl" lang="ar">
                      <head>
                        <meta charset="UTF-8">
                        <title>ملصقات الباركود المطبوعة لـ ${shopName}</title>
                        <style>
                          @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap');
                          body {
                            font-family: 'Tajawal', sans-serif;
                            margin: 10px;
                            padding: 0;
                            background: white;
                            color: black;
                            direction: rtl;
                          }
                          .stickers-container {
                            display: grid;
                            grid-template-columns: repeat(3, 1fr);
                            gap: 10px;
                          }
                          .sticker-card {
                            border: 1.5px solid #000;
                            padding: 10px;
                            text-align: center;
                            background: #fff;
                            page-break-inside: avoid;
                            border-radius: 4px;
                            box-sizing: border-box;
                          }
                          .sticker-header {
                            font-size: 9px;
                            font-weight: 800;
                            border-bottom: 1px dashed #000;
                            padding-bottom: 2.5px;
                            margin-bottom: 4px;
                            color: #111;
                            letter-spacing: 0.5px;
                          }
                          .sticker-title {
                            font-size: 11px;
                            font-weight: 700;
                            margin: 3px 0;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                          }
                          .barcode-visual {
                            font-family: monospace;
                            font-size: 16px;
                            font-weight: bold;
                            letter-spacing: 3.5px;
                            background: #f0f0f0;
                            padding: 4px 6px;
                            margin: 6px 0;
                            display: inline-block;
                            width: 90%;
                            user-select: none;
                            border: 1px solid #ddd;
                          }
                          .barcode-number {
                            font-family: monospace;
                            font-size: 9px;
                            font-weight: bold;
                            color: #333;
                            margin-bottom: 4px;
                          }
                          .sticker-price {
                            font-size: 11px;
                            font-weight: 800;
                            border-top: 1px solid #111;
                            padding-top: 3px;
                            margin-top: 4px;
                            color: #000;
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                          }
                          @media print {
                            body { margin: 0; }
                            .sticker-card { border: 1.5px solid #000; -webkit-print-color-adjust: exact; }
                          }
                        </style>
                      </head>
                      <body onload="window.print(); window.close();">
                        <div class="stickers-container">
                          ${itemsToPrint.flatMap(item => {
                            const copies = barcodePrintList[item.id] || 0;
                            const barcodeVal = item.barcode || item.id || '775191021';
                            const localPrice = Math.round(item.price * currencyRate);
                            
                            return Array(copies).fill(0).map(() => `
                              <div class="sticker-card">
                                <div class="sticker-header">${shopName} • ملصق ترميز مخزني</div>
                                <div class="sticker-title">${item.name}</div>
                                <div class="barcode-visual">||||| | ||||| | |||| |</div>
                                <div class="barcode-number">*${barcodeVal}*</div>
                                <div class="sticker-price">
                                  <span>باركود: ${item.category}</span>
                                  <strong>${localPrice} ${currencySymbol}</strong>
                                </div>
                              </div>
                            `);
                          }).join('')}
                        </div>
                      </body>
                    </html>
                  `);
                  printWindow.document.close();
                }}
                className="px-4 py-1.5 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-black text-xs rounded transition flex items-center gap-1 cursor-pointer shadow-[0_0_15px_rgba(241,196,15,0.2)]"
              >
                <Printer className="w-4 h-4" />
                إرسال ملصقات الباركود إلى الطابعة
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
            
            {/* Table Selection Area */}
            <div className="lg:col-span-2 bg-[#0d0d0d] border border-zinc-800 rounded-lg p-5 space-y-4">
              <div className="flex items-center gap-3 bg-zinc-950 p-3 rounded border border-zinc-850">
                <Search className="w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  placeholder="ابحث باسم المادة أو كود الباركود لتسريع الإملاء والغربلة..."
                  value={barcodeSearchQuery}
                  onChange={(e) => setBarcodeSearchQuery(e.target.value)}
                  className="bg-transparent text-sm text-white focus:outline-none w-full font-sans"
                />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right font-sans text-xs text-zinc-400">
                  <thead className="bg-[#141414] text-zinc-300 border-b border-zinc-800 text-[11px] font-bold text-center">
                    <tr>
                      <th className="p-3 text-right">المنتج / المادة</th>
                      <th className="p-3">الفئة مخزنياً</th>
                      <th className="p-3">رمز الباركود الحالي</th>
                      <th className="p-3 text-center">الإجراء والترميز التلقائي</th>
                      <th className="p-3 text-center w-[120px]">كمية الملصقات المطلوبة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/60">
                    {inventory
                      .filter(item => 
                        item.name.toLowerCase().includes(barcodeSearchQuery.toLowerCase()) ||
                        (item.barcode && item.barcode.includes(barcodeSearchQuery)) ||
                        item.category.toLowerCase().includes(barcodeSearchQuery.toLowerCase())
                      )
                      .map((item) => {
                        const currentCopies = barcodePrintList[item.id] || 0;
                        return (
                          <tr key={item.id} className="hover:bg-zinc-900/40 transition">
                            <td className="p-3 font-bold text-white max-w-[200px] truncate text-right">{item.name}</td>
                            <td className="p-3 text-center text-zinc-500">{item.category}</td>
                            <td className="p-3 text-center font-mono text-emerald-400">
                              {item.barcode ? (
                                <span className="bg-emerald-950/40 border border-emerald-900/30 px-2 py-0.5 rounded">
                                  {item.barcode}
                                </span>
                              ) : (
                                <span className="text-amber-500 font-sans">⚠️ غير معرف بالبار كود</span>
                              )}
                            </td>
                            <td className="p-3 text-center">
                              {!item.barcode ? (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const randomDigits = Math.floor(1000000000 + Math.random() * 9000000000).toString();
                                    const generated = '77' + randomDigits; // 12-digit standard code
                                    onUpdateItem({ ...item, barcode: generated });
                                  }}
                                  className="px-2 py-1 bg-zinc-800 hover:bg-[#f1c40f]/20 hover:text-[#f1c40f] rounded text-[10px] text-zinc-400 transition cursor-pointer"
                                >
                                  توليد كود تلقائياً 🏷️
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const randomDigits = Math.floor(1000000000 + Math.random() * 9000000000).toString();
                                    const generated = '77' + randomDigits;
                                    onUpdateItem({ ...item, barcode: generated });
                                  }}
                                  className="px-2 py-1 text-zinc-500 hover:text-white text-[10px] bg-zinc-950 rounded transition cursor-pointer"
                                >
                                  تحديث الكود ♻️
                                </button>
                              )}
                            </td>
                            <td className="p-3 text-center">
                              <div className="flex items-center justify-center gap-1 border border-zinc-800 bg-zinc-950 rounded px-1.5 py-0.5 max-w-[110px] mx-auto">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setBarcodePrintList(prev => ({
                                      ...prev,
                                      [item.id]: Math.max(0, (prev[item.id] || 0) - 1)
                                    }));
                                  }}
                                  className="text-zinc-500 hover:text-white px-1 font-bold text-sm cursor-pointer"
                                >
                                  -
                                </button>
                                <input
                                  type="number"
                                  value={currentCopies}
                                  onChange={(e) => {
                                    const val = Math.max(0, parseInt(e.target.value) || 0);
                                    setBarcodePrintList(prev => ({
                                      ...prev,
                                      [item.id]: val
                                    }));
                                  }}
                                  className="w-10 bg-transparent text-center text-white font-black font-mono text-xs focus:outline-none"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    setBarcodePrintList(prev => ({
                                      ...prev,
                                      [item.id]: (prev[item.id] || 0) + 1
                                    }));
                                  }}
                                  className="text-zinc-500 hover:text-white px-1 font-bold text-sm cursor-pointer"
                                >
                                  +
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Sticker Preview / Quick info widget */}
            <div className="space-y-6">
              
              <div className="bg-[#0b0b0b] border border-zinc-800 rounded-lg p-5 space-y-4">
                <h4 className="font-bold text-white text-xs tracking-wider flex items-center gap-2 border-b border-zinc-850 pb-2">
                  <span className="w-1.5 h-1.5 bg-[#f1c40f] rounded-full"></span>
                  محاكاة ملصق حراري باركود - معاينة حية للملصقات
                </h4>

                <div className="bg-white text-zinc-900 border-2 border-zinc-300 rounded p-4 text-center space-y-2 font-mono flex flex-col items-center">
                  <div className="text-[9px] font-extrabold text-zinc-500 border-b border-dashed border-zinc-300 pb-1 w-full uppercase">
                    {localStorage.getItem('default_shop_name') || 'مركز جام برو الرئيسي'}
                  </div>
                  
                  <div className="text-xs font-black text-black">
                    {inventory.filter(it => (barcodePrintList[it.id] || 0) > 0)[0]?.name || 'حدد مادة أو عياراً مخزنياً لرؤية ملصقها'}
                  </div>
                  
                  <div className="text-2xl font-mono tracking-widest text-zinc-900 leading-none py-1 select-none">
                    |||||| | |||| | ||
                  </div>
                  
                  <div className="text-[10px] text-zinc-500">
                    *{inventory.filter(it => (barcodePrintList[it.id] || 0) > 0)[0]?.barcode || '771234567890'}*
                  </div>

                  <div className="w-full flex justify-between items-center text-black border-t border-zinc-900 pt-1 text-xs">
                    <span className="font-sans text-[10px]">قسم الهواتف</span>
                    <strong className="text-sm font-extrabold">
                      {inventory.filter(it => (barcodePrintList[it.id] || 0) > 0)[0] 
                        ? `${Math.round(inventory.filter(it => (barcodePrintList[it.id] || 0) > 0)[0].price * parseFloat(localStorage.getItem('shop_currency_rate') || '1'))} ${localStorage.getItem('shop_currency_symbol') || 'ر.ي'}`
                        : '٠ ر.ي'
                      }
                    </strong>
                  </div>
                </div>

                <div className="text-[11px] text-zinc-500 space-y-2 bg-zinc-950 p-3 rounded font-sans border border-zinc-900 leading-relaxed">
                  <p>💡 <strong>خطوات تشغيل نظام الباركود:</strong></p>
                  <p>١. غربل المواد باستخدام صندوق البحث السريع.</p>
                  <p>٢. في حال وجود مواد تفتقر لأكواد باركود فنية، اضغط على <strong>توليد كود تلقائياً</strong>.</p>
                  <p>٣. حدد كمية الملصقات لكل صنف عن طريق أزرار الجمع والطرح (+ / -).</p>
                  <p>٤. اضغط على الزر الذهبي <strong>إرسال ملصقات الباركود إلى الطابعة</strong> لإتاحة الطباعة على طابعة زيبرا أو طابعات الورق اللاصق الحرارية.</p>
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* MODAL: ADD PRODUCT */}
      {isAddOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-lg w-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-white text-lg flex items-center gap-2">
                <Package className="text-[#f1c40f] w-5 h-5" />
                تعريف مادة جديدة بنظام جلب الباركود
              </h3>
              <button onClick={() => setIsAddOpen(false)} className="text-zinc-500 hover:text-white">✕</button>
            </div>
            
            <form onSubmit={handleCreateProduct} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">اسم المادة التجارية</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: قطع غيار آبل..."
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">تحديد الفئة</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                  >
                    <option value="قطع غيار لشاشات">قطع غيار لشاشات</option>
                    <option value="بطاريات واكسسوارات">بطاريات واكسسوارات</option>
                    <option value="قطع غيار دقيقة">قطع غيار دقيقة</option>
                    <option value="شبكات واتصالات">شبكات واتصالات</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">سعر التجزئة ($)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    value={price}
                    onChange={(e) => setPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">سعر الجملة ($)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    value={wholesalePrice}
                    onChange={(e) => setWholesalePrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">سعر الشراء / التكلفة ($)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    value={cost}
                    onChange={(e) => setCost(parseFloat(e.target.value) || 0)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 bg-zinc-950 p-4 border border-zinc-850 rounded">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">الرئيسي (التحرير) قطعة</label>
                  <input
                    type="number"
                    min="0"
                    value={warehouseMain}
                    onChange={(e) => setWarehouseMain(parseInt(e.target.value) || 0)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">الصيانة والفحص قطعة</label>
                  <input
                    type="number"
                    min="0"
                    value={warehouseSub}
                    onChange={(e) => setWarehouseSub(parseInt(e.target.value) || 0)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">باركود تعريفي (UPC)</label>
                  <input
                    type="text"
                    placeholder="امسح الباركود للسرعة..."
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">الحد الأدنى للجرد التنبيهي</label>
                  <input
                    type="number"
                    min="1"
                    value={minStock}
                    onChange={(e) => setMinStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">قائمة توافق القطعة (بفواصل)</label>
                <input
                  type="text"
                  placeholder="iPhone 15, iPhone 14 Pro"
                  value={compatibility}
                  onChange={(e) => setCompatibility(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 pt-4 border-t border-zinc-805">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#f1c40f] text-black font-semibold rounded text-xs hover:bg-[#d2ac0a] transition cursor-pointer"
                >
                  حفظ وتسجيل الصنف اللوجستي
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition"
                >
                  إلغاء الأمر
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: REGISTER DAMAGED */}
      {isDamagedOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-sm w-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <AlertCircle className="text-rose-500 w-5 h-5 animate-pulse" />
                قيد خسائر وتفويت بضائع تالفة
              </h3>
              <button onClick={() => setIsDamagedOpen(false)} className="text-zinc-500 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleRegisterDamage} className="space-y-4">
              <div>
                <label className="text-xs text-zinc-400 block mb-1">المادة المستهدفة بالتلف</label>
                <select
                  required
                  value={selectedDmgItemId}
                  onChange={(e) => setSelectedDmgItemId(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                >
                  <option value="">-- اختر السلعة التالفة --</option>
                  {inventory.map(item => (
                    <option key={item.id} value={item.id}>{item.name} (المتوفر: {item.stock})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">الكمية المقيدة تالفة</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={dmgQty}
                    onChange={(e) => setDmgQty(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">موقع الجرد التالف</label>
                  <select
                    value={dmgWarehouse}
                    onChange={(e) => setDmgWarehouse(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs text-white"
                  >
                    <option value="المستودع الرئيسي (التحرير)">المستودع الرئيسي</option>
                    <option value="مستودع الفحص والصيانة">الفحص والصيانة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">توصيف سبب التلف اللوجستي</label>
                <input
                  type="text"
                  required
                  placeholder="سوء شحن، عيب تيار كهربائي، شق داخلي..."
                  value={dmgReason}
                  onChange={(e) => setDmgReason(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 pt-4 border-t border-zinc-805">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded text-xs transition cursor-pointer"
                >
                  قيد كخسارة عاجلة
                </button>
                <button
                  type="button"
                  onClick={() => setIsDamagedOpen(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition"
                >
                  تراجع
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: REGISTER RETURN */}
      {isReturnOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-sm w-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <RefreshCcw className="text-emerald-500 w-5 h-5" />
                تحرير طلب استرجاع ومطابقة المرتجع
              </h3>
              <button onClick={() => setIsReturnOpen(false)} className="text-zinc-500 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleRegisterReturn} className="space-y-4">
              <div>
                <label className="text-xs text-zinc-400 block mb-1">حدد الصنف المطلوب إعادته</label>
                <select
                  required
                  value={selectedRetItemId}
                  onChange={(e) => setSelectedRetItemId(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                >
                  <option value="">-- اختر السلعة المسترجعة --</option>
                  {inventory.map(item => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">الكمية المسحوبة</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={retQty}
                    onChange={(e) => setRetQty(parseInt(e.target.value) || 1)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1">جهة المعاملة</label>
                  <select
                    value={retType}
                    onChange={(e) => setRetType(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs text-white"
                  >
                    <option value="customer">عميل / مستخدم نهائي</option>
                    <option value="supplier">مورد خارجي للجملة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">توضيح تقرير العطل أو المرتجع</label>
                <input
                  type="text"
                  required
                  placeholder="سرقة بالأشعة، خلل فحص التيار، غير متوافقة..."
                  value={retReason}
                  onChange={(e) => setRetReason(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 pt-4 border-t border-zinc-805">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-xs transition cursor-pointer"
                >
                  تقديم للفحص الأولي
                </button>
                <button
                  type="button"
                  onClick={() => setIsReturnOpen(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition"
                >
                  تراجع
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD WAREHOUSE */}
      {isAddWarehouseOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-sm w-full font-sans">
            <h3 className="font-bold text-white text-base mb-4 flex items-center gap-1.5">
              <Warehouse className="text-[#f1c40f] w-5 h-5" />
              إضافة مستودع تخزين جديد لشبكة الفروع
            </h3>
            <form onSubmit={handleAddWarehouse} className="space-y-4">
              <div>
                <label className="text-xs text-zinc-400 block mb-1">اسم المستودع الجديد</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: مستودع تعز، مستودع الحديدة..."
                  value={newWarehouseName}
                  onChange={(e) => setNewWarehouseName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 pt-4 border-t border-zinc-805">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#f1c40f] text-black font-bold rounded text-xs hover:bg-[#d2ac0a] transition cursor-pointer"
                >
                  حفظ المستودع
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddWarehouseOpen(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: WAREHOUSE AUDIT */}
      {isAuditOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-2xl w-full font-sans max-h-[90vh] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-white text-base flex items-center gap-1.5">
                  <ClipboardCheck className="text-[#f1c40f] w-5 h-5" />
                  جرد ومطابقة المخزون الفعلي: {selectedAuditWarehouse}
                </h3>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-zinc-400">اختر مستودعاً للجرد:</span>
                  <select
                    value={selectedAuditWarehouse}
                    onChange={(e) => handleOpenAudit(e.target.value)}
                    className="bg-zinc-950 border border-zinc-800 rounded px-2 py-0.5 text-xs text-zinc-300"
                  >
                    {warehousesList.map((name, i) => (
                      <option key={i} value={name}>{name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <p className="text-xs text-zinc-400 mb-4 leading-relaxed font-sans">
                قم بتعديل الكميات الفعلية الحالية المتواجدة بناءً على الجرد العيني اليومي. عند الضغط على "حفظ ومطابقة الجرد"، سيقوم النظام بتوزيع الفروقات وحساب الوفورات المخزنية ومطابقتها ذاتياً.
              </p>

              <div className="space-y-2.5 overflow-y-auto max-h-[50vh] pr-1 divide-y divide-zinc-800/40">
                {inventory.map((item) => {
                  const currentQty = auditQuantities[item.id] ?? 0;
                  return (
                    <div key={item.id} className="pt-2.5 flex items-center justify-between gap-4 text-xs font-sans">
                      <div>
                        <span className="text-white font-bold block">{item.name}</span>
                        <span className="text-[10px] text-zinc-500 font-mono">ID: {item.id} &bull; التكلفة: ${item.cost}</span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 bg-zinc-950 p-1.5 rounded border border-zinc-850">
                        <button
                          type="button"
                          onClick={() => {
                            setAuditQuantities(curr => ({
                              ...curr,
                              [item.id]: Math.max(0, currentQty - 1)
                            }));
                          }}
                          className="w-6 h-6 rounded bg-zinc-850 hover:bg-zinc-800 text-white font-bold text-center leading-none flex items-center justify-center cursor-pointer"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="0"
                          value={currentQty}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 0;
                            setAuditQuantities(curr => ({
                              ...curr,
                              [item.id]: val
                            }));
                          }}
                          className="w-16 bg-[#0a0a0a] border border-zinc-800 rounded text-center text-white py-0.5 text-xs font-mono font-bold focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setAuditQuantities(curr => ({
                              ...curr,
                              [item.id]: currentQty + 1
                            }));
                          }}
                          className="w-6 h-6 rounded bg-zinc-850 hover:bg-zinc-800 text-white font-bold text-center leading-none flex items-center justify-center cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex gap-3 pt-5 border-t border-zinc-800/60 mt-4 shrink-0 font-sans">
              <button
                type="button"
                onClick={handleSaveAudit}
                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs transition cursor-pointer"
              >
                حفظ ومطابقة الجرد العيني
              </button>
              <button
                type="button"
                onClick={() => setIsAuditOpen(false)}
                className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-xs hover:text-white transition cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
