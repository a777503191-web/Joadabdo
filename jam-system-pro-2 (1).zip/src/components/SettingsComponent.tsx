import React, { useState } from 'react';
import { 
  Settings, 
  Store, 
  Phone, 
  MapPin, 
  Download, 
  Upload, 
  Coins, 
  Check, 
  RefreshCcw, 
  Lock,
  Trash2
} from 'lucide-react';

interface SettingsComponentProps {
  onBackupRestoreTrigger?: () => void;
  activeStore?: any;
  onUpdateActiveStore?: (updatedFields: any) => void;
}

export default function SettingsComponent({ onBackupRestoreTrigger, activeStore, onUpdateActiveStore }: SettingsComponentProps) {
  // Shop Identity
  const [shopName, setShopName] = useState(() => {
    return activeStore?.name || localStorage.getItem('default_shop_name') || 'مركز جام برو الرئيسي';
  });
  const [shopSlogan, setShopSlogan] = useState(() => {
    return activeStore?.slogan || localStorage.getItem('default_shop_slogan') || 'لصيانة وبرمجة الهواتف الذكية كفالة وقطع غيار أصلية';
  });
  const [shopPhone, setShopPhone] = useState(() => {
    return activeStore?.phone || activeStore?.ownerPhone || localStorage.getItem('default_shop_phone') || '772315106';
  });
  const [shopAddress, setShopAddress] = useState(() => {
    return activeStore?.address || localStorage.getItem('default_shop_address') || 'صنعاء - التحرير';
  });

  // Currency States
  const [currencySymbol, setCurrencySymbol] = useState(() => {
    return localStorage.getItem('shop_currency_symbol') || 'ر.ي';
  });
  const [exchangeRate, setExchangeRate] = useState(() => {
    return localStorage.getItem('shop_currency_rate') || '1';
  });

  const handleSaveIdentity = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('default_shop_name', shopName);
    localStorage.setItem('default_shop_slogan', shopSlogan);
    localStorage.setItem('default_shop_phone', shopPhone);
    localStorage.setItem('default_shop_address', shopAddress);
    
    if (onUpdateActiveStore) {
      onUpdateActiveStore({
        name: shopName,
        slogan: shopSlogan,
        phone: shopPhone,
        address: shopAddress
      });
    }
    
    alert('🎉 تم حفظ هوية المحل وشعار الفاتورة بنجاح في سجلات التخزين!');
    window.location.reload(); // Refresh to broadcast changes
  };

  const handleSaveCurrency = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('shop_currency_symbol', currencySymbol);
    localStorage.setItem('shop_currency_rate', exchangeRate);
    alert('🪙 تم تحديث إعدادات العملة ومعدل الصرف الافتراضي بنجاح!');
    window.location.reload(); 
  };

  // 📥 EXPORT BACKUP
  const handleExportBackup = () => {
    try {
      const backupData: { [key: string]: any } = {};
      const keys = ['users', 'inventory', 'sales', 'returns', 'purchases', 'maintenance', 'transactions', 'accounts', 'logs', 'damaged'];
      
      keys.forEach(key => {
        const item = localStorage.getItem(key);
        if (item) {
          backupData[key] = JSON.parse(item);
        }
      });

      // Include shop configs
      backupData['_shop_configs'] = {
        default_shop_name: localStorage.getItem('default_shop_name'),
        default_shop_slogan: localStorage.getItem('default_shop_slogan'),
        default_shop_phone: localStorage.getItem('default_shop_phone'),
        default_shop_address: localStorage.getItem('default_shop_address'),
        shop_currency_symbol: localStorage.getItem('shop_currency_symbol'),
        shop_currency_rate: localStorage.getItem('shop_currency_rate'),
      };

      const jsonStr = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `jam_system_pro_backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      alert('🎉 تم استخراج ملف النسخة الاحتياطية بنجاح! احتفظ بالملف بأمان.');
    } catch (err: any) {
      alert(`⚠️ فشل التصدير: ${err?.message || err}`);
    }
  };

  // 📤 IMPORT BACKUP
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm('⚠️ تحذير فني هام! استعادة النسخة الاحتياطية ستقوم باستبدال كافة البيانات الحالية بالكامل. هل تريد الاستمرار بحذر؟')) {
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        if (!data || typeof data !== 'object') {
          throw new Error('صيغة الملف غير صالحة!');
        }

        // Restore keys
        Object.keys(data).forEach(key => {
          if (key === '_shop_configs') {
            const confs = data[key];
            if (confs) {
              Object.keys(confs).forEach(ckey => {
                if (confs[ckey]) localStorage.setItem(ckey, confs[ckey]);
              });
            }
          } else {
            localStorage.setItem(key, JSON.stringify(data[key]));
          }
        });

        alert('⚡ تم استيراد واستعادة قاعدة البيانات والتهيئة بنجاح! سيتم إعادة تشغيل واجهة النظام الآن.');
        window.location.reload();
      } catch (err: any) {
        alert(`❌ فشل استيراد النسخة الاحتياطية. تأكد أنه ملف JSON سليم وصادر من JAM SYSTEM PRO: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  const handleSetYemenRialDefault = () => {
    setCurrencySymbol('ر.ي');
    setExchangeRate('530');
    localStorage.setItem('shop_currency_symbol', 'ر.ي');
    localStorage.setItem('shop_currency_rate', '530');
    alert('👑 تم تهيئة الريال اليمني كعملة افتراضية بمعدل صرف 530 ريال مقابل الدولار بنجاح!');
    window.location.reload();
  };

  const handleFactoryReset = () => {
    if (!confirm('🚨 تنبيه أمني شديد الخطورة! هذا الإجراء سيقوم بحذف كافة الفواتير، الحسابات، الصيانة، والمخازن المخزنة في متصفحك بشكل نهائي والبدء بصفحة بيضاء تماماً ومطهرة. هل أنت متأكد من المسح الشامل للبيانات؟')) {
      return;
    }
    if (!confirm('⚠️ للتأكيد النهائي: لن تتمكن من استرجاع أي مبيعة أو فاتورة مالم يكن لديك نسخة احتياطية سابقة. هل تريد الاستمرار بحذف كل شيء؟')) {
      return;
    }
    const keys = ['users', 'inventory', 'sales', 'returns', 'purchases', 'maintenance', 'transactions', 'accounts', 'logs', 'damaged', 'jam_stores', 'default_shop_name', 'default_shop_slogan', 'default_shop_phone', 'default_shop_address', 'maint_business_type'];
    keys.forEach(key => localStorage.removeItem(key));
    localStorage.removeItem('jam_users');
    localStorage.removeItem('jam_inventory');
    localStorage.removeItem('jam_sales');
    localStorage.removeItem('jam_returns');
    localStorage.removeItem('jam_purchases');
    localStorage.removeItem('jam_maintenance');
    localStorage.removeItem('jam_transactions');
    localStorage.removeItem('jam_accounts');
    localStorage.removeItem('jam_logs');
    localStorage.removeItem('jam_damaged');

    alert('🧹 تم تصفير ومسح قاعدة البيانات بالكامل بنجاح والاستعادة لحالة المصنع النقية! سيتم الآن إعادة تحميل النظام.');
    window.location.reload();
  };

  return (
    <div className="space-y-6 font-sans">
      
      {/* Header Panel */}
      <div className="p-4 bg-[#0d0d0d] border border-zinc-800 rounded-lg flex items-center gap-3">
        <Settings className="w-6 h-6 text-[#f1c40f] animate-spin" style={{ animationDuration: '6s' }} />
        <div>
          <h2 className="text-sm font-bold text-white">مركز إعدادات النظام وتخصيص تجربة المحل وحفظ الأرشيف</h2>
          <p className="text-[11px] text-zinc-500 mt-0.5">التحكم في الهوية التجارية، تفعيل العملات المحلية، وإفراغ أو استعادة قواعد البيانات.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 🏢 1. SHOP IDENTITY */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
            <Store className="w-5 h-5 text-[#f1c40f]" />
            <h3 className="text-xs font-bold text-white">هوية وتفاصيل وصورة المحل</h3>
          </div>

          <form onSubmit={handleSaveIdentity} className="space-y-3 text-xs text-zinc-300">
            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">اسم المحل / المؤسسة الافتراضي</label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white text-right focus:outline-none focus:border-[#f1c40f]"
              />
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">شعار الفاتورة / Slogan</label>
              <input
                type="text"
                value={shopSlogan}
                onChange={(e) => setShopSlogan(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white text-right focus:outline-none focus:border-[#f1c40f]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">رقم هاتف العمل الأساسي</label>
                <div className="flex bg-zinc-950 border border-zinc-800 rounded items-center px-2">
                  <Phone className="w-3.5 h-3.5 text-zinc-500 mr-1" />
                  <input
                    type="text"
                    value={shopPhone}
                    onChange={(e) => setShopPhone(e.target.value)}
                    className="w-full bg-transparent text-left font-mono border-0 py-1.5 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">الموقع الجغرافي / العنوان</label>
                <div className="flex bg-zinc-950 border border-zinc-800 rounded items-center px-2">
                  <MapPin className="w-3.5 h-3.5 text-zinc-500 mr-1" />
                  <input
                    type="text"
                    value={shopAddress}
                    onChange={(e) => setShopAddress(e.target.value)}
                    className="w-full bg-transparent text-right border-0 py-1.5 text-xs text-white focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-extrabold rounded text-xs transition cursor-pointer"
            >
              حفظ هوية المحل بالشعارات الجديدة 💾
            </button>
          </form>
        </div>

        {/* 🪙 2. CURRENCY CONFIGURATION */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
            <Coins className="w-5 h-5 text-[#f1c40f]" />
            <h3 className="text-xs font-bold text-white">إعدادات العملة الافتراضية للفواتير والصرافة</h3>
          </div>

          <div className="space-y-4">
            <div className="p-3 bg-zinc-950 border border-zinc-850 rounded-lg space-y-2">
              <span className="text-[11px] font-bold text-[#f1c40f] block">تهيئة الريال اليمني السريع:</span>
              <p className="text-[10px] text-zinc-400 leading-relaxed">
                هل ترغب في تغيير عملة النظام بالكامل للريال اليمني؟ بنقرة واحدة سيتم تحويل رمز العملات إلى (ر.ي) وتحويل الأسعار والنسب لمطابقة الوضع الإقليمي.
              </p>
              <button
                type="button"
                onClick={handleSetYemenRialDefault}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-[11px] transition cursor-pointer"
              >
                🔄 تنشيط الريال اليمني (ر.ي) كعملة رئيسية فورا
              </button>
            </div>

            <form onSubmit={handleSaveCurrency} className="space-y-3 text-xs text-zinc-300">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">رمز العملة (مثلاً: ر.ي أو $)</label>
                  <input
                    type="text"
                    value={currencySymbol}
                    onChange={(e) => setCurrencySymbol(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white font-bold text-center focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">معدل صرف 1$ (مثلاً: 1 أو 530)</label>
                  <input
                    type="number"
                    step="any"
                    value={exchangeRate}
                    onChange={(e) => setExchangeRate(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white text-center font-mono focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-zinc-800 hover:bg-zinc-750 text-[#f1c40f] font-bold border border-zinc-700 rounded text-xs transition cursor-pointer"
              >
                تخصيص قيم الصرف المالي يدوياً 🪙
              </button>
            </form>
          </div>
        </div>

        {/* 📥 3. BACKUP & RESTORE */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 space-y-4 lg:col-span-2">
          <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
            <RefreshCcw className="w-5 h-5 text-[#f1c40f]" />
            <h3 className="text-xs font-bold text-white">مركز النسخ الاحتياطية المحلي وسجلات الطوارئ</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Export Section */}
            <div className="p-4 bg-[#0a0a0a] border border-zinc-850 rounded-lg space-y-3">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-emerald-400" />
                <span className="text-xs font-bold text-white">تصدير وحفظ البيانات حاليا</span>
              </div>
              <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                يقوم النظام بتجميع مصفوفات المخازن، حسابات الكريمي المالية، كروت الصيانة النشطة، والعملاء وتصديرها بملف مدمج خارجي.
              </p>
              <button
                type="button"
                onClick={handleExportBackup}
                className="w-full py-2 bg-[#f1c40f] hover:bg-[#d2ac0a] text-black font-extrabold text-[11px] rounded transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                📥 حفظ وتحميل ملف النسخة الاحتياطية (.json)
              </button>
            </div>

            {/* Import Section */}
            <div className="p-4 bg-[#0a0a0a] border border-zinc-850 rounded-lg space-y-3">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-rose-400 animate-pulse" />
                <span className="text-xs font-bold text-white">استعادة البيانات من الأرشيف</span>
              </div>
              <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                رفع ملف النسخ الاحتياطي الخاص بك لاستكمال الأعمال أو نقل المنظومة بالكامل لجهاز كمبيوتر آخر دون فقدان أي حركات.
              </p>
              
              <div className="relative">
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportBackup}
                  className="hidden"
                  id="import-backup-file"
                />
                <label
                  htmlFor="import-backup-file"
                  className="w-full py-2 bg-zinc-800 hover:bg-zinc-750 text-white font-bold text-[11px] rounded border border-zinc-700 transition cursor-pointer flex items-center justify-center gap-1.5 text-center"
                >
                  📤 حدد ملف الأرشيف لاسترجاعه الآن
                </label>
              </div>
            </div>

            {/* Factory Reset Section */}
            <div className="p-4 bg-red-950/20 border border-red-900/40 rounded-lg space-y-3 md:col-span-2">
              <div className="flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-red-500" />
                <span className="text-xs font-black text-red-400">حذف البيانات والحسابات التجريبية (إعادة ضبط المصنع كلياً) 🧹</span>
              </div>
              <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                هل ترغب في البدء الفعلي وإطلاق البرنامج لمشروعك الحقيقي؟ سيقوم هذا الإجراء بمسح كافة المنتجات التجريبية، سجلات المبيعات، حسابات البنوك، وكروت صيانة المخططات وحسابات المالكين الفرعيين المحلية وتصفير كافة القيم تماماً لبدء مسيرة مبيعات حقيقية.
              </p>
              <button
                type="button"
                onClick={handleFactoryReset}
                className="w-full py-2.5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-black text-xs rounded transition cursor-pointer flex items-center justify-center gap-2 shadow-lg"
              >
                <Trash2 className="w-4 h-4" />
                <span>إفراغ وحذف الحسابات وقاعدة البيانات التجريبية والبدء من الصفر ⚡</span>
              </button>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
